#' @return This function returns an object of class 'mvoprobit' which is a
#' list containing the following elements:
#' \itemize{
#' \item \code{par} - vector of parameters' estimates.
#' \item \code{coef} - list which j-the element \code{coef[[j]]} is a vector
#' of regression coefficients estimates of the j-th ordered equation i.e.
#' \eqn{\hat{\gamma}_{j}}.
#' \item \code{coef_var} - list which j-the element \code{coef_var[[j]]} is a
#' vector of regression coefficients estimates of the variance part
#' of the j-th ordered equation i.e.
#' \eqn{\hat{\gamma}_{j}^{*}}.
#' \item \code{coef2} - list which j-the element \code{coef2[[j]]} is a matrix
#' of regression coefficients estimates of the j-th continuous equation.
#' Wherein i-th row of this matrix contains estimates of regression 
#' coefficients corresponding to the i-th regime of j-th continuous variable.
#' \item \code{sigma} - estimate of the covariance matrix of random errors
#' of ordered equations i.e. \eqn{\widehat{\Sigma}}.
#' \item \code{sigma2} - estimates of covariances between random errors of
#' continuous equations.
#' \item \code{cov_y} - list which j-th element \code{cov_y[[j]]} contains
#' estimates of covariances between random errors of j-th continuous
#' equation in different regimes.
#' \item \code{cuts} - list which j-the element \code{cuts[[j]]} is a vector
#' of cuts estimates of the j-th equation i.e. \eqn{\hat{c}_{j}}.
#' \item \code{ind} - list containing some indexes partition of the 
#' model (not intended for users).
#' \item \code{logLik} - log-likelihood value.
#' \item \code{regressors} - numeric matrix which j-th element
#' \code{regressors[[j]]} is a regressors matrix of the j-th
#' equation i.e. \eqn{w_{j}}.
#' \item \code{regressors2} - list which j-th element
#' \code{regressors2[[j]]} is a regressors matrix of the j-th
#' variance equation i.e. \eqn{w_{j}^{*}}.
#' \item \code{dependent} - numeric matrix which j-th column 
#' \code{dependent[, j]} is a vector of dependent variable \eqn{z_{j}} values.
#' \item \code{control_lnL} - some additional variables to be passed to
#' likelihood function (not intended for users).
#' \item \code{formula} - the same as \code{formula} input argument but all
#' elements are coerced to formula type.
#' \item \code{lambda} - special variables to be used for multivariate 
#' two-step (non-random) sample selection (Heckman's type) models like 
#' Kossova and Potanin (2018). See 'Details' section of 
#' \code{\link[switchSelection]{predict.mvoprobit}} for more information.
#' \item \code{data_list} - list which j-th element data_list[[j]] is a 
#' dataframe containing regressors and dependent variable of the j-th equation.
#' \item \code{data} - the same as \code{data} input argument but
#' without missing values.
#' \item \code{cov} - estimate of the covariance matrix of parameters'
#' estimator.
#' \item \code{sd} - standard errors of the estimates.
#' \item \code{p_value} - p-values of the tests on significance of the 
#' parameters where null hypothesis is that corresponding parameter equals zero.
#' \item \code{tbl} - special table used to create a summary 
#' (not intended for users).
#' \item \code{groups} - the same as \code{groups} input argument or 
#' automatically generated matrix representing the structure of the system 
#' of equations. Please, see 'Details' section above for more information.
#' \item \code{groups2} - the same as \code{groups2} input argument or 
#' automatically generated matrix representing the structure of the system 
#' of equations. Please, see 'Details' section above for more information.
#' \item \code{marginal} - the same as \code{marginal} input argument.
#' }
