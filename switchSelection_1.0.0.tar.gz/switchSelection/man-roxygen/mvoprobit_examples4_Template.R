#' @examples
#' # -------------------------------
#' # Example 4
#' # Heckman model with
#' # ordered selection mechanism
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' rho <- 0.5
#' var.y <- 0.3
#' sd.y <- sqrt(var.y)
#' sigma <- matrix(c(1,          rho * sd.y,
#'                   rho * sd.y, var.y),
#'                 nrow = 2)
#' errors <- mnorm::rmnorm(n = n, mean = c(0, 0), sigma = sigma)
#' u <- errors[, 1]
#' eps <- errors[, 2]
#' 
#' # Coefficients
#' gamma <- c(-1, 2)
#' beta <- c(1, -1, 1)
#' 
#' # Linear index
#' li <- gamma[1] * w1 + gamma[2] * w2
#' li.y <- beta[1] + beta[2] * w1 + beta[3] * w3
#' 
#' # Latent variable
#' z_star <- li + u
#' y_star <- li.y + eps
#' 
#' # Cuts
#' cuts <- c(-1, 0.5, 2)
#' 
#' # Observable ordered outcome
#' z <- rep(0, n)
#' z[(z_star > cuts[1]) & (z_star <= cuts[2])] <- 1
#' z[(z_star > cuts[2]) & (z_star <= cuts[3])] <- 2
#' z[z_star > cuts[3]] <- 3
#' table(z)
#' 
#' # Observable continuous outcome such
#' # that outcome 'y' is observable only 
#' # when 'z > 1' and unobservable otherwise
#' # i.e. when 'z <= 1' we code 'y' as 'Inf'
#' y <- y_star
#' y[z <= 1] <- Inf
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, 
#'                    z = z, y = y)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Estimation
#' model <- mvoprobit(list(z ~ w1 + w2),
#'                    list(y ~ w1 + w3),
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of ordered equation
#' cbind(true = gamma, estimate = model$coef[[1]])
#'   # cuts
#' cbind(true = cuts, estimate = model$cuts[[1]])   
#'   # regression coefficients of continuous equation
#' cbind(true = beta, estimate = as.numeric(model$coef2[[1]]))  
#'   # variance
#' cbind(true = var.y, estimate = as.numeric(model$var_y[[1]]))
#'   # covariance
#' cbind(true = rho * sd.y, estimate = as.numeric(model$cov_y[[1]]))
#' 
#' # ---
#' # Step 3
#' # Estimation of expectations and marginal effects
#' # ---
#' 
#' # Predict unconditional expectation of the dependent variable
#' predict(model, group2 = 0)
#' 
#' # Predict conditional expectations of the dependent variable
#'   # E(y | z == 2)
#' predict(model, group = 2, group2 = 0)
#'   # E(y | z == 0)
#' predict(model, group = 0, group2 = 0)
#' 
#' # ---
#' # Step 4
#' # Two-step estimation
#' # ---
#' 
#' # Predict adjusted conditional expectations
#' lambda2 <- predict(model, group = 2, type = "lambda")
#' lambda3 <- predict(model, group = 3, type = "lambda")
#' 
#' # Construct variable responsible for adjusted
#' # conditional expectation in linear regression equation
#' data$lambda <- NA
#' data$lambda[model$data$z == 2] <- lambda2[model$data$z == 2]
#' data$lambda[model$data$z == 3] <- lambda3[model$data$z == 3]
#' 
#' # Estimate model via classical least squares
#' model1 <- lm(y ~ w1 + w3, data = data[!is.infinite(data$y), ])
#' summary(model1)
#' 
#' # Estimate model via two-step procedure
#' model2 <- lm(y ~ w1 + w3 + lambda, data = data)
#' summary(model2)
#' 
#' # Check estimates accuracy
#' tbl <- cbind(true = c(beta, rho * sd.y), 
#'              ls = c(coef(model1), 0),
#'              ml = c(as.numeric(model$coef2[[1]]), 
#'                                as.numeric(model$cov_y[[1]])),
#'              twostep = coef(model2))  
#' rownames(tbl) <- names(coef(model2))
#' print(tbl)
#' 
