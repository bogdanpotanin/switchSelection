#' @examples
#' # -------------------------------
#' # Example 7
#' # Endogenous multivariate
#' # switching model with
#' # multivariate heteroscedastic
#' # ordered selection mechanism
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' w4 <- runif(n = n, min = -1, max = 1)
#' w5 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' var_y0 <- 0.9
#' var_y1 <- 1
#' var_g0 <- 1.1
#' var_g1 <- 1.2
#' var_g2 <- 1.3
#' A <- rWishart(1, 7, diag(7))[, , 1]
#' B <- diag(sqrt(c(1, 1, var_y0, var_y1, 
#'                  var_g0, var_g1, var_g2)))
#' sigma <-  B  %*% cov2cor(A) %*% B
#' errors <- mnorm::rmnorm(n = n, mean = rep(0, nrow(sigma)), sigma = sigma)
#' u1 <- errors[, 1]
#' u2 <- errors[, 2]
#' eps0_y <- errors[, 3]
#' eps1_y <- errors[, 4]
#' eps0_g <- errors[, 5]
#' eps1_g <- errors[, 6]
#' eps2_g <- errors[, 7]
#' 
#' # Coefficients
#' gamma1 <- c(-1, 2)
#' gamma1_het <- c(0.5, -1)
#' gamma2 <- c(1, 1)
#' beta0_y <- c(1, -1, 1, -1.2)
#' beta1_y <- c(2, -1.5, 0.5, 1.2)
#' beta0_g <- c(-1, 1, 1, 1)
#' beta1_g <- c(1, -1, 1, 1)
#' beta2_g <- c(1, 1, -1, 1)
#' 
#' # Linear index of ordered equation
#'   # mean
#' li1 <- gamma1[1] * w1 + gamma1[2] * w2
#' li2 <- gamma2[1] * w1 + gamma2[2] * w3
#'   # variance
#' li1_het <- gamma1_het[1] * w2 + gamma1_het[2] * w3
#' 
#' # Linear index of the first continuous equation
#'   # regime 0
#' li_y0 <- beta0_y[1] + beta0_y[2] * w1 + beta0_y[3] * w3 + beta0_y[4] * w4
#'   # regime 1
#' li_y1 <- beta1_y[1] + beta1_y[2] * w1 + beta1_y[3] * w3 + beta1_y[4] * w4
#' 
#' # Linear index of the second continuous equation
#'   # regime 0
#' li_g0 <- beta0_g[1] + beta0_g[2] * w2 + beta0_g[3] * w3 + beta0_g[4] * w5
#'   # regime 1
#' li_g1 <- beta1_g[1] + beta1_g[2] * w2 + beta1_g[3] * w3 + beta1_g[4] * w5
#'   # regime 2
#' li_g2 <- beta2_g[1] + beta2_g[2] * w2 + beta2_g[3] * w3 + beta2_g[4] * w5
#' 
#' # Latent variables
#' z1_star <- li1 + u1 * exp(li1_het)
#' z2_star <- li2 + u2
#' y0_star <- li_y0 + eps0_y
#' y1_star <- li_y1 + eps1_y
#' g0_star <- li_g0 + eps0_g
#' g1_star <- li_g1 + eps1_g
#' g2_star <- li_g2 + eps2_g
#' 
#' # Cuts
#' cuts1 <- c(-1, 1)
#' cuts2 <- c(0)
#' 
#' # Observable ordered outcome
#'   # first
#' z1 <- rep(0, n)
#' z1[(z1_star > cuts1[1]) & (z1_star <= cuts1[2])] <- 1
#' z1[z1_star > cuts1[2]] <- 2
#'   # second
#' z2 <- rep(0, n)
#' z2[z2_star > cuts2[1]] <- 1
#' table(z1, z2)
#' 
#' # Observable continuous outcome such
#' # that outcome 'y' is 
#' # in regime 0 when 'z1 == 1', 
#' # in regime 1 when 'z1 == 0' or 'z1 == 2',
#' # unobservable when 'z2 == 0'
#' y <- rep(NA, n)
#' y[z1 == 1] <- y0_star[z1 == 1]
#' y[z1 != 1] <- y1_star[z1 != 1]
#' y[z2 == 0] <- Inf
#' 
#' #' # Observable continuous outcome such
#' # that outcome 'g' is 
#' # in regime 0 when 'z1 == z2', 
#' # in regime 1 when 'z1 > z2',
#' # in regime 2 when 'z1 < z2',
#' g <- rep(NA, n)
#' g[z1 == z2] <- g0_star[z1 == z2]
#' g[z1 > z2] <- g1_star[z1 > z2]
#' g[z1 < z2] <- g2_star[z1 < z2]
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, w4 = w4, w5 = w5,
#'                    z1 = z1, z2 = z2, y = y, g = g)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Assign groups
#' groups <- matrix(c(0, 0,
#'                    0, 1,
#'                    1, 0,
#'                    1, 1,
#'                    2, 0,
#'                    2, 1), 
#'                  byrow = TRUE, ncol = 2)
#' groups2 <- matrix(NA, nrow = nrow(groups), ncol = 2)
#' groups2[groups[, 1] == 1, 1] <- 0
#' groups2[(groups[, 1] == 0) | (groups[, 1] == 2), 1] <- 1
#' groups2[groups[, 2] == 0, 1] <- -1
#' groups2[groups[, 1] == groups[, 2], 2] <- 0
#' groups2[groups[, 1] > groups[, 2], 2] <- 1
#' groups2[groups[, 1] < groups[, 2], 2] <- 2
#' cbind(groups, groups2)
#' 
#' # Estimation
#' model <- mvoprobit(list(z1 ~ w1 + w2 | w2 + w3,
#'                         z2 ~ w1 + w3),
#'                    list(y ~ w1 + w3 + w4,
#'                         g ~ w2 + w3 + w5),
#'                    groups = groups, groups2 = groups2,
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of the first ordered equation
#' cbind(true = gamma1, estimate = model$coef[[1]])
#' cbind(true = gamma1_het, estimate = model$coef_var[[1]])
#'   # regression coefficients of the second ordered equation
#' cbind(true = gamma2, estimate = model$coef[[2]])
#'   # cuts
#' cbind(true = cuts1, estimate = model$cuts[[1]])   
#' cbind(true = cuts2, estimate = model$cuts[[2]])  
#'   # regression coefficients of the first continuous equation
#' cbind(true = beta0_y, estimate = model$coef2[[1]][1, ]) 
#' cbind(true = beta1_y, estimate = model$coef2[[1]][2, ])
#'   # regression coefficients of the second continuous equation
#' cbind(true = beta0_g, estimate = model$coef2[[2]][1, ]) 
#' cbind(true = beta1_g, estimate = model$coef2[[2]][2, ])
#' cbind(true = beta2_g, estimate = model$coef2[[2]][3, ])
#'   # variances
#' cbind(true = c(var_y0, var_y1), estimate = model$var_y[[1]]) 
#' cbind(true = c(var_g0, var_g1, var_g2), estimate = model$var_y[[2]]) 
#'   # correlation between ordered equations
#' cbind(true = c(sigma[1, 2]), estimate = model$sigma[1, 2])
#'   # covariances between continious and ordered equations
#' cbind(true = sigma[1:2, 3], estimate = model$cov_y[[1]][1, ])
#' cbind(true = sigma[1:2, 4], estimate = model$cov_y[[1]][2, ])
#' cbind(true = sigma[1:2, 5], estimate = model$cov_y[[2]][1, ])
#' cbind(true = sigma[1:2, 6], estimate = model$cov_y[[2]][2, ])
#' cbind(true = sigma[1:2, 7], estimate = model$cov_y[[2]][3, ])
#'   # covariances between continuous equations
#' cbind(true = c(sigma[4, 7], sigma[3, 5], sigma[4, 6]), 
#'       estimate = model$sigma2[[1]]) 
#' 
