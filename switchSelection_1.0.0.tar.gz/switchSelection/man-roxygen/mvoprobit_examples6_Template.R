#' @examples
#' # -------------------------------
#' # Example 6
#' # Endogenous switching model with
#' # multivariate heteroscedastic
#' # ordered selection mechanism
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' w4 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' rho_z1_z2 <- 0.5
#' rho_y0_z1 <- 0.6
#' rho_y0_z2 <- 0.7
#' rho_y1_z1 <- 0.65
#' rho_y1_z2 <- 0.75
#' var_y0 <- 0.9
#' var_y1 <- 1
#' sd_y0 <- sqrt(var_y0)
#' sd_y1 <- sqrt(var_y1)
#' cor_y01 <- 0.7
#' cov_y01 <- sd_y0 * sd_y1 * cor_y01
#' cov_y0_z1 <- rho_y0_z1 * sd_y0
#' cov_y1_z1 <- rho_y1_z1 * sd_y1
#' cov_y0_z2 <- rho_y0_z2 * sd_y0
#' cov_y1_z2 <- rho_y1_z2 * sd_y1
#' sigma <- matrix(c(1,         rho_z1_z2, cov_y0_z1, cov_y1_z1, 
#'                   rho_z1_z2, 1,         cov_y0_z2, cov_y1_z2,
#'                   cov_y0_z1, cov_y0_z2, var_y0,    cov_y01,
#'                   cov_y1_z1, cov_y1_z2, cov_y01,   var_y1),
#'                 nrow = 4)
#' errors <- mnorm::rmnorm(n = n, mean = c(0, 0, 0, 0), sigma = sigma)
#' u1 <- errors[, 1]
#' u2 <- errors[, 2]
#' eps0 <- errors[, 3]
#' eps1 <- errors[, 4]
#' 
#' # Coefficients
#' gamma1 <- c(-1, 2)
#' gamma1_het <- c(0.5, -1)
#' gamma2 <- c(1, 1)
#' beta0 <- c(1, -1, 1, -1.2)
#' beta1 <- c(2, -1.5, 0.5, 1.2)
#' 
#' # Linear index of ordered equation
#'   # mean
#' li1 <- gamma1[1] * w1 + gamma1[2] * w2
#' li2 <- gamma2[1] * w1 + gamma2[2] * w3
#'   # variance
#' li1_het <- gamma1_het[1] * w2 + gamma1_het[2] * w3
#' 
#' # Linear index of continuous equation
#'   # regime 0
#' li_y0 <- beta0[1] + beta0[2] * w1 + beta0[3] * w3 + beta0[4] * w4
#'   # regime 1
#' li_y1 <- beta1[1] + beta1[2] * w1 + beta1[3] * w3 + beta1[4] * w4
#' 
#' # Latent variables
#' z1_star <- li1 + u1 * exp(li1_het)
#' z2_star <- li2 + u2
#' y0_star <- li_y0 + eps0
#' y1_star <- li_y1 + eps1
#' 
#' # Cuts
#' cuts1 <- c(-1, 1)
#' cuts2 <- c(0)
#' 
#' # Observable ordered outcome
#'   # first
#' z1 <- rep(0, n)
#' z1[(z1_star > cuts1[1]) & (z1_star <= cuts1[2])] <- 1
#' z1[z1_star > cuts1[2]] <- 2
#'   # second
#' z2 <- rep(0, n)
#' z2[z2_star > cuts2[1]] <- 1
#' table(z1, z2)
#' 
#' # Observable continuous outcome such
#' # that outcome 'y' is 
#' # in regime 0 when 'z1 == 1', 
#' # in regime 1 when 'z1 == 0' or 'z1 == 2',
#' # unobservable when 'z2 == 0'
#' y <- rep(NA, n)
#' y[z1 == 1] <- y0_star[z1 == 1]
#' y[z1 != 1] <- y1_star[z1 != 1]
#' y[z2 == 0] <- Inf
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, w4 = w4,
#'                    z1 = z1, z2 = z2, y = y)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Assign groups
#' groups <- matrix(c(0, 0,
#'                    0, 1,
#'                    1, 0,
#'                    1, 1,
#'                    2, 0,
#'                    2, 1), 
#'                  byrow = TRUE, ncol = 2)
#' groups2 <- matrix(c(-1, 1, -1, 0, -1, 1), ncol = 1)
#' 
#' # Estimation
#' model <- mvoprobit(list(z1 ~ w1 + w2 | w2 + w3,
#'                         z2 ~ w1 + w3),
#'                    list(y ~ w1 + w3 + w4),
#'                    groups = groups, groups2 = groups2,
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of the first ordered equation
#' cbind(true = gamma1, estimate = model$coef[[1]])
#' cbind(true = gamma1_het, estimate = model$coef_var[[1]])
#'   # regression coefficients of the second ordered equation
#' cbind(true = gamma2, estimate = model$coef[[2]])
#'   # cuts
#' cbind(true = cuts1, estimate = model$cuts[[1]])   
#' cbind(true = cuts2, estimate = model$cuts[[2]])  
#'   # regression coefficients of continuous equation
#' cbind(true = beta0, estimate = model$coef2[[1]][1, ]) 
#' cbind(true = beta1, estimate = model$coef2[[1]][2, ])
#'   # variances
#' cbind(true = c(var_y0, var_y1), estimate = model$var_y[[1]]) 
#'   # covariances
#' cbind(true = c(cov_y0_z1, cov_y0_z2), estimate = model$cov_y[[1]][1, ])
#' cbind(true = c(cov_y1_z1, cov_y1_z2), estimate = model$cov_y[[1]][2, ])
#' 
