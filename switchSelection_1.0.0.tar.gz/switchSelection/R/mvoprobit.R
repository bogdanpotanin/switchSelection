#' Multivariate ordered probit model with heteroscedasticity 
#' and (non-random) sample selection.
#' @description This function allows to estimate parameters of multivariate
#' ordered probit model. It is possible to account for heteroscedastic
#' variances and (non-random) sample selection i.e. when some categories of 
#' particular dependent variables are observable only under some specific values 
#' of other dependent variables.
#' @template mvoprobit_param_Template
#' @template mvoprobit_details_Template
#' @template mvoprobit_return_Template
#' @template mvoprobit_examples1_Template
#' @template mvoprobit_examples2_Template
#' @template mvoprobit_examples3_Template
#' @template mvoprobit_examples4_Template
#' @template mvoprobit_examples5_Template
#' @template mvoprobit_examples6_Template
#' @template mvoprobit_examples7_Template
#' @references E. Kossova, B. Potanin (2018). 
#' Heckman method and switching regression model multivariate generalization.
#' Applied Econometrics, vol. 50, pages 114-143.
#'
mvoprobit <- function(formula,
                      formula2 = NULL,
                      data = NULL,
                      groups = NULL,
                      groups2 = NULL,
                      marginal = list(),
                      opt_type = "optim",
                      opt_args = NULL,
                      start = NULL,
                      cov_type = "sandwich",
                      n_sim = 1000, 
                      n_cores = 1,
                      control = NULL)
{
  # Validation
  
    # data
  if (!is.data.frame(data))
  {
    stop(paste0("Argument 'data' is missing or wrong. ",
                "Please, insure that 'data' is dataframe ",
                "containing variables described in 'formula'.",
                "\n"))
  }
  
    # groups
  if (!is.null(groups))
  {
    if (!is.matrix(groups))
    {
      groups <- as.matrix(groups)
    }
    if (ncol(groups) != length(formula))
    {
      stop(paste0("Argument 'groups' is wrong. ",
                  "Please, insure that 'groups' is a matrix ",
                  "which number of columns equals to the length ",
                  "of 'formula'.",
                  "\n"))
    }
  }
  
    # opt_type
  opt_type_vec <- c("optim", "gena", "pso")
  if (!(opt_type %in% opt_type_vec))
  {
    stop(paste0("Argument 'opt_type' is wrong. ",
                "Please, insure that it is one of: ",
                paste0(opt_type_vec, collapse = ", "),
                "\n"))
  }
  
    # cov_type
  cov_type_vec <- c("sandwich", "hessian", "GOP", "no")
  if (!is.matrix(cov_type))
  {
    if (!(cov_type %in% cov_type_vec))
    {
      stop(paste0("Argument 'cov_type' is wrong. ",
                  "Please, insure that it is one of: ",
                  paste0(cov_type_vec, collapse = ", "),
                  "\n"))
    }
  }
  
    # formula
  if (!is.list(formula))
  {
    formula <- list(formula)
  }
  
    # formula2
  is2 <- FALSE
  if (!is.null(formula2))
  {
    is2 <- TRUE
    if (!is.list(formula2))
    {
      formula2 <- list(formula2)
    }
  }
  
    # marginal
  if (length(marginal) > 0)
  {
    if (length(marginal) != length(formula))
    {
      stop(paste0("The number of elements in 'marginal' should be the same ",
                  "as the number of ordered equations. ",
                  "Please, insure that 'length(marginal) == length(formula)' ",
                  "or 'marginal' is an empty character vector."))
    }
  }
  
  #---
  
  # Deal with control variables
  out_type <- "default"
  if (!is.null(control))
  {
    if (exists("out_type", where = control))
    {
      out_type = control$out_type
    }
  }
  
  # Get number of equations
  n_eq <- length(formula)
  n_eq2 <- length(formula2)
  
  # Coerce formula to type 'formula' and check whether it has "|" symbol
  # which indicates the presence of heteroscedasticity.
  # If there is heteroscedasticity then store separate formulas for
  # mean and variance equations
  is_het <- rep(FALSE, n_eq)
  formula_mean <- vector(mode = "list", length = n_eq)
  formula_var <- vector(mode = "list", length = n_eq)
  for (i in 1:n_eq)
  {
    formula[[i]] <- as.formula(formula[[i]])
    frm_tmp <- paste(formula[[i]][2], formula[[i]][3], sep = '~')
    is_het[i] <- grepl(x = frm_tmp, pattern = "|", fixed = TRUE)
    if (is_het[i])
    {
      frm_tmp <- formula.split(formula[[i]])
      formula_mean[[i]] <- frm_tmp[[1]]
      formula_var[[i]] <- frm_tmp[[2]]
    }
    else
    {
      formula_mean[[i]] <- formula[[i]]
    }
  }
  
  # Get separate dataframe for each equation
  # insuring that all dataframes include the 
  # same observations
  df <- vector(mode = "list", length = n_eq)
  df_mean <- vector(mode = "list", length = n_eq)
  df_var <- vector(mode = "list", length = n_eq)
  df2 <- NULL
  complete_is <- matrix(NA, 
                        nrow = nrow(data), 
                        ncol = n_eq)
  complete_is2 <- NULL
    # ordered
  if (is2)
  {
    df2 <- vector(mode = "list", length = n_eq2)
    complete_is2 <- matrix(NA, 
                           nrow = nrow(data), 
                           ncol = n_eq2)
  }
  frm_tmp <- NULL
  for (i in 1:n_eq)
  {
    if (is_het[i])
    {
      frm_tmp <- switchSelection::formula.merge(
        switchSelection::formula.split(formula[[i]]), 
        type = "var-terms")
    }
    else
    {
      frm_tmp <- formula[[i]]
    }
    df[[i]] <- model.frame(frm_tmp, data, na.action = na.pass)
    z_i_tmp <- as.vector(df[[i]][, 1])
    complete_is[, i] <- complete.cases(df[[i]]) | ((z_i_tmp == -1) & !is.na(z_i_tmp))
  }
    # continuous
  if (is2)
  {
    for (i in 1:n_eq2)
    {
      df2[[i]] <- model.frame(formula2[[i]], data, na.action = na.pass)
      y_i_tmp <- as.vector(df2[[i]][, 1])
      complete_is2[, i] <- complete.cases(df2[[i]]) | is.infinite(y_i_tmp)
    }
  }
    # merge
  if (is2)
  {
    complete_ind <- which((rowSums(complete_is) == n_eq) &
                          (rowSums(complete_is2) == n_eq2))
  }
  else
  {
    complete_ind <- which(rowSums(complete_is) == n_eq)
  }
    # seperate dataframes for mean and variance equations
    # of ordered variables
  for (i in 1:n_eq)
  {
    df_mean[[i]] <- model.frame(formula_mean[[i]], 
                                data[complete_ind, ], 
                                na.action = na.pass)
    if (is_het[i])
    {
      df_var[[i]] <- model.frame(formula_var[[i]], 
                                 data[complete_ind, ], 
                                 na.action = na.pass)
    }
  }
    # dataframe for continuous equations
  if (is2)
  {
    for (i in 1:n_eq2)
    {
      df2[[i]] <- model.frame(formula2[[i]], 
                              data[complete_ind, ], 
                              na.action = na.pass)
    }
  }

  # Calculate number of observations
  n_obs <- length(complete_ind)

  # Extract dependent variables and W_mean
    # ordered variables
  z <- matrix(NA, nrow = n_obs, ncol = n_eq)
  W_mean <- vector("mode" = "list", length = n_eq)
  W_var <- vector("mode" = "list", length = n_eq)
  for (i in 1:n_eq)
  {
    z[, i] <- as.vector(df_mean[[i]][, 1])
    W_mean[[i]] <- as.matrix(df_mean[[i]][, -1])
    if (is_het[i])
    {
      W_var[[i]] <- as.matrix(df_var[[i]][, -1, drop = FALSE])
    }
    else
    {
      W_var[[i]] <- matrix()
    }
  }
    # continuous variables
  y <- matrix(NA)
  X <- list(matrix())
  if (is2)
  {
    y <- matrix(NA, nrow = n_obs, ncol = n_eq2)
    X <- vector("mode" = "list", length = n_eq2)
    for (i in 1:n_eq2)
    {
      y[, i] <- as.vector(df2[[i]][, 1])
      X[[i]] <- cbind(1, as.matrix(df2[[i]][, -1, drop = FALSE]))
      colnames(X[[i]])[1] <- "(Intercept)"
    }
  }

  # Get names of the dependent variables
  z_names <- rep(NA, n_eq)
  y_names <- NULL
  for (i in 1:n_eq)
  {
    z_names[i] <- as.character(formula[[i]][[2]])
  }
  if (n_eq2 > 0)
  {
    y_names <- rep(NA, n_eq2)
    for (i in 1:n_eq2)
    {
      y_names[i] <- as.character(formula2[[i]][[2]])
    }
  }

  # Return data if need
  if (out_type == "data")
  {
    out <- list(n_obs = n_obs,
                dependent = z,
                W_mean = W_mean,
                W_var = W_var,
                X = X,
                complete_ind = complete_ind,
                data = data[complete_ind, ])
    
    return(out)
  }
  
  # Calculate the number of cuts for each equation
  n_cuts_eq <- rep(NA, n_eq)
  for (i in 1:n_eq)
  {
    n_cuts_eq[i] <- max(z[, i])
  }
  
  # Set combinations by default if need
  if (is.null(groups))
  {
    groups <- as.matrix(t(hpa::polynomialIndex(n_cuts_eq + 1) - 1))
  }
  n_groups_unique <- nrow(groups)
  
  # Set groups for continuous equations if need
  if (is.null(groups2))
  {
    if (is2)
    {
      groups_tmp <- groups
      groups2_tmp <- as.matrix(t(hpa::polynomialIndex(rep(1, n_eq2)) - 1))
      for (i in 1:nrow(groups2_tmp))
      {
        groups2 <- rbind(groups2,
                         matrix(rep(groups2_tmp[i, ], 
                                    each = n_groups_unique), 
                                nrow = n_groups_unique))
        if (i > 1)
        {
          groups <- rbind(groups, groups_tmp)
        }
      }
    }
    else
    {
      groups2 <- matrix()
    }
  }

  # Get indexes of observations for each group
  ind_g <- NULL
  if (is2)
  {
    y_tmp <- y
    y_tmp[is.infinite(y)] <- -1
    y_tmp[!is.infinite(y)] <- 0
    groups2_tmp <- groups2
    groups2_tmp[groups2_tmp != -1] <- 0
    ind_g <- findGroup(cbind(z, y_tmp), cbind(groups, groups2_tmp))
  }
  else
  {
    ind_g <- findGroup(z, groups)
  }

  # Calculate the number of groups
  n_groups <- length(ind_g)
  
  # Calculate number of observations in each group
  n_obs_g <- rep(NA, n_groups)
  for (i in 1:n_groups)
  {
    n_obs_g[i] <- length(ind_g[[i]])
  }
  n_obs_g_0 <- n_obs_g == 0
  
  # Find groups with zero observable equations
  ind_o_groups <- rep(FALSE, n_groups)
  for (i in 1:n_groups)
  {
    if (any(groups[i, ] != -1))
    {
      ind_o_groups[i] <- TRUE
    }
  }
  
  # Remove groups with zero observations
  # and without observable equations
  ind_g_include <- !n_obs_g_0 & ind_o_groups
  groups <- groups[ind_g_include, , drop = FALSE]
  if (is2)
  {
    groups2 <- groups2[ind_g_include, , drop = FALSE]
  }
  n_obs_g <- n_obs_g[ind_g_include]
  ind_g <- ind_g[ind_g_include]
  n_groups <- nrow(groups[, , drop = FALSE])

  # Find unobservable groups for continuous variables
  if (is2)
  {
    for (i in n_groups)
    {
      for (j in 1:n_eq2)
      {
        if (all(is.infinite(y[ind_g[[i]], j]) | 
                is.na(y[ind_g[[i]], j])))
        {
          groups2[i, j] <- -1
        }
      }
    }
  }

  # Calculate the number of observed equations per group
  n_eq_g <- vector(mode = "numeric", length = n_groups)
  n_eq2_g <- rep(0, n_groups)
  n_eq_all_g <- n_eq_g
  for (i in 1:n_groups)
  {
    n_eq_g[i] <- sum(groups[i, , drop = FALSE] != -1)
  }
  if (is2)
  {
    n_eq2_g <- vector(mode = "numeric", length = n_groups)
    for (i in 1:n_groups)
    {
      n_eq2_g[i] <- sum(groups2[i, , drop = FALSE] != -1)
      n_eq_all_g[i] <- n_eq_g[i] + n_eq2_g[i]
    }
  }

  # Get indexes of observed equations for each group
  ind_eq <- vector(mode = "list", length = n_groups)
  ind_eq2 <- list(NA)
  ind_eq_all <- ind_eq
  for (i in 1:n_groups)
  {
    ind_eq[[i]] <- which(groups[i, , drop = FALSE] != -1)
  }
  if (is2)
  {
    ind_eq2 <- vector(mode = "list", length = n_groups)
    for (i in 1:n_groups)
    {
      ind_eq2[[i]] <- which(groups2[i, , drop = FALSE] != -1)
      ind_eq_all[[i]] <- c(ind_eq[[i]], ind_eq2[[i]] + n_eq)
    }
  }
  else
  {
    ind_eq_all <- ind_eq
  }
  # Get the number of coefficients (regressors)
  # for each equation and determine their indexes
  # in parameters vector
  n_coef <- vector("mode" = "numeric", length = n_eq)
  coef_ind <- vector("mode" = "list", length = n_eq)
  for(i in 1:n_eq)
  {
    n_coef[i] <- ncol(W_mean[[i]])
    if (i != 1)
    {
      coef_ind[[i]] <- (coef_ind[[i - 1]][n_coef[i - 1]] + 1):
                       ((coef_ind[[i - 1]][n_coef[i - 1]] + n_coef[i]))
    }
    else
    {
      coef_ind[[i]] <- 1:n_coef[i]
    }
  }

  # Calculate total number of estimated coefficients
  n_coef_total <- sum(n_coef)
  
  # Get the number of the covariance matrix 
  # elements to be estimated
  n_sigma <- (n_eq ^ 2 - n_eq) / 2
  
  # Get the number of cut points to be considered
  n_cuts <- sum(n_cuts_eq)
  
  # Get indexes of sigma elements in parameters vector
  sigma_ind <- (n_coef_total + 1):(n_coef_total + n_sigma)

  # Store indexes of sigma elements in a matrix form
  sigma_ind_mat <- matrix(NA, nrow = n_eq, ncol = n_eq)
  if (n_eq >= 2)
  {
    counter <- sigma_ind[1]
    for (i in 2:n_eq)
    {
      for (j in 1:(i - 1))
      {
        sigma_ind_mat[i, j] <- counter
        sigma_ind_mat[j, i] <- sigma_ind_mat[i, j]
        counter <- counter + 1
      }
    }
  }

  # Store indexes of cuts in a list form
  cuts_ind <- vector("mode" = "list", length = n_eq)
  n_par <- n_coef_total + n_sigma
  for(i in 1:n_eq)
  {
    for (j in 1:n_cuts_eq[i])
    {
      n_par <- n_par + 1
      cuts_ind[[i]][j] <- n_par
    }
  }
  
  # Deal with coefficients of variance equation
  n_coef_var <- vector("mode" = "numeric", length = n_eq)
  coef_var_ind <- vector("mode" = "list", length = n_eq)
  for(i in 1:n_eq)
  {
    if(is_het[i])
    {
      n_coef_var[i] <- ncol(W_var[[i]])
      coef_var_ind[[i]] <- (n_par + 1):(n_par + n_coef_var[i])
      n_par <- n_par + n_coef_var[i]
    }
    else
    {
      coef_var_ind[[i]] <- numeric()
    }
  }
  
  # Calculate the number of regimes for each continuous variable
  n_regimes <- vector(mode = "numeric", length = 0)
  if (is2)
  {
    n_regimes <- vector(mode = "numeric", length = n_eq2)
    for (i in 1:n_eq2)
    {
      n_regimes[i] <- max(groups2[, i] + 1)
    }
  }
  
  # Deal with coefficients of continuous equations
  n_coef2 <- vector(mode = "numeric", length = 0)
  coef2_ind <- list(matrix())
  if (is2)
  {
    n_coef2 <- vector(mode = "numeric", length = n_eq2)
    coef2_ind <- vector(mode = "list", length = n_eq2)
    for(i in 1:n_eq2)
    {
      n_coef2[i] <- ncol(X[[i]])
      # coefficients for each regime are located in a different rows
      coef2_ind[[i]] <- matrix((n_par + 1):(n_par + n_coef2[i] * n_regimes[i]), 
                               nrow = n_regimes[i], ncol = n_coef2[i], 
                               byrow = TRUE)
      n_par <- n_par + length(coef2_ind[[i]])
    }
  }
  
  # Determine structure of covariances between continuous
  # equations for different regimes
  regimes <- as.matrix(t(hpa::polynomialIndex(n_regimes - 1)))
  n_regimes_total <- nrow(regimes)
  
  # If need add covariances related to continuous equations
  var_y_ind <- list(NA)
  cov_y_ind <- list(matrix(0))
  sigma2_ind <- list(matrix(0))
  sigma2_ind_mat <- list(matrix(0))
  if (is2)
  {
    # variances
    for (i in 1:n_eq2)
    {
      var_y_ind[[i]] <- (n_par + 1):(n_par + n_regimes[i])
      n_par <- n_par + n_regimes[i]
    }
    # covariances with continuous equations
    for (i in 1:n_eq2)
    {
      cov_y_ind[[i]] <- matrix(ncol = n_eq, nrow = n_regimes[i])
      for (j in 1:n_regimes[i])
      {
        cov_y_ind[[i]][j, ] <- (n_par + 1):(n_par + n_eq)
        n_par <- n_par + n_eq
      }
    }
    # covariances between continuous equations
    if (n_eq2 >= 2)
    {
      n_sigma2 <- (n_eq2 ^ 2 - n_eq2) / 2
      sigma2_ind <- vector(mode = "list", length = n_sigma2)
      regimes_pair <- vector(mode = "list", length = n_sigma2)
      sigma2_ind_mat <- vector(mode = "list", length = n_groups)
      for (g in 1:n_groups)
      {
        sigma2_ind_mat[[g]] <- matrix(NA, nrow = n_eq2, ncol = n_eq2)
      }
      # indexes for each covariance depending on regime
      counter <- 1
      for (i in 2:n_eq2)
      {
        for (j in 1:(i - 1))
        {
          sigma2_ind[[counter]] <- numeric()
          regimes_pair[[counter]] <- numeric()
          # note that i > j so in regimes_pair equation with
          # the greater index goes first
          pairs <- unique(groups2[, c(i, j)])
          pairs <- pairs[(pairs[, 1] != -1) & (pairs[, 2] != -1), ]
          regimes_pair_n <- ifelse(is.matrix(pairs), nrow(pairs), 0)
          if (regimes_pair_n > 0)
          {
            regimes_pair[[counter]] <- pairs
            sigma2_ind[[counter]] <- (n_par + 1):(n_par + regimes_pair_n)
            n_par <- n_par + regimes_pair_n
            # indexes of covariances depending on group
            for (g in 1:n_groups)
            {
              cond <- which((regimes_pair[[counter]][, 1] == groups2[g, i]) &
                            (regimes_pair[[counter]][, 2] == groups2[g, j]))
              if (length(cond) > 0)
              {
                sigma2_ind_mat[[g]][i, j] <- sigma2_ind[[counter]][cond]
                sigma2_ind_mat[[g]][j, i] <- sigma2_ind[[counter]][cond]
              }
            }
          }
          counter <- counter + 1
        }
      }
    }
  }
  
  # Parameters associated with marginal distributions
  is_marginal <- length(marginal) > 0
  marginal_par_ind <- list(NA)
  marginal_par_n <- rep(0, n_eq)
  marginal_names <- character()
  if (is_marginal)
  {
    marginal_names <- names(marginal)
    for (i in 1:n_eq)
    {
      marginal_par_n[i] <- ifelse((length(marginal[[i]]) != 0) &
                                  !is.null(marginal[[i]]), 
                                  as.numeric(marginal[[i]]), 0)
      if (marginal_par_n[i] > 0)
      {
        marginal_par_ind[[i]] <- (n_par + 1):(n_par + marginal_par_n[i])
        n_par <- n_par + length(marginal_par_ind[[i]])
      }
    }
  }
  
  # Round the number of parameters to prevent bugs
  marginal_par_n <- round(marginal_par_n)

  # Store the information into the list
  control_lnL <- list(n_par = n_par,
                      n_obs = n_obs,
                      n_eq = n_eq,
                      n_eq2 = n_eq2,
                      n_coef = n_coef,
                      n_coef2 = n_coef2,
                      n_regimes = n_regimes,
                      coef_ind = lapply(coef_ind, function(x){x - 1}),
                      coef_var_ind = lapply(coef_var_ind, function(x){x - 1}),
                      coef2_ind = lapply(coef2_ind, function(x){x - 1}),
                      sigma_ind = sigma_ind - 1,
                      sigma2_ind = lapply(sigma2_ind, function(x){x - 1}),
                      sigma_ind_mat = sigma_ind_mat - 1,
                      sigma2_ind_mat = lapply(sigma2_ind_mat, 
                                              function(x){x - 1}),
                      var_y_ind = lapply(var_y_ind, function(x){x - 1}),
                      cov_y_ind = lapply(cov_y_ind, function(x){x - 1}),
                      cuts_ind = lapply(cuts_ind, function(x){x - 1}),
                      marginal_par_ind = lapply(marginal_par_ind, 
                                                function(x){x - 1}),
                      n_groups = n_groups,
                      ind_g = lapply(ind_g, function(x){x - 1}),
                      ind_eq = lapply(ind_eq, function(x){x - 1}),
                      ind_eq2 = lapply(ind_eq2, function(x){x - 1}),
                      ind_eq_all = lapply(ind_eq_all, function(x){x - 1}),
                      n_cuts_eq = n_cuts_eq,
                      groups = groups,
                      groups2 = groups2,
                      n_obs_g = n_obs_g,
                      n_eq_g = n_eq_g,
                      n_eq2_g = n_eq2_g,
                      n_eq_all_g = n_eq_all_g,
                      is_het = is_het,
                      is2 = is2,
                      y = y,
                      X = X,
                      marginal_names = marginal_names,
                      marginal_par_n = marginal_par_n)

  # Create a starting point for the numeric optimization
  if (is.null(start))
  {
    start <- rep(0, n_par)
    for (i in 1:n_eq)
    {
      # cuts
      for (j in 1:n_cuts_eq[i])
      {
        start[cuts_ind[[i]]][j] <- qnorm(mean(z[, i] <= (j - 1)))
      }
    }
    if (n_eq2 > 0)
    {
      for (i in 1:n_eq2)
      {
        data_tmp <- data.frame(y = y[, i], X[[i]])
        for (j in 1:n_regimes[i])
        {
          ind_g_include_tmp <- which(groups2[, i] == (j - 1))
          ing_g_tmp <- NULL
          for (t in ind_g_include_tmp)
          {
            ing_g_tmp <- c(ing_g_tmp, ind_g[[t]])
          }
          data_tmp_g <- data_tmp[ing_g_tmp, ]
          model_tmp <- lm(y ~ . + 0, data = data_tmp_g[!is.na(data_tmp_g$y) & 
                                                       !is.infinite(data_tmp_g$y), ])
          start[coef2_ind[[i]][j, ]] <- coef(model_tmp)
          start[var_y_ind[[i]][j]] <- sigma(model_tmp) ^ 2
        }
      }
    }
    if (is_marginal)
    {
      for (i in 1:n_eq)
      {
        if ((marginal_names[i] == "PGN") | (marginal_names[i] == "hpa"))
        {
          start[marginal_par_ind[[i]]] <- 1e-8
        }
        if (marginal_names[i] == "student")
        {
          start[marginal_par_ind[[i]]] <- 30
        }
      }
    }
  }

  # Code to test derivatives
  # f0 <- lnL_mvoprobit(par = start,
  #                     W = W_mean, W_var = W_var,
  #                     n_sim = n_sim, n_cores = n_cores,
  #                     control_lnL = control_lnL)
  # grad.a <- lnL_mvoprobit(par = start,
  #                         W = W_mean, W_var = W_var,
  #                         n_sim = n_sim, n_cores = n_cores,
  #                         control_lnL = control_lnL,
  #                         out_type = "grad")
  # grad.n <- rep(NA, n_par)
  # for (i in 1:n_par)
  # {
  #   delta <- 1e-6
  #   start.delta <- start
  #   start.delta[i] <- start[i] + delta
  #   f1 <- lnL_mvoprobit(par = start.delta,
  #                      W = W_mean, W_var = W_var,
  #                      n_sim = n_sim, n_cores = n_cores,
  #                      control_lnL = control_lnL)
  #   grad.n[i] <- (f1 - f0) / delta
  # }
  # return(cbind(as.vector(grad.a), as.vector(grad.n)))
  
  # Perform the optimization routine
  opt <- optim(par = start,
               method = "BFGS",
               fn = lnL_mvoprobit,
               hessian = TRUE,
               gr = grad_mvoprobit,
               control = list(maxit = 10000000,
                              fnscale = -1,
                              reltol = 1e-10),
               W = W_mean, W_var = W_var,
               n_sim = n_sim, n_cores = n_cores,
               control_lnL = control_lnL)

  # Add genetic optimization if need
  if (opt_type == "gena")
  {
    opt <- gena::gena(fn = lnL_mvoprobit,
                      gr = grad_mvoprobit,
                      pop.initial = opt$par,
                      mutation.method = "percent", 
                      maxiter = 100, info = TRUE,
                      lower = -2 * abs(opt$par), 
                      upper = 2 * abs(opt$par),
                      W = W_mean, W_var = W_var,
                      n_sim = n_sim, n_cores = n_cores,
                      hybrid.prob = 0.2,
                      control_lnL = control_lnL)
  }
  
  # Add genetic optimization if need
  if (opt_type == "pso")
  {
    opt <- gena::pso(fn = lnL_mvoprobit,
                     gr = grad_mvoprobit,
                     pop.initial = opt$par,
                     maxiter = 100, info = TRUE,
                     lower = -2 * abs(opt$par), 
                     upper =  2 * abs(opt$par),
                     W = W_mean, W_var = W_var,
                     n_sim = n_sim, n_cores = n_cores,
                     hybrid.prob = 0,
                     control_lnL = control_lnL)
  }

  # Store parameters estimates
  par <- opt$par
  
  # Store parameters
  coef <- vector(mode = "list", length = n_eq)
  coef_var <- vector(mode = "list", length = n_eq)
  cuts <- vector(mode = "list", length = n_eq)
  for (i in 1:n_eq)
  {
    coef[[i]] <- opt$par[coef_ind[[i]]]
    coef_var[[i]] <- opt$par[coef_var_ind[[i]]]
    cuts[[i]] <- opt$par[cuts_ind[[i]]]
  }
  coef2 <- NULL
  var_y <- NULL
  cov_y <- NULL
  if (n_eq2 > 0)
  {
    coef2 <- vector(mode = "list", length = n_eq2)
    var_y <- vector(mode = "list", length = n_eq2)
    cov_y <- vector(mode = "list", length = n_eq2)
    for (i in 1:n_eq2)
    {
      coef2[[i]] <- matrix(nrow = n_regimes[i], ncol = n_coef2[i])
      var_y[[i]] <- opt$par[var_y_ind[[i]]]
      cov_y[[i]] <- matrix(nrow = n_regimes[i], ncol = n_eq)
      for (j in 1:n_regimes[i])
      {
        coef2[[i]][j ,] <- opt$par[coef2_ind[[i]][j ,]]
        cov_y[[i]][j ,] <- opt$par[cov_y_ind[[i]][j ,]]
      }
      rownames(coef2[[i]]) <- paste0("regime ", 0:(n_regimes[i] - 1))
      colnames(coef2[[i]]) <- colnames(X[[i]])
      rownames(cov_y[[i]]) <- paste0("regime ", 0:(n_regimes[i] - 1))
      colnames(cov_y[[i]]) <- 1:n_eq
    }
    names(coef2) <- y_names
  }

  # Store covariance matrix between ordered equations
  sigma <- matrix(NA, nrow = n_eq, ncol = n_eq)
  diag(sigma) <- rep(1, n_eq)
  if (n_eq >= 2)
  {
    sigma_vec <- par[sigma_ind]
    sigma_vec_ind <- matrix(NA, nrow = n_sigma, ncol = 2)
    counter <- 1
    for (i in 2:n_eq)
    {
      for (j in 1:(i - 1))
      {
        sigma_vec_ind[counter, ] <- c(i, j)
        sigma[i, j] <- sigma_vec[counter]
        sigma[j, i] <- sigma[i, j]
        counter <- counter + 1
      }
    }
  }
  
  # Store covariance matrix between continuous equations
  sigma2 <- NULL
  counter <- 1
  if (n_eq2 >= 2)
  {
    sigma2 <- vector(mode = "list", length = n_sigma2)
    for (i in 2:n_eq2)
    {
      for (j in 1:(i - 1))
      {
        sigma2[[counter]] <- opt$par[sigma2_ind[[counter]]]
        counter <- counter + 1
      }
    }
  }
  
  # Store marginal distribution parameters
  marginal_par <- vector(mode = "list", length = n_eq)
  if (is_marginal)
  {
    for (i in 1:n_eq)
    {
      if (marginal_par_n[i] > 0)
      {
        marginal_par[[i]] <- opt$par[marginal_par_ind[[i]]]
      }
    }
  }
  
  # Estimate lambda for sample selection models
  lambda <- lnL_mvoprobit(par = par, 
                          W = W_mean, W_var = W_var,
                          n_sim = n_sim, n_cores = n_cores,
                          control_lnL = control_lnL,
                          out_type = "lambda")
  
  # Estimate asymptotic covariance matrix
  H <- NULL
  H_inv <- NULL
  J <- NULL
  cov <- diag(rep(1, length(par)))
  if (!is.matrix(cov_type))
  {
    if (cov_type != "no")
    {
      if ((cov_type == "sandwich") | (cov_type == "hessian"))
      {
        H <- gena::gena.hessian(gr = lnL_mvoprobit,
                                par = par,
                                gr.args = list(W = W_mean,
                                               W_var = W_var,
                                               n_sim = n_sim, n_cores = n_cores,
                                               control_lnL = control_lnL, 
                                               out_type = "grad"))
        H_inv <- qr.solve(H, tol = 1e-16)
      }
      if ((cov_type == "sandwich") | (cov_type == "GOP"))
      {
        J <- lnL_mvoprobit(par = par,
                           W = W_mean,
                           W_var = W_var,
                           n_sim = n_sim, n_cores = n_cores,
                           control_lnL = control_lnL, 
                           out_type = "jac")
      }
      if (cov_type == "sandwich")
      {
        cov <- H_inv %*% t(J) %*% J %*% H_inv
      }
      if (cov_type == "hessian")
      {
        cov <- -H_inv
      }
      
      if (any(is.na(cov)))
      {
        warning(paste0("Can't calculate covariance matrix of type '", 
                       cov_type, "'. ", 
                       "Therefore GOP covariance matrix will be used instead."))
        cov_type <- "GOP"
      }
      
      if (cov_type == "GOP")
      {
        cov <- qr.solve(t(J) %*% J, tol = 1e-16)
      }
    }
  }
  else
  {
    cov <- cov_type
  }
  se <- sqrt(diag(cov))

  # Calculate p-values
  z_value <- par / se
  p_value <- rep(NA, n_par)
  for (i in 1:n_par)
  {
    p_value[i] <- 2 * min(pnorm(z_value[i]), 1 - pnorm(z_value[i]))
  }
  
  # Construct output table
  tbl_coef <- vector(mode = "list", length = n_eq)
  tbl_coef_var <- vector(mode = "list", length = n_eq)
  tbl_cuts <- vector(mode = "list", length = n_eq)
  tbl_sigma <- vector(mode = "list", length = 1)
  tbl_coef2 <- NULL
  tbl_var_y <- NULL
  tbl_cov_y <- NULL
  tbl_sigma2 <- NULL
  tbl_marginal_par <- NULL
  if (n_eq2 > 0)
  {
    tbl_coef2 <- vector(mode = "list", length = n_eq2)
    tbl_var_y <- vector(mode = "list", length = n_eq2)
    tbl_cov_y <- vector(mode = "list", length = n_eq2)
    tbl_sigma2 <- vector(mode = "list", length = n_eq2 * (n_eq2 - 1) / 2)
  }
  for (i in 1:n_eq)
  {
    # coefficients of mean equation
    tbl_coef[[i]] <- as.matrix(cbind(Estimate = coef[[i]],
                                     Std_Error = se[coef_ind[[i]] ],
                                     z_value = z_value[coef_ind[[i]]],
                                     p_value = p_value[coef_ind[[i]]]))
    rownames(tbl_coef[[i]]) <- colnames(W_mean[[i]])
    names(coef[[i]]) <- colnames(W_mean[[i]])
    # coefficients of variance equation
    if (is_het[i])
    {
      tbl_coef_var[[i]] <- as.matrix(cbind(Estimate = coef_var[[i]],
                                        Std_Error = se[coef_var_ind[[i]] ],
                                        z_value = z_value[coef_var_ind[[i]]],
                                        p_value = p_value[coef_var_ind[[i]]]))
      rownames(tbl_coef_var[[i]]) <- colnames(W_var[[i]])
      names(coef_var[[i]]) <- colnames(W_var[[i]])
    }
    # cuts
    tbl_cuts[[i]] <- as.matrix(cbind(Estimate = cuts[[i]],
                                     Std_Error = se[cuts_ind[[i]]],
                                     z_value = z_value[cuts_ind[[i]]],
                                     p_value = p_value[cuts_ind[[i]]]))
    rownames(tbl_cuts[[i]]) <- paste0("cut", 1:n_cuts_eq[i])
    names(cuts[[i]]) <- rownames(tbl_cuts[[i]])
  }
  # covariance matrix of ordered equations
  tbl_sigma <- NULL
  if (n_eq >= 2)
  {
    sigma_vec_names <- paste0("sigma", sigma_vec_ind[, 1, drop = FALSE], 
                                       sigma_vec_ind[, 2, drop = FALSE])
    tbl_sigma <- as.matrix(cbind(Estimate = par[sigma_ind],
                                 Std_Error = se[sigma_ind],
                                 z_value = z_value[sigma_ind],
                                 p_value = p_value[sigma_ind]))
    rownames(tbl_sigma) <- sigma_vec_names
  }
  # coef2
  if (n_eq2 > 0)
  {
    for (i in 1:n_eq2)
    {
      tbl_coef2[[i]] <- vector(mode = "list", length = n_regimes[i])
      tbl_cov_y[[i]] <- vector(mode = "list", length = n_regimes[i])
      for (j in 1:n_regimes[i])
      {
        tbl_coef2[[i]][[j]] <- as.matrix(cbind(Estimate = coef2[[i]][j, ],
                                               Std_Error = se[coef2_ind[[i]][j, ]],
                                               z_value = z_value[coef2_ind[[i]][j, ]],
                                               p_value = p_value[coef2_ind[[i]][j, ]]))
        rownames(tbl_coef2[[i]][[j]]) <- colnames(X[[i]])
        names(tbl_coef2[[i]]) <- paste0("regime ", 0:(n_regimes[i] - 1))
        
        tbl_cov_y[[i]][[j]] <- as.matrix(cbind(Estimate = cov_y[[i]][j, ],
                                               Std_Error = se[cov_y_ind[[i]][j, ]],
                                               z_value = z_value[cov_y_ind[[i]][j, ]],
                                               p_value = p_value[cov_y_ind[[i]][j, ]]))
        rownames(tbl_cov_y[[i]][[j]]) <- z_names
        names(tbl_coef2[[i]]) <- paste0("regime ", 0:(n_regimes[i] - 1))
      }
      tbl_var_y[[i]] <- as.matrix(cbind(Estimate = var_y[[i]],
                                        Std_Error = se[var_y_ind[[i]]],
                                        z_value = z_value[var_y_ind[[i]]],
                                        p_value = p_value[var_y_ind[[i]]]))
      rownames(tbl_var_y[[i]]) <- rep("var", n_regimes[i])
    }
    names(tbl_coef2) <- paste0("Equation ", 1:n_eq2)
  }
  # Covariances between continuous equations
  if (n_eq2 >= 2)
  {
    counter <- 1
    for (i in 2:n_eq2)
    {
      for (j in 1:(i - 1))
      {
        tbl_sigma2[[counter]] <- as.matrix(cbind(Estimate = sigma2[[counter]],
                                                 Std_Error = se[sigma2_ind[[counter]]],
                                                 z_value = z_value[sigma2_ind[[counter]]],
                                                 p_value = p_value[sigma2_ind[[counter]]]))
        names(tbl_sigma2)[counter] <- paste0(y_names[i], " and ", y_names[j])
        rownames(tbl_sigma2[[counter]]) <- rep("", nrow(tbl_sigma2[[counter]]))
        for (t in 1:nrow(regimes_pair[[counter]]))
        {
          rownames(tbl_sigma2[[counter]])[t] <- paste0("(",
                                                       regimes_pair[[counter]][t, 1], 
                                                       ",",
                                                       regimes_pair[[counter]][t, 2],
                                                       ")")
        }
        counter <- counter + 1
      }
    }
  }
  # marginal_par
  if (is_marginal)
  {
    tbl_marginal_par <- vector(mode = "list", length = n_eq)
    for (i in 1:n_eq)
    {
      if (marginal_par_n[i] > 0)
      {
        tbl_marginal_par[[i]] <- as.matrix(
          cbind(Estimate = marginal_par[[i]],
          Std_Error = se[marginal_par_ind[[i]] ],
          z_value = z_value[marginal_par_ind[[i]]],
          p_value = p_value[marginal_par_ind[[i]]]))
        rownames(tbl_marginal_par[[i]]) <- paste0("par", 1:marginal_par_n[i])
        names(marginal_par[[i]]) <- paste0("par", 1:marginal_par_n[i])
      }
    }
  }

  # Store the output
  out <- list(par = par,
              coef = coef,
              coef_var = coef_var,
              coef2 = coef2,
              sigma = sigma,
              sigma2 = sigma2,
              cuts = cuts,
              marginal_par = marginal_par,
              ind = list(coef = coef_ind,
                         coef_var = coef_var_ind,
                         cuts = cuts_ind,
                         sigma = sigma_ind,
                         g = ind_g,
                         eq = ind_eq,
                         var_y = var_y_ind,
                         sigma2 = sigma2_ind,
                         coef2 = coef2_ind,
                         cov_y = cov_y_ind,
                         sigma2 = sigma2_ind,
                         marginal_par = marginal_par_ind),
              logLik = opt$value,
              W_mean = W_mean,
              W_var = W_var,
              X = X,
              dependent = z,
              control_lnL = control_lnL,
              formula = formula,
              formula2 = formula2,
              lambda = lambda,
              data_list = df,
              data = data[complete_ind, ],
              cov = cov,
              se = se,
              p_value = p_value,
              tbl = list(coef = tbl_coef,
                         coef_var = tbl_coef_var,
                         cuts = tbl_cuts,
                         sigma = tbl_sigma,
                         coef2 = tbl_coef2,
                         var_y = tbl_var_y,
                         cov_y = tbl_cov_y,
                         sigma2 = tbl_sigma2,
                         marginal_par = tbl_marginal_par),
              groups = groups,
              groups2 = groups2,
              var_y = var_y,
              cov_y = cov_y,
              start = start,
              marginal = marginal)
  class(out) <- "mvoprobit"

  return(out)
}

#' Log-likelihood
logLik.mvoprobit <- function (object, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  lnL <- object$logLik
  attr(lnL, "class") <- "logLik"
  attr(lnL, "df") <- length(as.vector(object$par))
  
  return(lnL)
}

#' Summary
summary.mvoprobit <- function(object, ...) 
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  class(object) <- "summary.mvoprobit";
  
  return(object)
}

#' Print summary
print.summary.mvoprobit <- function(object, ...)
{
  class(object) <- "mvoprobit"
  tbl_coef <- object$tbl$coef
  tbl_coef_var <- object$tbl$coef_var
  tbl_sigma <- object$tbl$sigma
  tbl_cuts <- object$tbl$cuts
  tbl_coef2 <- object$tbl$coef2
  tbl_var_y <- object$tbl$var_y
  tbl_cov_y <- object$tbl$cov_y
  tbl_sigma2 <- object$tbl$sigma2
  tbl_marginal_par = object$tbl$marginal_par
  
  n_eq <- object$control_lnL$n_eq
  n_eq2 <- object$control_lnL$n_eq2
  coef_ind <- object$ind$coef
  coef_var_ind <- object$ind$coef_var
  cuts_ind <- object$ind$cuts
  coef2_ind <- object$ind$coef2
  sigma_ind <- object$ind$sigma
  sigma2_ind <- object$ind$sigma2
  var_y_ind <- object$ind$var_y
  cov_y_ind <- object$ind$cov_y
  marginal_par_ind <- object$ind$marginal_par
  n_obs <- object$control_lnL$n_obs
  is_het <- object$control_lnL$is_het
  n_regimes <- object$control_lnL$n_regimes
  
  marginal <- object$marginal
  marginal_par <- object$marginal_par
  marginal_names <- names(marginal)
  is_marginal <- length(marginal) > 0

  cat(paste0(ifelse(n_eq2 == 0, 
                    ifelse(n_eq > 1, "Multivariate ", "Univariate "), 
                    paste0("Selection mechanism is ", 
                           ifelse(n_eq > 1, "multivariate ", "univariate "))),
             ifelse(any(is_het), "heteroscedastic ", ""),
             "ordered ", ifelse(is_marginal, "choice", "probit"), 
             " model\n"))
  if ((n_eq > 1) | (n_eq2 > 0))
  {
    cat(paste0("There are ", n_eq, " ordered ", 
               ifelse(n_eq2 > 0, paste0("and ", n_eq2, " continuous "), ""),
               "equations\n"))
  }
  cat("---\n")
  cat(paste0("Log-likelihood = ", round(object$logLik, 4), "\n"))
  cat(paste0("AIC = ", round(AIC(object), 4), "\n"))
  cat(paste0("Observations = ", n_obs, "\n"))

  stars <- switchSelection::starsVector(object$p_value)

  for (i in 1:n_eq)
  {
    cat("---\n")
    if (n_eq >= 2)
    {
      # cat(paste0("Ordered equation ", i, "\n"))
      cat(paste0(object$formula[[i]][[2]], " equation\n"))
      cat("-\n");
    }
    if (is_marginal)
    {
      cat(paste0("Distribution: ", marginal_names[i], "\n"))
      cat("-\n")
    }
    cat("Coefficients: \n")
    print(as.table(cbind(round(tbl_coef[[i]], 4), 
                         stars[coef_ind[[i]]])))
    if (is_het[i])
    {
      cat("-\n")
      cat("Coefficients of variance equation: \n")
      print(as.table(cbind(round(tbl_coef_var[[i]], 4), 
                           stars[coef_var_ind[[i]]])))
    }
    cat("-\n")
    cat("Cuts: \n")
    print(as.table(cbind(round(tbl_cuts[[i]], 4), 
                         stars[cuts_ind[[i]]])))
    if (length(marginal_par[[i]]) > 0)
    {
      cat("-\n")
      cat(paste0("Parameters of ", marginal_names[i], " distribution: \n"))
      print(as.table(cbind(round(tbl_marginal_par[[i]], 4), 
                           stars[marginal_par_ind[[i]]])))
    }
  }
  
  if (n_eq2 > 0)
  {
    for (i in 1:n_eq2)
    {
      cat("---\n")
      # cat(paste0("Continuous equation ", i, "\n"))
      cat(paste0(object$formula2[[i]][[2]], " equation\n"))
      tbl_var_y[[i]] <- cbind(round(tbl_var_y[[i]], 4), stars[var_y_ind[[i]]])
      for (j in 1:n_regimes[i])
      {
        cat("--\n")
        if (n_regimes[i] > 1)
        {
          cat(paste0("Regime ", j - 1, ":\n"))
          cat("-\n")
        }
        cat("Coefficients:\n")
        print(as.table(cbind(round(tbl_coef2[[i]][[j]], 4), 
                             stars[coef2_ind[[i]][j, ]])))
        cat("-\n")
        cat(paste0("Variance:\n"))
        print(as.table(tbl_var_y[[i]][j, , drop = FALSE]))
        cat("-\n")
        cat(paste0("Covariances with ordered equations:\n"))
        print(as.table(cbind(round(tbl_cov_y[[i]][[j]], 4), 
                             stars[cov_y_ind[[i]][j, ]])))
      }
    }
  }
  
  if (n_eq >= 2)
  {
    cat("---\n")
    cat("Correlations between ordered equations: \n")
    print(as.table(cbind(round(tbl_sigma, 4), 
                         stars[sigma_ind])))
  }
  
  if (n_eq2 >= 2)
  {
    cat("---\n")
    cat("Covariances between continuous equations: \n")
    counter <- 1
    for (i in 2:n_eq2)
    {
      for (j in 1:(i - 1))
      {
        cat("-\n")
        cat(paste0("Between ", object$formula2[[i]][[2]], 
                   " and ", object$formula2[[j]][[2]], "\n"))
        print(as.table(cbind(round(tbl_sigma2[[counter]], 4), 
                             stars[sigma2_ind[[counter]]])))
        counter <- counter + 1
      }
    }
  }
  
  cat("---\n")
  cat("Signif. codes:  0 '***' 0.01 '**' 0.05 '*' 0.1 \n")
}

#' Print
print.mvoprobit <- function(object, ...)
{
  print.summary.mvoprobit(object)
}

#' Predict method for mvoprobit function
#' @description Predicted values based on object of class 'mvoprobit'.
#' @param object object of class "mvoprobit"
#' @param ... further arguments (currently ignored)
#' @param newdata an optional data frame in which to look for variables 
#' with which to predict. If omitted, the original data frame used.
#' This data frame should contain values of dependent variables even if
#' they are not actually needed for prediction 
#' (simply assign them with 0 values).
#' @param given_ind numeric vector of indexes of conditioned components.
#' @param group numeric vector which i-th element represents value of the
#' i-th dependent variable. If this value equals -1 then this component
#' will be ignored (useful for estimation of marginal probabilities).
#' @param type string representing a type of prediction. See 'Details' for
#' more information.
#' @param me string representing the name of the variable for which marginal
#' effect should be estimated. See 'Details' for more information.
#' @param eps numeric vector of length 1 or 2 used for calculation of
#' marginal effects. See 'Details'.
#' @details See 'Examples' section of \code{\link[switchSelection]{mvoprobit}}
#' for examples of this function application.
#' 
#' If \code{type = "prob"} then function returns a joint probability that
#' dependent variables will have values assigned in \code{group}. To calculate
#' marginal probabilities set unnecessary \code{group} values to -1. To
#' estimate conditional probabilities provide indexes of conditioned variables
#' through \code{given_ind}. For example if \eqn{z_{1}}, \eqn{z_{2}} and 
#' \eqn{z_{3}} are dependent variables then to calculate 
#' \eqn{P(z_{1}=2 | z_{3} = 0)} set \code{given_ind = 3} and 
#' \code{groups = c(2, -1, 0)}. Note that conditioning on covariates 
#' (regressors) is omitted for notations brevity and this conditioning depends 
#' on the values in \code{newdata}.
#' 
#' If \code{type = "li"} then function returns a matrix which columns are
#' linear indexes of corresponding equations.
#' 
#' If \code{type = "sd"} then function returns a matrix which columns are
#' standard deviations of random errors for corresponding equations. 
#' 
#' If \code{type = "li"} or \code{type = "sd"} and some \code{groups} are equal
#' to -1 then corresponding components will be omitted from the output matrix.
#' 
#' If \code{me} is provided then the function returns marginal effect
#' of variable \code{me} respect to the statistic determined by \code{type}
#' argument. 
#' For example if \code{me = "x1"} and \code{type = "prob"} then function 
#' returns marginal effect of \code{x1} on the corresponding probability 
#' i.e. one that would be estimated if \code{me} is \code{NULL}.
#' 
#' If \code{length(eps) = 1} then \code{eps} is an increment in 
#' numeric differentiation procedure. 
#' If \code{eps} is \code{NULL} then this increment will be selected 
#' automatically taking into account scaling of variables. 
#' If \code{length(eps) = 2} then marginal effects will be estimated as the
#' difference of predicted value when variable \code{me} equals \code{eps[2]}
#' and \code{eps[1]} correspondingly. 
#' 
#' For example suppose that 
#' \code{type = "prob"}, \code{me = "x1"}, \code{given_ind = 3} and
#' \code{groups = c(2, -1, 0)}. Then if \code{eps} is a \code{NULL} or a 
#' small number (something like \code{eps = 0.0001}) the following marginal
#' effect will be estimated (via first difference numeric differentiation):
#'  \deqn{\frac{\partial P(z_{1}=2 | z_{3} = 0)}{\partial x_{1}}.}
#'  If \code{eps = c(1, 3)} then the function estimates the following difference
#'  (useful for estimation of marginal effects of ordered covariates):
#'  \deqn{P(z_{1}=2 | z_{3} = 0, x_{1} = 3) - 
#'       P(z_{1}=2 | z_{3} = 0, x_{1} = 1).}
#'
#' 
#' @returns This function returns a predictions for each row of \code{newdata}
#' or for each observation in the model if \code{newdata} is \code{NULL}.
#' Structure of the output depends on the \code{type} argument
#' (see 'Details' section).
predict.mvoprobit <- function(object, ..., 
                              newdata = NULL, 
                              given_ind = numeric(),
                              group = NULL,
                              group2 = NULL,
                              type = "prob",
                              me = NULL,
                              eps = NULL)
{
  # For continuous variables
  if (!is.null(group2))
  {
    # Get data
    if (is.null(newdata))
    {
      W_mean <- as.matrix(object$W_mean)
      W_var <- as.matrix(object$W_var)
      X <- object$X
    }
    else
    {
      if (is.data.frame(newdata))
      {
        newdata <- switchSelection::mvoprobit(formula = object$formula, 
                                              data = newdata, 
                                              control = list(out_type = "data"))
      }
      W_mean <- as.matrix(newdata$W_mean)
      W_var <- as.matrix(newdata$W_var)
      X <- newdata$X
    }
    
    # Prepare matrix to store predictions
    y_pred <- matrix(NA, nrow = nrow(W_mean[[1]]), ncol = length(group2))
    
    # Part for conditional prediction if need
    if (!is.null(group))
    {
      lambda <- predict(object, ..., newdata = newdata,
                        given_ind = given_ind, group = group,
                        type = "lambda")
    }
    
    # Unconditional predictions
    for (i in 1:length(group2))
    {
      if (group2[i] != -1)
      {
        X_i <- as.matrix(X[[i]])
        y_pred[, i] <- X_i %*% matrix(model$coef2[[i]][group2[i] + 1, ], 
                                      ncol = 1)
        # conditional predictions (on ordered equations)
        if (!is.null(group))
        {
          y_pred[, i] <- y_pred[, i] + lambda %*% 
                                       matrix(object$cov_y[[i]][group2[i] + 1, ], 
                                              ncol = 1)
        }
      }
    }
    
    # Return prediction for continuous equation
    return(y_pred)
  }

  # Calculation of marginal effects
  if (!is.null(me))
  {
    # If several marginal effects should be calculated
    n_me <- length(me)
    if (n_me > 1)
    {
      list_return <- list()
      for (i in 1:n_me)
      {
        list_return[[me[i]]] <- predict(object, ..., newdata = newdata,
                                        given_ind = given_ind, group = group,
                                        type = type, me = me[i], eps = eps)
      }
      return(list_return)
    }
    # Prepare data
    if (is.null(newdata))
    {
      newdata <- object$data
    }
    else
    {
      newdata <- switchSelection::mvoprobit(formula = object$formula, 
                                            data = newdata, 
                                            control = list(out_type = "data"))
      newdata <- newdata$data
    }
    
    # Determine the type of marginal effect
    is_discrete <- length(eps) > 1
    
    # Adjust epsilon if need
    if (is.null(eps))
    {
      eps <- newdata[[me]] * sqrt(.Machine$double.eps)
    }
    
    # Calculate values before and after
    if (is_discrete)
    {
      newdata[me] <- eps[1]
    }
    p0 <- predict.mvoprobit(object, 
                            newdata = newdata,
                            given_ind = given_ind,
                            group = group,
                            type = type,
                            me = NULL)
    if (is_discrete)
    {
      newdata[me] <- eps[2]
    }
    else
    {
      newdata[me] <- newdata[me] + eps
    }
    p1 <- predict.mvoprobit(object, 
                            newdata = newdata,
                            given_ind = given_ind,
                            group = group,
                            type = type,
                            me = NULL)
    
    # Estimate marginal effect
    val <- p1 - p0
    if (!is_discrete)
    {
      val <- val / eps
    }
    return(val)
  }
  
  # Assign group value for some types of return value
  if (((type == "li") | (type == "sd")) & is.null(group))
  {
    group <- rep(1, object$control_lnL$n_eq)
  }
  
  # Store the data
  W_mean <- NULL
  W_var <- NULL
  if (is.null(newdata))
  {
    W_mean <- as.matrix(object$W_mean)
    W_var <- as.matrix(object$W_var)
  }
  else
  {
    if (is.data.frame(newdata))
    {
      newdata <- switchSelection::mvoprobit(formula = object$formula, 
                                            data = newdata, 
                                            control = list(out_type = "data"))
    }
    W_mean <- as.matrix(newdata$W_mean)
    W_var <- as.matrix(newdata$W_var)
  }
  n_obs <- nrow(W_mean[[1]])

  # Return marginal probabilities for each equation
  # if there is no particular group
  if (is.null(group))
  {
    n_obs <- object$control_lnL$n_obs
    n_eq <- object$control_lnL$n_eq
    prob <- matrix(NA, nrow = n_obs, ncol = n_eq)
    colnames(prob) <- paste0("P(y", 1:n_eq, "=1)")
    group <- rep(-1, n_eq)
    
    for (i in 1:n_eq)
    {
      group[i] <- 1
      prob[, i] <- predict(object, 
                           newdata = newdata, 
                           type = "prob",
                           group = group)
      group[i] <- -1
    }
    
    return(prob)
  }
  
  # Some additional variables
  is_eq <- group != -1
  ind_eq <- which(is_eq)
  ind_eq_omit <- which(!is_eq)
  n_eq_g <- length(ind_eq)
  
  # Validation
  if (length(given_ind) >= n_eq_g)
  {
    stop(paste("At least one component should be unconditioned.",
               "Please, insure that 'length(given_ind)' is smaller than",
               "the number of observable equations."))
  }
  
  # Calculate conditional probabilities if need
  if (length(given_ind) > 0)
  {
    if (type != "prob")
    {
      warning(passte("Since 'given_ind' has been provided then 'type'",
                     "will be coerced to 'prob'."))
    }
    
    group_given <- group
    group_given[-given_ind] <- -1

    p_intersection <- predict(object, 
                              newdata = newdata, 
                              type = "prob",
                              group = group)
    p_given <- predict(object, 
                       newdata = newdata, 
                       type = "prob",
                       group = group_given)

    return(p_intersection / p_given)
  }

  # Get some variables from the model
  coef <- object$coef
  coef_var <- object$coef_var
  sigma <- object$sigma
  cuts <- object$cuts
  control_lnL <- object$control_lnL
  n_eq <- control_lnL$n_eq
  n_cuts_eq <- control_lnL$n_cuts_eq
  is_het <- control_lnL$is_het
  
  # Calculate linear index
  li_lower <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_upper <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_mean <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_var <- matrix(1, nrow = n_obs, ncol = n_eq_g)
  for (i in 1:n_eq_g)
  {
    # Calculate linear indexes for mean and variance parts
    li_mean[, i] <- W_mean[[ind_eq[i]]] %*% coef[[ind_eq[i]]]
    if (is_het[ind_eq[i]])
    {
      li_var[, i] <- exp(W_var[[ind_eq[i]]] %*% coef_var[[ind_eq[i]]])
    }
    # Adjust lower limits for cuts and heteroscedasticity
    if (group[ind_eq[i]] != 0)
    {
      li_lower[, i] <- cuts[[ind_eq[i]]][group[ind_eq[i]]] - 
                       li_mean[, i]
      if (is_het[ind_eq[i]])
      {
        li_lower[, i] <- li_lower[, i, drop = FALSE] / 
                         li_var[, i, drop = FALSE]
      }
    }
    else
    {
      li_lower[, i] <- -Inf
    }
    # Adjust upper limits for cuts and heteroscedasticity
    if (group[ind_eq[i]] != n_cuts_eq[[ind_eq[i]]])
    {
      li_upper[, i] <- cuts[[ind_eq[i]]][group[ind_eq[i]] + 1] - 
                       li_mean[, i, drop = FALSE]
      if (is_het[ind_eq[i]])
      {
        li_upper[, i] <- li_upper[, i, drop = FALSE] / 
                         li_var[, i, drop = FALSE]
      }
    }
    else
    {
      li_upper[, i] <- Inf
    }
  }

  # Return linear indexes if need
  if (type == "li")
  {
    return(li_mean)
  }
  
  # Return standard deviations if need
  if (type == "sd")
  {
    return(li_var)
  }

  # Get covariance matrix
  sigma_g <- sigma[ind_eq, ind_eq, drop = FALSE]
  if (type == "prob")
  {
    # Calculate probabilities
    prob <- mnorm::pmnorm(lower = li_lower, upper = li_upper, 
                          mean = rep(0, n_eq_g), sigma = sigma_g)$prob
    return(prob)
  }
  
  if (type == "lambda")
  {
    # Calculate lambdas for conditional expectations
    grads <- mnorm::pmnorm(lower = li_lower, upper = li_upper, 
                           mean = rep(0, n_eq_g), sigma = sigma_g,
                           log = TRUE, 
                           grad_upper = TRUE, grad_lower = TRUE)
    lambda <- grads$grad_upper - grads$grad_lower
    #lambda <- sweep(lambda, MARGIN = 2, (2 * group[ind_eq] - 1), `*`)
    return(lambda)
  }
  
  stop("Wrong 'type' argument.")
}