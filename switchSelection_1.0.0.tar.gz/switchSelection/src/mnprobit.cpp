// [[Rcpp::depends(mnorm)]]
#include <RcppArmadillo.h>
#include <mnorm.h>
using namespace Rcpp;

// [[Rcpp::plugins(openmp)]]

//' Log-likelihood function of multinomial probit model
//' @description Calculates log-likelihood function of multinomial probit model
//' @export
// [[Rcpp::export(rng = false)]]
double lnL_mnprobit(const arma::vec par,
                    const arma::vec z,
                    const arma::vec alt,
                    const arma::mat W,
                    const int n_sim,
                    const int n_cores,
                    const List control_lnL)
{
  // Multiple cores
  omp_set_num_threads(n_cores);
  
  // Get some dimensional data
  const int n_par = control_lnL["n_par"];
  const int n_alt = control_lnL["n_alt"];
  const int n_obs = control_lnL["n_obs"];
  const int n_coef = control_lnL["n_coef"];
  const int n_coef_total = control_lnL["n_coef_total"];
  const int n_sigma = control_lnL["n_sigma"];

  // Determine indexes of coefficients and 
  // covariances in the vector of parameters
  const arma::uvec coef_ind = control_lnL["coef_ind"];
  const arma::uvec sigma_ind = control_lnL["sigma_ind"];

  // Store the coefficients for each alternative
  arma::vec coef_vec = par.elem(coef_ind);
  arma::mat coef(n_coef, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++) 
  {
    coef.col(i) = coef_vec.subvec(i * n_coef, (i + 1) * n_coef - 1);
  }
  
  // Construct the covariance matrix
  arma::vec sigma_vec = par.elem(sigma_ind);
  arma::mat sigma(n_alt - 1, n_alt - 1);
  sigma(0, 0) = 1;
  if (n_alt > 2)
  {
    int counter = 0;
    for (int i = 0; i < (n_alt - 1); i++)
    {
      for (int j = 0; j <= i; j++)
      {
        if (!((i == 0) & (j == 0)))
        {
          sigma.at(i, j) = sigma_vec.at(counter);
          sigma.at(j, i) = sigma.at(i, j);
          counter++;
        }
      }
    }
  }

  // Check that matrix is positive defined
  if(!sigma.is_sympd())
  {
    return(-(1e+100));
  }
  
  // Vector of zero means
  NumericVector mean_zero_R(n_alt - 1);
  
  // Estimate the linear index for each alternative
  arma::mat li(n_obs, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++)
  {
    li.col(i) = W * coef.col(i);
  }

  // Vector to store log-likelihood information
  arma::vec lnL(n_obs);

  // Calculate log-likelihood depending on the alternative
  for (int i = 0; i < n_alt; i++)
  {
    // Get indexes of observations related
    // to the alternative
    arma::uvec alt_ind = find(z == alt.at(i));
    int n_alt_obs = alt_ind.size();
    
    // Transformation matrix
    arma::mat transform_mat(n_alt, n_alt);
    transform_mat.diag().ones();
    
    if (i != (n_alt - 1))
    {
      transform_mat.col(i).ones();
      transform_mat.col(i) = -transform_mat.col(i);
    }
    transform_mat.shed_row(i);
    transform_mat.shed_col(n_alt - 1);
    
    // Construct covariance matrix for alternative
    arma::mat sigma_alt = transform_mat * sigma * transform_mat.t();
    NumericMatrix sigma_alt_R = wrap(sigma_alt);
    
    // Estimate all necessary differences in utilities
    // related to linear indexes
    arma::mat li_diff = arma::mat(n_alt_obs, n_alt - 1);
    if (i == (n_alt - 1))
    {
      li_diff = -li.rows(alt_ind);
    }
    else
    {
      arma::uvec i_uvec = {i};
      li_diff.col(n_alt - 2) = li.submat(alt_ind, i_uvec);        
      int counter = 0;
      for (int j = 0; j < (n_alt - 1); j++)
      {
        arma::uvec j_uvec = {j};
        if (i != j)
        {
          li_diff.col(counter) = li.submat(alt_ind, i_uvec) - 
            li.submat(alt_ind, j_uvec);
          counter++;
        }
      }
    }
    NumericMatrix li_diff_R = wrap(li_diff);
    
    // Matrix of negative infinite values
    NumericMatrix lower_neg_inf(n_alt_obs, n_alt - 1);
    std::fill(lower_neg_inf.begin(), lower_neg_inf.end(), R_NegInf);
    
    // Calculate probabilities
    List prob_list = mnorm::pmnorm(lower_neg_inf, li_diff_R,
                                   NumericVector(), 
                                   mean_zero_R, sigma_alt_R,
                                   NumericVector(),
                                   n_sim, "default", "NO", true,
                                   false, false, false, false,
                                   false, R_NilValue, n_cores,
                                   CharacterVector());
    arma::vec prob_tmp = prob_list["prob"];
    lnL.elem(alt_ind) = prob_tmp;
  }

  return(sum(lnL));
}

//' Gradient of the log-likelihood function of multinomial probit model
//' @description  Calculates gradient of the log-likelihood function of 
//' multinomial probit model
//' @export
// [[Rcpp::export(rng = false)]]
NumericVector grad_mnprobit(const arma::vec par,
                            const arma::vec z,
                            const arma::vec alt,
                            const arma::mat W,
                            const int n_sim,
                            const int n_cores,
                            const List control_lnL)
{
  // Multiple cores
  omp_set_num_threads(n_cores);
  
  // Get some dimensional data
  const int n_par = control_lnL["n_par"];
  const int n_alt = control_lnL["n_alt"];
  const int n_obs = control_lnL["n_obs"];
  const int n_coef = control_lnL["n_coef"];
  const int n_coef_total = control_lnL["n_coef_total"];
  const int n_sigma = control_lnL["n_sigma"];
  
  // Determine indexes of coefficients and 
  // covariances in the vector of parameters
  const arma::uvec coef_ind = control_lnL["coef_ind"];
  const arma::uvec sigma_ind = control_lnL["sigma_ind"];

  // Vector to store Jacobian
  arma::mat jac(n_obs, n_par);
  
  // Store the coefficients for each alternative
  arma::vec coef_vec = par.elem(coef_ind);
  arma::mat coef(n_coef, n_alt - 1);
  arma::umat coef_ind_alt = control_lnL["coef_ind_alt"];
  for (int i = 0; i < (n_alt - 1); i++) 
  {
    coef.col(i) = coef_vec.elem(coef_ind_alt.col(i));
  }

  // Store indexes of worse alternatives for each best alternative
  arma::umat worse_ind(n_alt - 1, n_alt);
  for (int i = 0; i < n_alt; i++) 
  {
    int counter = 0;
    for (int j = 0; j < n_alt; j++) 
    {
      if (i != j)
      {
        worse_ind.at(counter, i) = j;
        counter++;
      }
    }
  }
  
  // Construct the covariance matrix
  arma::vec sigma_vec = par.elem(sigma_ind);
  arma::mat sigma(n_alt - 1, n_alt - 1);
  arma::mat sigma_ind_mat(n_sigma, 2);
  sigma(0, 0) = 1;
  if (n_alt > 2)
  {
    int counter = 0;
    for (int i = 0; i < (n_alt - 1); i++)
    {
      for (int j = 0; j <= i; j++)
      {
        if (!((i == 0) & (j == 0)))
        {
          sigma.at(i, j) = sigma_vec.at(counter);
          sigma.at(j, i) = sigma.at(i, j);
          sigma_ind_mat.at(counter, 0) = i;
          sigma_ind_mat.at(counter, 1) = j;
          counter++;
        }
      }
    }
  }

  // Check that matrix is positive defined
  if(!sigma.is_sympd())
  {
    NumericVector grad_error(n_par);
    grad_error.fill(-(1e+100));
    return(grad_error);
  }
  
  // Vector of zero means
  NumericVector mean_zero_R(n_alt - 1);
  
  // Estimate the linear index for each alternative
  arma::mat li(n_obs, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++)
  {
    li.col(i) = W * coef.col(i);
  }

  // Calculate log-likelihood dependentin on alternative
  for (int i = 0; i < n_alt; i++)
  {
    // Get indexes of observations related
    // to the alternative
    arma::uvec alt_ind = find(z == alt.at(i));
    int n_alt_obs = alt_ind.size();
    
    // Transformation matrix
    arma::mat transform_mat(n_alt, n_alt);
    transform_mat.diag().ones();
    
    if (i != (n_alt - 1))
    {
      transform_mat.col(i).ones();
      transform_mat.col(i) = -transform_mat.col(i);
    }
    transform_mat.shed_row(i);
    transform_mat.shed_col(n_alt - 1);
    
    // Construct covariance matrix for alternative
    arma::mat sigma_alt = transform_mat * sigma * transform_mat.t();
    NumericMatrix sigma_alt_R = wrap(sigma_alt);
    
    // Estimate all necessary differences in utilities
    // related to linear indexes
    arma::mat li_diff = arma::mat(n_alt_obs, n_alt - 1);
    if (i == (n_alt - 1))
    {
      li_diff = -li.rows(alt_ind);
    }
    else
    {
      arma::uvec i_uvec = {i};
      li_diff.col(n_alt - 2) = li.submat(alt_ind, i_uvec);        
      int counter = 0;
      for (int j = 0; j < (n_alt - 1); j++)
      {
        arma::uvec j_uvec = {j};
        if (i != j)
        {
          li_diff.col(counter) = li.submat(alt_ind, i_uvec) - 
            li.submat(alt_ind, j_uvec);
          counter++;
        }
      }
    }
    NumericMatrix li_diff_R = wrap(li_diff);

    // Matrix of negative infinite values
    NumericMatrix lower_neg_inf(n_alt_obs, n_alt - 1);
    std::fill(lower_neg_inf.begin(), lower_neg_inf.end(), R_NegInf);

    // Calculate probabilities
    List prob_list = mnorm::pmnorm(lower_neg_inf, li_diff_R,
                                   NumericVector(), 
                                   mean_zero_R, sigma_alt_R,
                                   NumericVector(),
                                   n_sim, "default", "NO", true,
                                   false, true, true, false,
                                   false, R_NilValue, n_cores,
                                   CharacterVector());
    arma::mat grad_upper = prob_list["grad_upper"];
    arma::cube grad_sigma = prob_list["grad_sigma"];

    // Estimate the Jacobian for the coefficients
      // for the first (n_alt - 1) alternatives
    if (i < (n_alt - 1))
    {
      for (int i1 = 0; i1 < (n_alt - 1); i1++)
      {
        for (int j1 = 0; j1 < n_coef; j1++)
        {
          arma::uvec j1_uvec = {j1};
          arma::uvec  coef_ind_alt_uvec = {coef_ind_alt.at(j1, i)};
          jac.submat(alt_ind, coef_ind_alt_uvec) = 
            jac.submat(alt_ind, coef_ind_alt_uvec) + 
            grad_upper.col(i1) % W.submat(alt_ind, j1_uvec);
        }
      }

      for (int i1 = 0; i1 < (n_alt - 2); i1++)
      {
        int worse_ind_i1 = worse_ind.at(i1, i);
        for (int j1 = 0; j1 < n_coef; j1++)
        {
          arma::uvec j1_uvec = {j1};
          arma::uvec  coef_ind_alt_uvec = {coef_ind_alt.at(j1, worse_ind_i1)};
          jac.submat(alt_ind, coef_ind_alt_uvec) = 
            jac.submat(alt_ind, coef_ind_alt_uvec) -
            grad_upper.col(i1) % W.submat(alt_ind, j1_uvec);
        }
      }
    }
      // for the last alternative
    else
    {
      for (int i1 = 0; i1 < (n_alt - 1); i1++)
      {
        for (int j1 = 0; j1 < n_coef; j1++)
        {
          arma::uvec j1_uvec = {j1};
          arma::uvec  coef_ind_alt_uvec = {coef_ind_alt.at(j1, i1)};
          jac.submat(alt_ind, coef_ind_alt_uvec) = 
            jac.submat(alt_ind, coef_ind_alt_uvec) -
            grad_upper.col(i1) % W.submat(alt_ind, j1_uvec);
        }
      }
    }
    
    // Estimate the Jacobian for the covariances
    for (int i1 = 0; i1 < n_sigma; i1++)
    {
      arma::uvec sigma_ind_uvec_i1 = {sigma_ind(i1)};
      arma::mat sigma_alt_diff(n_alt - 1, n_alt - 1);
      sigma_alt_diff.at(sigma_ind_mat.at(i1, 0), sigma_ind_mat.at(i1, 1)) = 1;
      sigma_alt_diff.at(sigma_ind_mat.at(i1, 1), sigma_ind_mat.at(i1, 0)) = 1;
      sigma_alt_diff = transform_mat * sigma_alt_diff * transform_mat.t();
      for (int j1 = 0; j1 < (n_alt - 1); j1++)
      {
        arma::uvec j1_uvec = {j1};
        for (int j2 = 0; j2 <= j1; j2++)
        {
          arma::uvec j2_uvec = {j2};
          if (sigma_alt_diff.at(j1, j2) != 0)
          {
            arma::vec mat_tmp = grad_sigma.tube(j1, j2);
            jac.submat(alt_ind, sigma_ind_uvec_i1) = 
              jac.submat(alt_ind, sigma_ind_uvec_i1) + 
              mat_tmp * sigma_alt_diff.at(j1, j2);
          }
        }
      }
    }
  }

  // Agregate the Jacobian into the gradient
  arma::rowvec grad = sum(jac, 0);

  return(wrap(grad));
}
