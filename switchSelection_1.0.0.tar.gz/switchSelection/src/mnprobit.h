#ifndef switchSelection_mnprobit_H
#define switchSelection_mnprobit_H

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace RcppArmadillo;

double lnL_mnprobit(const arma::vec par,
                    const arma::vec z,
                    const arma::vec y_unique,
                    const arma::mat W,
                    const int n_sim,
                    const int n_cores,
                    const List control_lnL);

NumericVector grad_mnprobit(const arma::vec par,
                            const arma::vec z,
                            const arma::vec y_unique,
                            const arma::mat W,
                            const int n_sim,
                            const int n_cores,
                            const List control_lnL);

#endif
