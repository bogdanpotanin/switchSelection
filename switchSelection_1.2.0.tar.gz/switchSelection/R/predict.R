# ---------------------------------------------------------------------
# mvoprobit
# ---------------------------------------------------------------------

#' Predict method for mvoprobit function
#' @description Predicted values based on object of class 'mvoprobit'.
#' @template predict.mvoprobit_param_Template
#' @template predict.mvoprobit_details_Template
#' @template predict.mvoprobit_return_Template
predict.mvoprobit <- function(object, ..., 
                              newdata   = NULL, 
                              given_ind = numeric(),
                              group     = NULL,
                              group2    = NULL,
                              type      = ifelse(is.null(group2), 
                                                 "prob", "val"),
                              me        = NULL,
                              eps       = NULL,
                              control   = list(),
                              se        = FALSE,
                              exogenous = NULL)
{
  # -------------------------------------------------------
  # Deal with data and variables
  # -------------------------------------------------------

  # Get some values
  groups    <- object$groups
  groups2   <- object$groups2
  ind_g     <- object$other$ind_g
  ind_eq    <- object$other$ind_eq
  n_par     <- length(object$par)
  n_eq      <- object$other$n_eq
  is2       <- object$other$is2
  n_eq2     <- 0
  if (is2)
  {
    n_eq2 <- object$other$n_eq2
  }
  n_groups  <- object$other$n_groups
  estimator <- object$estimator
  
  # Provide 'data' as 'newdata' if need
  is_newdata <- TRUE
  if (is.null(newdata))
  {
    is_newdata <- FALSE
    newdata    <- object$data
  }
  
  # Deal with 'exogenous' argument
  n_exogenous  <- length(exogenous)
  is_exogenous <- n_exogenous > 0
  if (is_exogenous)
  {
    newdata    <- exogenous_fn(exogenous = exogenous, newdata = newdata)
    is_newdata <- TRUE
  }
  
  # Adjust data to appropriate format i.e., remove missing values and so on
  # without addressing for lambda variables
  newdata_tmp <- object
  if (is_newdata)
  {
    newdata_tmp <- switchSelection::mvoprobit(
      formula   = object$formula,
      formula2  = object$formula2, 
      data      = newdata, 
      estimator = estimator,
      control   = list(out_type = ifelse(is.null(group), "data_ind", "data"),
                       is_1step = FALSE))
  }

  # Recalculate lambda for two-step estimator
  # to plug it into the data if need
  if ((type == "val") & (estimator == "2step"))
  {
    lambda_tmp <- predict(object, group = group, type = "lambda",
                          newdata = newdata_tmp$data)
    newdata_tmp <- switchSelection::mvoprobit(
      formula   = object$model1, 
      formula2  = object$formula2,
      data      = newdata_tmp$data, 
      estimator = estimator,
      control   = list(out_type = ifelse(is.null(group) | is.null(group2), 
                                         "data_ind", "data"),
                       lambda = lambda_tmp))
  }
  newdata <- newdata_tmp$data
  
  # Split 'newdata' according to 'formula' and 'formula2'
  W_mean <- newdata_tmp$W_mean
  W_var  <- newdata_tmp$W_var
  X      <- newdata_tmp$X
  y      <- newdata_tmp$dependent2
  
  # Get the number of observations
  n_obs <- newdata_tmp$other$n_obs
  
  # Get information on marginal distributions
  marginal    <- object$marginal
  is_marginal <- length(object$marginal) > 0
  
  # Transform marginal argument into mnorm format
  marginal_mnorm <- object$marginal
  if (is_marginal)
  {
    for (i in 1:n_eq)
    {
      if (length(object$marginal_par[[i]]) > 0)
      {
        marginal_mnorm[[i]] <- object$marginal_par[[i]]
      }
    }
  }
  
  # Adjust for marginal distributions of observable equations only
  marginal_mnorm_g <- marginal_mnorm
  if (is_marginal)
  {
    marginal         <- marginal[ind_eq]
    marginal_mnorm_g <- marginal_mnorm[ind_eq]
  }
  
  # Get estimates of the parameters and some related variables
  coef        <- object$coef
  coef_var    <- object$coef_var
  sigma       <- object$sigma
  cuts        <- object$cuts
  control_lnL <- object$control_lnL
  sigma_omit  <- control_lnL$sigma_omit
  n_eq        <- control_lnL$n_eq
  n_cuts_eq   <- control_lnL$n_cuts_eq
  is_het      <- control_lnL$is_het
  
  # -------------------------------------------------------
  # Calculate standard errors
  # -------------------------------------------------------
  
  # Deal with the output
  se_fn <- NULL
  if (!is.logical(se))
  {
    se_fn <- se
    se    <- TRUE
  }
  
  # Estimation of standard errors
  if (se)
  {
    # Get arguments of the function and change 'se'
    # argument to false to prevent eternal cycle
    predict_args         <- c(as.list(environment()), list(...))
    predict_args$newdata <- newdata
    predict_args$se      <- FALSE

    # Apply delta method
    predict_fn <- function(object)
    {
      predict_args$object <- object
      val <- do.call(what = predict.mvoprobit, args = predict_args)
      if (!is.null(se_fn))
      {
        if (is.function(se_fn))
        {
          val <- se_fn(val)
        }
        else
        {
          val <- val[, se_fn]
        }
      }
      return(val)
    }
    out <- delta_method(object = object, fn = predict_fn)
    
    return(out)
  }
  
  # -------------------------------------------------------
  # Calculate value with data-driven groups
  # -------------------------------------------------------
  
  # Estimate the value
  if (is.null(group))
  {
    # Get some variables
    groups   <- newdata_tmp$groups
    n_groups <- newdata_tmp$other$n_groups
    if (n_eq2 == 0)
    {
      group2 <- NA
    }
    if (!is.null(group2))
    {
      groups2 <- matrix(rep(group2, n_groups), nrow = n_groups, byrow = TRUE)
    }
    else
    {
      if (is_newdata)
      {
        groups2 <- newdata_tmp$groups2
      }
      else
      {
        groups2 <- object$groups2
      }
    }
    ind_g  <- newdata_tmp$other$ind_g
    ind_eq <- newdata_tmp$other$ind_eq
    
    # Calculate the value for all groups and
    # aggregate the result
    val <- NULL
    if (n_groups > 1)
    {
      for (i in 1:n_groups)
      {
        val_tmp <- predict(object, 
                           newdata = newdata[ind_g[[i]], ],
                           group   = groups[i, ],
                           group2  = groups2[i, ],
                           type    = type)
        if (i == 1)
        {
          val           <- matrix(0, nrow = n_obs, ncol = ncol(val_tmp))
          colnames(val) <- colnames(val_tmp)
        }
        val[ind_g[[i]], ] <- val_tmp
      }
    }
    return(val)
  }
  
  # Remove 'newdata_tmp'
  newdata_tmp <- NULL
  
  # -------------------------------------------------------
  # Validation
  # -------------------------------------------------------
  
  # group
  if (!is.null(group))
  {
    if (any((group %% 1) != 0))
    {
      stop(paste0("Invalid 'group' argument. Please, insure that 'group' is ",
                  "a vector of integers.\n"))
    }
    if (length(group) != n_eq)
    {
      stop(paste0("Invalid 'group' argument. Please, insure that length ",
                  "of 'group' equals to the number of ordered equations i.e. ",
                  "'length(group) == length(formula)'.\n"))
    }
    if (any(group < -1))
    {
      stop(paste0("Invalid 'group' argument. Please, insure that it ", 
                  "does not contain any negative values other than -1.\n"))
    }
    if (any(group >= n_groups))
    {
      stop(paste0("Invalid 'group' argument. Please, insure that it ", 
                  "does not contain any values greater than the number of ", 
                  "the maximum category of corresponding equation.\n"))
    }
  }
  
  # group2
  if (is2 & (type == "val") & !is.null(group) & is.null(group2))
  {
    group2 <- rep(0, n_eq2)
    warning(paste0("It is assumed that 'group2' is a vector of zeros.\n"))
  }
  if (is2 & !is.null(group2) & (length(group2) != n_eq2))
  {
    stop(paste0("Invalid 'group2' argument. ",
                "It should be a vector of length ", n_eq2, ".\n"))
  }
  
  # control
  is_scores <- FALSE
  if (hasName(control, "is_scores"))
  {
    is_scores <- control$is_scores
  }
  
  # Some additional variables
  is_eq       <- group != -1
  ind_eq      <- which(is_eq)
  ind_eq_omit <- which(!is_eq)
  n_eq_g      <- length(ind_eq)
  y_names     <- object$other$y_names
  
  # -------------------------------------------------------
  # Conditional probabilities
  # -------------------------------------------------------
  
  # Calculate conditional probabilities
  if (length(given_ind) > 0)
  {
    if (length(given_ind) >= n_eq_g)
    {
      stop(paste("At least one component should be unconditioned.",
                 "Please, insure that 'length(given_ind)' is smaller than",
                 "the number of observable equations."))
    }
    
    if (type != "prob")
    {
      warning(paste0("Since 'given_ind' has been provided then 'type'",
                     "will be coerced to 'prob'."))
    }
    
    group_given             <- group
    group_given[-given_ind] <- -1
    
    p_intersection <- predict(object, 
                              newdata = newdata, 
                              type    = "prob",
                              group   = group,
                              control = control)
    p_given        <- predict(object, 
                              newdata = newdata, 
                              type    = "prob",
                              group   = group_given,
                              control = control)
    
    return(p_intersection / p_given)
  }
  
  # -------------------------------------------------------
  # Marginal effects
  # -------------------------------------------------------
  
  # Calculate marginal effects
  if (!is.null(me))
  {
    # If several marginal effects should be calculated
    n_me <- length(me)
    if (n_me > 1)
    {
      list_return <- list()
      for (i in 1:n_me)
      {
        list_return[[me[i]]] <- predict(object, ..., 
                                        newdata   = newdata,
                                        given_ind = given_ind, 
                                        group     = group,
                                        type      = type, 
                                        me        = me[i], 
                                        eps       = eps,
                                        control   = control)
      }
      return(list_return)
    }
    
    # Determine the type of marginal effect
    is_discrete <- length(eps) > 1
    
    # Adjust epsilon if need
    if (is.null(eps))
    {
      eps <- newdata[[me]] * sqrt(.Machine$double.eps)
    }
    
    # Calculate values before and after
    if (is_discrete)
    {
      newdata[me] <- eps[1]
    }
    p0 <- predict.mvoprobit(object, 
                            newdata   = newdata,
                            given_ind = given_ind,
                            group     = group,
                            group2    = group2,
                            type      = type,
                            me        = NULL,
                            control   = control)
    if (is_discrete)
    {
      newdata[me] <- eps[2]
    }
    else
    {
      newdata[me] <- newdata[me] + eps
    }
    p1 <- predict.mvoprobit(object, 
                            newdata   = newdata,
                            given_ind = given_ind,
                            group     = group,
                            group2    = group2,
                            type      = type,
                            me        = NULL,
                            control   = control)
    
    # Estimate marginal effect
    val <- p1 - p0
    if (!is_discrete)
    {
      val <- val / eps
    }
    
    # Return marginal effect
    return(val)
  }

  # -------------------------------------------------------
  # Linear indexes
  # -------------------------------------------------------
  
  # Assign 'group' for some 'type'
  if (((type == "li") | (type == "sd")) & is.null(group))
  {
    group <- rep(1, object$other$n_eq)
  }
  
  # Calculate linear index
  li_lower <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_upper <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_mean  <- matrix(NA, nrow = n_obs, ncol = n_eq_g)
  li_var   <- matrix(1, nrow = n_obs, ncol = n_eq_g)
  if (n_eq_g > 0)
  {
    for (i in 1:n_eq_g)
    {
      # Calculate linear indexes for mean and variance parts
      li_mean[, i] <- W_mean[[ind_eq[i]]] %*% coef[[ind_eq[i]]]
      if (is_het[ind_eq[i]])
      {
        li_var[, i] <- exp(W_var[[ind_eq[i]]] %*% coef_var[[ind_eq[i]]])
      }
      # Adjust lower limits for cuts and heteroscedasticity
      if (group[ind_eq[i]] != 0)
      {
        li_lower[, i] <- cuts[[ind_eq[i]]][group[ind_eq[i]]] - 
          li_mean[, i]
        if (is_het[ind_eq[i]])
        {
          li_lower[, i] <- li_lower[, i, drop = FALSE] / 
                           li_var[, i, drop = FALSE]
        }
      }
      else
      {
        li_lower[, i] <- -Inf
      }
      # Adjust upper limits for cuts and heteroscedasticity
      if (group[ind_eq[i]] != n_cuts_eq[[ind_eq[i]]])
      {
        li_upper[, i] <- cuts[[ind_eq[i]]][group[ind_eq[i]] + 1] - 
                         li_mean[, i, drop = FALSE]
        if (is_het[ind_eq[i]])
        {
          li_upper[, i] <- li_upper[, i, drop = FALSE] / 
                           li_var[, i, drop = FALSE]
        }
      }
      else
      {
        li_upper[, i] <- Inf
      }
    }
  }

  # Return linear indexes if need
  if (type == "li")
  {
    return(li_mean)
  }
  
  # Return standard deviations if need
  if (type == "sd")
  {
    return(li_var)
  }
  
  # -------------------------------------------------------
  # Probabilities
  # -------------------------------------------------------
  
  # Get covariance matrix
  sigma_g <- sigma[ind_eq, ind_eq, drop = FALSE]
  if (any(sigma_omit[ind_eq, ind_eq] == 1))
  {
    sigma_g[sigma_omit[ind_eq, ind_eq]] <- 0
    warning("Unidentified covariances are set to 0.")
  }
  
  # Calculate probabilities
  if ((type == "prob") & (n_eq_g > 0))
  {
    # Calculate probabilities
    prob <- mnorm::pmnorm(lower    = li_lower, 
                          upper    = li_upper, 
                          mean     = rep(0, n_eq_g), 
                          sigma    = sigma_g,
                          marginal = marginal_mnorm_g)$prob
    return(prob)
  }
  
  # -------------------------------------------------------
  # Lambda
  # -------------------------------------------------------

  # Calculate lambda
  lambda <- matrix(0, nrow = n_obs, ncol = n_eq_g)
  if (!is.null(group))
  {
    # Prepare matrix to store the final results
    lambda_mat <- matrix(0, nrow = n_obs, ncol = n_eq)
    colnames(lambda_mat) <- paste0("lambda", 1:n_eq)
    if (n_eq_g > 0)
    {
      # Calculate lambdas for conditional expectations
      grads <- mnorm::pmnorm(lower              = li_lower, 
                             upper              = li_upper, 
                             mean               = rep(0, n_eq_g), 
                             sigma              = sigma_g,
                             log                = TRUE, 
                             grad_upper         = TRUE, 
                             grad_lower         = TRUE,
                             grad_sigma         = FALSE,
                             marginal           = marginal_mnorm_g,
                             grad_marginal      = is_marginal,
                             grad_marginal_prob = is_marginal)
      lambda_lower <- NULL
      lambda_upper <- NULL
      if (!is_marginal)
      {
        lambda_lower <- -grads$grad_lower
        lambda_upper <- grads$grad_upper
      }
      else
      {
        lambda_lower <- -grads$grad_lower_marginal
        lambda_upper <- grads$grad_upper_marginal
      }
      if (hasName(control, name = "adj"))
      {
        if (control$adj)
        {
          li_lower_adj                        <- li_lower
          li_lower_adj[is.infinite(li_lower)] <- 0
          li_upper_adj                        <- li_upper
          li_upper_adj[is.infinite(li_upper)] <- 0
          lambda                              <- lambda_lower * li_lower_adj - 
                                                 lambda_upper * li_upper_adj
        }
        else
        {
          stop("Parameter 'adj' in 'control' should be 'TRUE'.")
        }
      }
      else
      {
        lambda <- lambda_lower - lambda_upper
      }
    }
    
    # Return lambda
    if (type == "lambda")
    {
      lambda_mat[, ind_eq] <- lambda
      return(lambda_mat)
    }
  }
  else
  {
    if (type == "lambda")
    {
      return(matrix(NA, nrow = n_obs, ncol = n_eq))
    }
  }
  
  # -------------------------------------------------------
  # Predictions for continuous equations
  # -------------------------------------------------------
  
  # Prediction for continuous equation
  y_pred    <- NULL
  scores    <- vector(mode = "list", length = n_eq2)
  if (!is.null(group2))
  {
    # Matrix to store the predictions
    y_pred           <- matrix(NA, nrow = n_obs, ncol = n_eq2)
    colnames(y_pred) <- object$other$y_names
    
    # Predictions
    for (i in 1:n_eq2)
    {
      X_i <- as.matrix(X[[i]])
      if (group2[i] != -1)
      {
        # substitute data with predictions for scores
        if (is_scores)
        {
          if (i >= 2)
          {
            # predictions of the previous equation
            for (v0 in 1:(i - 1))
            {
              if (y_names[v0] %in% colnames(X_i))
              {
                X_i[, y_names[v0]] <- y_pred[, v0]
              }
            }
          }
        }
        # predictions
        y_pred[, i] <- X_i %*% matrix(object$coef2[[i]][group2[i] + 1, ], 
                                      ncol = 1)
        if (!is.null(group))
        {
          if (object$estimator == "ml")
          {
            y_pred[, i] <- y_pred[, i] + lambda %*% 
                           matrix(object$cov2[[i]][group2[i] + 1, ind_eq], 
                                  ncol = 1)
          }
        }
      }
      # calculate scores
      if (is_scores)
      {
        scores[[i]] <- as.vector(y[, i] - y_pred[, i]) * X_i
        scores[[i]][is.infinite(scores[[i]]) | is.na(scores[[i]])] <- 0
      }
    }
  }
    
  # If scores should be returned
  if (is_scores)
  {
    names(scores) <- object$other$y_names
    return(scores)
  }
    
  # Return prediction for continuous equation
  if (type == "val")
  {
    return(y_pred)
  }
  
  # -------------------------------------------------------
  # Normally user should not pass to this section
  # -------------------------------------------------------
  
  stop("Wrong 'type' argument.")
}

# ---------------------------------------------------------------------
# mnprobit
# ---------------------------------------------------------------------

#' Predict method for mnprobit function
#' @template predict.mnprobit_param_Template
#' @template predict.mnprobit_details_Template
#' @template predict.mnprobit_return_Template
predict.mnprobit <- function(object, ..., 
                             newdata = NULL,
                             alt = 1, 
                             regime = -1,
                             type = ifelse(is.null(regime) | (regime == -1), 
                                           "prob", "val"),
                             alt_obs = "all",
                             me = NULL, 
                             eps = NULL,
                             control = list(),
                             se = FALSE,
                             exogenous = NULL)
{   
  # -------------------------------------------------------
  # Deal with data and variables
  # -------------------------------------------------------
  
  # Check whether 'newdata' has been provided
  is_newdata <- !is.null(newdata)
  
  # Provide 'data' as 'newdata' if need
  if (!is_newdata)
  {
    newdata <- object$data
  }
  
  # Deal with 'exogenous' argument
  n_exogenous <- length(exogenous)
  is_exogenous <- n_exogenous > 0
  if (is_exogenous)
  {
    newdata <- exogenous_fn(exogenous = exogenous, newdata = newdata)
  }
  
  # Get some variables
  coef <- object$coef
  sigma <- object$sigma
  n_alt <- object$control_lnL$n_alt
  n_obs <- object$control_lnL$n_obs
  n_par <- length(object$par)
  n_coef <- object$control_lnL$n_coef
  n_regimes <- object$n_regimes
  
  # Get variables associated with formulas
  df <- model.frame(object$formula, data = newdata, na.action = na.omit)
  W <- as.matrix(cbind(1, df[, -1]))
  z <- as.vector(df[, 1])
  df2 <- NULL
  X <- NULL
  y <- NULL
  if (is2)
  {
    df2 <- model.frame(object$formula2, data = newdata, na.action = na.omit)
    X <- as.matrix(cbind(1, df2[, -1]))
    y <- as.vector(df2[, 1])
  }
  
  # Remove 'df' and 'df2'
  df <- NULL
  df2 <- NULL
  
  # Calculate the number of observations
  n_obs <- nrow(W)
  
  # -------------------------------------------------------
  # Calculate standard errors
  # -------------------------------------------------------
  
  # Calculate standard errors
  if (se)
  {
    # Get arguments of the function and change se
    # argument to false to prevent eternal cycle
    predict_args <- c(as.list(environment()), list(...))
    predict_args$newdata <- newdata
    predict_args$se <- FALSE
    
    # Apply delta method
    predict_fn <- function(object)
    {
      predict_args$object <- object
      do.call(what = predict.mnprobit, args = predict_args)
    }
    out <- delta_method(object = object, fn = predict_fn)
    
    return(out)
  }
  
  # -------------------------------------------------------
  # Special routines not intended for users
  # -------------------------------------------------------
  
  # Special routine to calculate probabilities for each observation
  if ((type == "prob") & is.null(alt))
  {
    probs <- matrix(NA, ncol = n_alt, nrow = n_obs)
    for (i in 1:n_alt)
    {
      probs[, i] <- predict(object, type = "prob", 
                            alt = i, newdata = newdata)
    }
    colnames(probs) <- paste0("P(z=", 1:n_alt, ")")
    rownames(probs) <- 1:n_obs
    return(probs)
  }
  
  # Special routine to differentiate lambda respect to all arguments
  if (is.null(alt) & (regime == -1) & 
      (type == "dlambda") & !is_newdata)
  {
    delta <- sqrt(.Machine$double.eps) * 10
    lambda <- predict.mnprobit(object = object, type = "lambda", alt = NULL)
    dlambda <- array(dim = c(nrow(lambda), ncol(lambda), n_par))
    # respect to coefficients
    coef_ind_alt <- object$control_lnL$coef_ind_alt
    for (i in 1:(n_alt - 1))
    {
      for (j in 1:n_coef)
      {
        par_old_tmp <- object$coef[j, i] 
        delta_tmp <- delta * abs(par_old_tmp)
        object$coef[j, i]  <- par_old_tmp + delta_tmp
        lambda_tmp <- predict.mnprobit(object = object, 
                                       type = "lambda", alt = NULL)
        dlambda[, , coef_ind_alt[j, i] + 1] <- (lambda_tmp - lambda) / 
          delta_tmp
        object$coef[j, i]  <- par_old_tmp
      }
    }
    # respect to sigma
    if (n_alt > 2)
    {
      sigma_ind <- object$control_lnL$sigma_ind
      counter <- 1
      for (i in 1:(n_alt - 1))
      {
        for (j in 1:i)
        {
          if (!((i == 1) & (j == 1)))
          {
            par_old_tmp <- object$sigma[i, j]
            delta_tmp <- delta * abs(par_old_tmp)
            object$sigma[i, j] <- par_old_tmp + delta_tmp
            object$sigma[j, i] <- object$sigma[i, j]
            lambda_tmp <- predict.mnprobit(object = object, 
                                           type = "lambda", alt = NULL)
            dlambda[, , sigma_ind[counter] + 1] <- (lambda_tmp - lambda) /
              delta_tmp
            counter <- counter + 1
            object$sigma[i, j] <- par_old_tmp
            object$sigma[j, i] <- par_old_tmp
          }
        }
      }
    }
    return(dlambda)
  }
  
  # -------------------------------------------------------
  # Alternative specific lambdas
  # -------------------------------------------------------
  
  # Calculate all alternative specific lambdas
  if (is.null(alt) & (type == "lambda"))
  {
    lambda <- matrix(NA, nrow = n_obs, ncol = n_alt - 1)
    for (i in 1:n_alt)
    {
      ind_alt <- object$control_lnL$ind_alt[[i]] + 1
      lambda[ind_alt, ] <- predict(object, alt = i, 
                                   type = "lambda", alt_obs = "alt")
    }
    return(lambda)
  }
  
  # -------------------------------------------------------
  # Marginal effects
  # -------------------------------------------------------
  
  # Calculation of marginal effects
  if (!is.null(me))
  {
    # If several marginal effects should be calculated
    n_me <- length(me)
    if (n_me > 1)
    {
      list_return <- list()
      for (i in 1:n_me)
      {
        list_return[[me[i]]] <- predict(object, newdata = newdata,
                                        alt = alt, regime = regime,
                                        alt_obs = alt_obs,
                                        type = type, me = me[i], eps = eps)
      }
      return(list_return)
    }
    
    # Determine the type of marginal effect
    is_discrete <- length(eps) > 1
    
    # Adjust epsilon if need
    if (is.null(eps))
    {
      eps <- newdata[[me]] * sqrt(.Machine$double.eps)
    }
    
    # Calculate values before and after
    if (is_discrete)
    {
      newdata[me] <- eps[1]
    }
    p0 <- predict.mnprobit(object, newdata = newdata,
                           alt = alt, regime = regime,
                           alt_obs = alt_obs,
                           type = type, me = NULL, eps = NULL)
    if (is_discrete)
    {
      newdata[me] <- eps[2]
    }
    else
    {
      newdata[me] <- newdata[me] + eps
    }
    p1 <- predict.mnprobit(object, ..., newdata = newdata,
                           alt = alt, regime = regime,
                           alt_obs = alt_obs,
                           type = type, me = NULL, eps = NULL)
    
    # Estimate marginal effect
    val <- p1 - p0
    if (!is_discrete)
    {
      val <- val / eps
    }
    return(val)
  }
  
  # -------------------------------------------------------
  # Get alternative specific data
  # -------------------------------------------------------
  
  # Select appropriate observations
  if (alt_obs != "all")
  {
    if (alt_obs == "alt")
    {
      alt_obs <- alt
    }
    alt_ind = which(z %in% alt_obs)
    n_obs <- length(alt_ind)
    W <- W[alt_ind, ]
    z <- z[alt_ind]
  }
  
  # -------------------------------------------------------
  # Unconditional predictions of continuous variable
  # -------------------------------------------------------
  
  # Unconditional predictions of continuous variable
  coef2 <- NULL
  y_pred <- NULL
  if (is2 & (type == "val"))
  {
    coef2 <- object$coef2
    if (regime != -1)
    {
      y_pred <- X %*% matrix(coef2[, regime + 1], ncol = 1)
    }
    if (is.null(alt))
    {
      return(y_pred)
    }
  }
  
  # -------------------------------------------------------
  # Linear index
  # -------------------------------------------------------
  
  # Calculate linear index
  li <- matrix(NA, nrow = n_obs, ncol = n_alt - 1)
  for (i in 1:(n_alt - 1))
  {
    li[, i] <- W %*% coef[, i]
  }
  
  # Return linear indexes if need
  if (type == "li")
  {
    return(li[, alt])
  }
  
  # -------------------------------------------------------
  # Preliminary data manipulations
  # -------------------------------------------------------
  
  # Create transformation matrix
  transform_mat <- matrix(0, nrow = n_alt, ncol = n_alt)
  diag(transform_mat) <- 1
  if (alt != n_alt)
  {
    transform_mat[, alt] <- -1
  }
  transform_mat <- transform_mat[-alt, , drop = FALSE]
  transform_mat <- transform_mat[, -n_alt, drop = FALSE]
  
  # Construct covariance matrix for alternative
  sigma_alt <- transform_mat %*% sigma %*% t(transform_mat)
  
  # Calculate the differences between linear indexes
  li_diff <- matrix(NA, n_obs, n_alt - 1);
  if (alt == n_alt)
  {
    li_diff <- -li;
  }
  else
  {
    li_diff[, n_alt - 1] <- li[, alt];
    li_diff[, -(n_alt - 1)] <- apply(li[, -alt, drop = FALSE], 2, 
                                     function(x)
                                     {
                                       return(li[, alt] - x)
                                     })
  }
  
  # -------------------------------------------------------
  # Probabilities
  # -------------------------------------------------------
  
  # Calculate the probabilities
  lower_neg_inf <- matrix(-Inf, nrow = n_obs, ncol = n_alt - 1)
  prob <- mnorm::pmnorm(lower = lower_neg_inf, upper = li_diff,
                        mean = rep(0, n_alt - 1), sigma = sigma_alt,
                        is_validation = FALSE)$prob
  
  if (type == "prob")
  {
    return(prob)
  }
  
  # -------------------------------------------------------
  # Lambda
  # -------------------------------------------------------
  
  # Calculate lambdas
  lambda <- mnorm::pmnorm(lower = lower_neg_inf, upper = li_diff,
                          mean = rep(0, n_alt - 1), sigma = sigma_alt,
                          grad_upper = TRUE,
                          log = TRUE,
                          is_validation = FALSE)$grad_upper
  A <- matrix(0, nrow = n_alt - 1, ncol = n_alt - 1)
  for (i in 1:(n_alt - 1))
  {
    for (j in 1:(n_alt - 1))
    {
      if (i == alt)
      {
        A[i, j] <- 1
      }
      if (((i < alt) & (i == j)) | 
          ((i > alt) & (i == (j + 1))))
      {
        A[i, j] <- -1
      }
    }
  }
  lambda <- lambda %*% t(A)
  
  # Return the results
  if (type == "lambda")
  {
    return(lambda)
  }
  
  # -------------------------------------------------------
  # Conditional predictions of continuous variable
  # -------------------------------------------------------
  
  # Conditional predictions
  coef_lambda <- NULL
  if (is2 & (regime != -1) & (type == "val"))
  {
    coef_lambda <- object$coef_lambda
    # conditional predictions (on continuous equations)
    if (!is.null(alt))
    {
      # degrees
      degrees <- object$degrees[regime + 1, ]
      # estimate predictions
      for (j in 1:(n_alt - 1))
      {
        lambda_pow <- 1
        if (degrees[j] >= 1)
        {
          for (j1 in 1:degrees[j])
          {
            lambda_pow <- lambda_pow * lambda[, j]
            y_pred <- y_pred + lambda_pow * coef_lambda[[regime + 1]][[j]][j1]
          }
        }
      }
    }
  }
  
  # Return prediction for continuous equation
  if (type == "val")
  {
    return(y_pred)
  }
  
  # -------------------------------------------------------
  # Normally user should not pass to this section
  # -------------------------------------------------------
  
  stop("Wrong 'type' argument.")
}

# ---------------------------------------------------------------------
# mnlogit
# ---------------------------------------------------------------------

#' Predict method for mnlogit function
#' @template predict.mnprobit_param_Template
#' @template predict.mnprobit_details_Template
#' @template predict.mnprobit_return_Template
predict.mnlogit <- function(object, ..., 
                            newdata = NULL,
                            alt = 1, 
                            regime = -1,
                            type = ifelse(is.null(regime) | (regime == -1), 
                                          "prob", "val"),
                            alt_obs = "all",
                            me = NULL, 
                            eps = NULL,
                            control = list(),
                            se = FALSE,
                            exogenous = NULL)
{   
  # -------------------------------------------------------
  # Deal with data and variables
  # -------------------------------------------------------
  
  # Check whether 'newdata' has been provided
  is_newdata <- !is.null(newdata)
  
  # Provide 'data' as 'newdata' if need
  if (!is_newdata)
  {
    newdata <- object$data
  }
  
  # Deal with 'exogenous' argument
  n_exogenous <- length(exogenous)
  is_exogenous <- n_exogenous > 0
  if (is_exogenous)
  {
    newdata <- exogenous_fn(exogenous = exogenous, newdata = newdata)
  }
  
  # Get some variables
  coef <- object$coef
  n_alt <- object$control_lnL$n_alt
  n_obs <- object$control_lnL$n_obs
  n_par <- length(object$par)
  n_coef <- object$control_lnL$n_coef
  n_regimes <- object$n_regimes
  is2 <- n_regimes > 0
  
  # Get variables associated with formulas
  df <- model.frame(object$formula, data = newdata, na.action = na.omit)
  W <- as.matrix(cbind(1, df[, -1]))
  z <- as.vector(df[, 1])
  df2 <- NULL
  X <- NULL
  y <- NULL
  if (is2)
  {
    df2 <- model.frame(object$formula2, data = newdata, na.action = na.omit)
    X <- as.matrix(cbind(1, df2[, -1]))
    y <- as.vector(df2[, 1])
  }
  
  # Remove 'df' and 'df2'
  df <- NULL
  df2 <- NULL
  
  # Calculate the number of observations
  n_obs <- nrow(W)
  
  # -------------------------------------------------------
  # Calculate standard errors
  # -------------------------------------------------------
  
  # Calculate standard errors
  if (se)
  {
    # Get arguments of the function and change se
    # argument to false to prevent eternal cycle
    predict_args <- c(as.list(environment()), list(...))
    predict_args$newdata <- newdata
    predict_args$se <- FALSE
    
    # Apply delta method
    predict_fn <- function(object)
    {
      predict_args$object <- object
      do.call(what = predict.mnlogit, args = predict_args)
    }
    out <- delta_method(object = object, fn = predict_fn)
    
    return(out)
  }
  
  # -------------------------------------------------------
  # Special routines not intended for users
  # -------------------------------------------------------
  
  # Special routine to differentiate lambda respect to all arguments
  if (is.null(alt) & (regime == -1) & 
      (type == "dlambda") & is.null(newdata))
  {
    delta <- sqrt(.Machine$double.eps) * 10
    lambda <- predict.mnlogit(object = object, type = "lambda", alt = NULL)
    dlambda <- array(dim = c(nrow(lambda), ncol(lambda), n_par))
    # respect to coefficients
    coef_ind_alt <- object$control_lnL$coef_ind_alt
    for (i in 1:(n_alt - 1))
    {
      for (j in 1:n_coef)
      {
        par_old_tmp <- object$coef[j, i] 
        delta_tmp <- delta * abs(par_old_tmp)
        object$coef[j, i]  <- par_old_tmp + delta_tmp
        lambda_tmp <- predict.mnlogit(object = object, 
                                       type = "lambda", alt = NULL)
        dlambda[, , coef_ind_alt[j, i] + 1] <- (lambda_tmp - lambda) / delta_tmp
        object$coef[j, i]  <- par_old_tmp
      }
    }
    return(dlambda)
  }
  
  # Calculate all alternative specific lambdas
  if (is.null(alt) & (type == "lambda"))
  {
    lambda <- matrix(NA, nrow = n_obs, ncol = n_alt)
    for (i in 1:n_alt)
    {
      ind_alt <- object$control_lnL$ind_alt[[i]] + 1
      lambda[ind_alt, ] <- predict(object, alt = i, 
                                   type = "lambda", alt_obs = "alt")
    }
    return(lambda)
  }
  
  # -------------------------------------------------------
  # Marginal effects
  # -------------------------------------------------------
  
  # Calculation of marginal effects
  if (!is.null(me))
  {
    # If several marginal effects should be calculated
    n_me <- length(me)
    if (n_me > 1)
    {
      list_return <- list()
      for (i in 1:n_me)
      {
        list_return[[me[i]]] <- predict(object, newdata = newdata,
                                        alt = alt, regime = regime,
                                        alt_obs = alt_obs,
                                        type = type, me = me[i], eps = eps)
      }
      return(list_return)
    }
    
    # Determine the type of marginal effect
    is_discrete <- length(eps) > 1
    
    # Adjust epsilon if need
    if (is.null(eps))
    {
      eps <- newdata[[me]] * sqrt(.Machine$double.eps)
    }
    
    # Calculate values before and after
    if (is_discrete)
    {
      newdata[me] <- eps[1]
    }
    p0 <- predict.mnlogit(object, newdata = newdata,
                          alt = alt, regime = regime,
                          alt_obs = alt_obs,
                          type = type, me = NULL, eps = NULL)
    if (is_discrete)
    {
      newdata[me] <- eps[2]
    }
    else
    {
      newdata[me] <- newdata[me] + eps
    }
    p1 <- predict.mnlogit(object, ..., newdata = newdata,
                          alt = alt, regime = regime,
                          alt_obs = alt_obs,
                          type = type, me = NULL, eps = NULL)
    
    # Estimate marginal effect
    val <- p1 - p0
    if (!is_discrete)
    {
      val <- val / eps
    }
    return(val)
  }
  
  # -------------------------------------------------------
  # Get alternative specific data
  # -------------------------------------------------------
  
  # Select appropriate observations
  if (alt_obs != "all")
  {
    if (alt_obs == "alt")
    {
      alt_obs <- alt
    }
    alt_ind = which(z %in% alt_obs)
    n_obs <- length(alt_ind)
    W <- W[alt_ind, ]
    z <- z[alt_ind]
  }
  
  # -------------------------------------------------------
  # Unconditional predictions of continuous variable
  # -------------------------------------------------------
  
  # Unconditional predictions of continuous variable
  coef2 <- NULL
  y_pred <- NULL
  if (is2 & (type == "val"))
  {
    coef2 <- object$coef2
    if (regime != -1)
    {
      y_pred <- X %*% matrix(coef2[, regime + 1], ncol = 1)
    }
    if (is.null(alt))
    {
      return(y_pred)
    }
  }
  
  # -------------------------------------------------------
  # Linear index
  # -------------------------------------------------------
  
  # Calculate linear index
  li <- matrix(0, nrow = n_obs, ncol = n_alt)
  for (i in 1:(n_alt - 1))
  {
    li[, i] <- W %*% coef[, i]
  }
  
  # Return linear indexes if need
  if (type == "li")
  {
    return(li[, alt])
  }
  
  # -------------------------------------------------------
  # Probabilities
  # -------------------------------------------------------
  
  # Calculate exponents of linear indexes
  li_exp <- exp(li)
  
  # Calculate the probabilities
  prob <- sweep(li_exp, 1, rowSums(li_exp), FUN = '/')

  if (type == "prob")
  {
    return(prob[, alt])
  }
  
  # -------------------------------------------------------
  # Lambda
  # -------------------------------------------------------
  
  # Calculate lambdas
  lambda <- matrix(NA, nrow = n_obs, ncol = n_alt)
  lambda[, alt] <- -log(prob[, alt])
  lambda[, -alt] <- prob[, -alt] * log(prob[, -alt]) / 
                    (1 - prob[, -alt])
  
  # return the results
  if (type == "lambda")
  {
    return(lambda)
  }
  
  # -------------------------------------------------------
  # Conditional predictions of the continuous variable
  # -------------------------------------------------------
  
  # Conditional predictions
  coef_lambda <- NULL
  if (is2 & (regime != -1) & (type == "val"))
  {
    coef_lambda <- object$coef_lambda
    # conditional predictions (on continuous equations)
    if (!is.null(alt))
    {
      degrees <- object$degrees[regime + 1, ]
      for (j in 1:n_alt)
      {
        lambda_pow <- 1
        if (degrees[j] >= 1)
        {
          for (j1 in 1:degrees[j])
          {
            lambda_pow <- lambda_pow * lambda[, j]
            y_pred <- y_pred + lambda_pow * coef_lambda[[regime + 1]][[j]][j1]
          }
        }
      }
    }
  }
  
  # Return prediction for continuous equation
  if (type == "val")
  {
    return(y_pred)
  }
  
  # -------------------------------------------------------
  # Normally user should not pass to this section
  # -------------------------------------------------------
  
  stop("Wrong 'type' argument.")
}

# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

#' Modify exogenous variables in data frame
#' @description Change some values of the exogenous variables in a data frame.
#' @param exogenous list such that \code{exogenous[[i]]} represents the value 
#' (or a vector of values of the same size as \code{nrow(newdata)}) which will 
#' be exogenously assigned to the variable \code{names(exogenous)[[i]]} in 
#' \code{newdata} i.e., \code{newdata[, names(exogenous)[i]] <- exogenous[[i]]}.
#' If \code{newdata} is \code{NULL} and \code{exogenous} is not \code{NULL} then
#' \code{newdata} is set to \code{object$data}.
#' This argument is especially useful for causal inference when some endogenous 
#' (dependent) variables should be exogenously assigned with some values i.e.,
#' in the right hand side of the \code{formula} and \code{formula2}.
#' The purpose of the \code{exogeneous} argument is just a \code{convenience} so
#' equivalently it is possible to exogenously provide the values to variables
#' via \code{newdata} argument.
#' @param newdata data frame.
#' @details This function changes \code{exogenous} variables in \code{newdata}.
#' @return The function returns data frame which is similar to \code{newdata} 
#' but some values of this data frame are set according to \code{exogenous}.
exogenous_fn <- function(exogenous, newdata)
{
  n_exogenous <- length(exogenous)
  exogenous_names <- names(exogenous)
  if (!is.list(exogenous))
  {
    stop ("Argument 'exogenous' should be a list.")
  }
  n_obs <- nrow(newdata)
  for (i in 1:n_exogenous)
  {
    n_exogenous_i <- length(exogenous[[i]])
    if (!is.numeric(exogenous[[i]]) | ((n_exogenous_i > 1) & 
                                       (n_exogenous_i != n_obs)))
    {
      stop (paste0("Elements of 'exogenous' argument should be ",
                   "numeric values of appropriate size but ",
                   "exogenous[[", i, "]] is not."))
    }
    if (!(exogenous_names[i] %in% colnames(newdata)))
    {
      stop (paste0("Incorrect value of exogenous[[", i, "]] since there ",
                   "is no variable ", exogenous_names[i], " in the data."))
    }
    newdata[, exogenous_names[i]] <- exogenous[[i]]
  }
  
  return (as.data.frame(newdata))
}