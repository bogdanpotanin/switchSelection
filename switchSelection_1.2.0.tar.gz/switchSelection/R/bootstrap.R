#' Bootstrap for mvoprobit and mnprobit functions
#' @description Function \code{\link[switchSelection]{bootstrap_base}} 
#' provides bootstrap estimates of the parameters 
#' of \code{\link[switchSelection]{mvoprobit}},
#' \code{\link[switchSelection]{mnprobit}} and
#' \code{\link[switchSelection]{mnlogit}} models.
#' Function \code{\link[switchSelection]{bootstrap_test}} uses these 
#' estimates for the analysis of bootstrap confidence intervals and
#' hypothesis testing.
#' @name bootstrap
#' @param object an object of class 'mvoprobit', 'mnprobit' or 'mnlogit'.
#' @param iter the number of bootstrap iterations.
#' @param bootstrap an object returned by function 
#' \code{\link[switchSelection]{bootstrap_base}}. 
#' If \code{NULL} this function is applied automatically.
#' @param opt_type the same as \code{opt_type} argument of
#' \code{\link[switchSelection]{mvoprobit}},
#' \code{\link[switchSelection]{mnprobit}} and
#' \code{\link[switchSelection]{mnlogit}} functions.
#' @param opt_args the same as \code{opt_args} argument of
#' \code{\link[switchSelection]{mvoprobit}},
#' \code{\link[switchSelection]{mnprobit}} and
#' \code{\link[switchSelection]{mnlogit}} functions.
#' @param n_sim the same as \code{n_sim} argument of
#' \code{\link[switchSelection]{mvoprobit}} and 
#' \code{\link[switchSelection]{mnprobit}} functions.
#' @param n_cores the same as \code{n_cores} argument of
#' \code{\link[switchSelection]{mvoprobit}},
#' \code{\link[switchSelection]{mnprobit}} and
#' \code{\link[switchSelection]{mnlogit}} functions.
#' @param fn function which returns a numeric vector and should depend on the 
#' elements of \code{object}. These elements should be accessed via 
#' \code{\link[switchSelection]{coef.mvoprobit}},
#' \code{\link[switchSelection]{coef.mnprobit}} and
#' \code{\link[switchSelection]{coef.mnlogit}} functions. 
#' Also it is possible to use \code{\link[switchSelection]{predict.mvoprobit}}, 
#' \code{\link[switchSelection]{predict.mnprobit}} and
#' \code{\link[switchSelection]{predict.mnlogit}} functions.
#' The first argument of \code{fn} should be \code{object}.
#' Therefore \code{coef} and \code{predict} functions in \code{fn} should also
#' depend on \code{object}.
#' @param ... objects returned by function 
#' \code{\link[switchSelection]{bootstrap_based}} to be combined into a
#' single object.
#' @param fn_args list of additional arguments of \code{fn}.
#' @param cl numeric value between \code{0} and \code{1} representing
#' a confidence level of the confidence interval.
#' @details The output of \code{\link[switchSelection]{bootstrap_base}}
#' function is intended for the function
#' \code{\link[switchSelection]{bootstrap_test}} that is useful for
#' the analysis of bootstrap confidence intervals and hypothesis testing.
#' 
#' Function \code{\link[switchSelection]{bootstrap_combine}} combines several
#' objects returned by \code{\link[switchSelection]{bootstrap_base}} function
#' into a single object.
#' 
#' Alternatively apply \code{\link[switchSelection]{delta_method}} function
#' for the analysis of confidence intervals and hypothesis testing
#' based on delta method.
#' @return Function \code{\link[switchSelection]{bootstrap_base}}
#' returns an object of class \code{bootstrap_mvoprobit},
#' \code{bootstrap_mnprobit} or \code{bootstrap_mnlogit}
#' depending on the function being used to estimate
#' the parameters of the model. This object is a list which elements 
#' are the lists corresponding to the elements of the list returned by
#' \code{\link[switchSelection]{mvoprobit}},
#' \code{\link[switchSelection]{mnprobit}} and 
#' \code{\link[switchSelection]{mnlogit}} functions.
#' For example, element \code{coef[[i]]} of the object of class
#' \code{bootstrap_mvoprobit} is the element \code{coef} of the object
#' of class \code{mvoprobit} obtained on the \code{i}-th iteration of the
#' bootstrap algorithm. There are two expeptions. 
#' First, \code{par} element is a matrix which rows are estimates of the 
#' parameters obtained on the \code{i}-th iteration of the bootstrap algorithm.
#' Second, \code{cov} is bootstrap asymptotic covariance matrix.
#' 
#' Function \code{\link[switchSelection]{bootstrap_base}} returns an object of 
#' class \code{bootstrap_test}. It is a list which has the following elements:
#' \itemize{
#' \item \code{bootstrap} - a matrix such that \code{bootstrap[, i]} is a
#' vector of estimates of \code{fn} calculated with estimates of the parameters
#' obtained on the \code{i}-th iteration of the bootstrap algorithm.
#' \item \code{tbl} - a matrix which columns are described below.
#' }
#' Matrix \code{tbl} has the following columns:
#' \itemize{
#' \item \code{val} - output of the \code{fn} function.
#' \item \code{se} - numeric vector such that \code{se[i]} represents standard
#' error associated with \code{val[i]}.
#' \item \code{lwr.b} - realization of the lower (left) bound of the 
#' bootstrap (percentile) confidence interval.
#' \item \code{upr.b} - realization of the upper (right) bound of the 
#' bootstrap (percentile) confidence interval.
#' \item \code{lwr.a} - realization of the lower (left) bound of the 
#' asymptotic confidence interval under the assumption of the aymptotic
#' normality of the estimator.
#' \item \code{upr.a} - realization of the upper (right) bound of the 
#' asymptotic confidence interval under the assumption of the aymptotic
#' normality of the estimator.
#' \item \code{p_value} - numeric vector such that \code{p_value[i]} represents
#' p-value of the two-sided significance test associated with \code{val[i]}.
#' This test is conducted under the assumption of asymptotic normality
#' of the estimator. Null hypothesis is that \code{fn} equals zero.
#' }
#' 
#' Function \code{\link[switchSelection]{bootstrap_combine}}  returns the object
#' which combines several object returned by 
#' \code{\link[switchSelection]{bootstrap_base}} function into a single
#' object.
#' @template bootstrap_examples_Template
bootstrap_base <- function(object, iter = 100, 
                           opt_type = "optim", opt_args = NULL,
                           n_sim = 1000, n_cores = 1)
{
  # Routine for mvoprobit
  if (is(object = object, class2 = "mvoprobit"))
  {
    # Prepare a list to store the output
    out <- list(par = matrix(NA, nrow = iter, ncol = length(object$par)),
                coef = vector(mode = "list", length = iter),
                coef_var = vector(mode = "list", length = iter),
                cuts = vector(mode = "list", length = iter),
                coef2 = vector(mode = "list", length = iter),
                sigma = vector(mode = "list", length = iter),
                var2 = vector(mode = "list", length = iter),
                cov2 = vector(mode = "list", length = iter),
                sigma2 = vector(mode = "list", length = iter),
                marginal_par = vector(mode = "list", length = iter),
                coef_lambda = vector(mode = "list", length = iter))
    
    # Estimate the model
    n <- nrow(object$data)
    for (i in 1:iter)
    {
      # Select indexes of observations to include into the sample
      ind <- sample(x = 1:n, size = n, replace = TRUE)
      
      # Estimate the model
      model <- mvoprobit(formula = object$formula, formula2 = object$formula2,
                         data = object$data[ind, ], 
                         groups = object$groups, groups2 = object$groups2,
                         marginal = object$marginal,
                         opt_type = opt_type, opt_args = opt_args,
                         start = object$par,
                         estimator = object$estimator,
                         cov_type = object$cov_type,
                         degrees = object$degrees,
                         regularization = object$other$regularization)
      
      # Store the results
      out$par[i, ] <- model$par
      out$coef[[i]] <- model$coef
      out$coef_var[[i]] <- model$coef_var
      out$cuts[[i]] <- model$cuts
      out$coef2[[i]] <- model$coef2
      out$sigma[[i]] <- model$sigma
      out$var2[[i]] <- model$var2
      out$cov2[[i]] <- model$cov2
      out$sigma2[[i]] <- model$sigma2
      out$marginal_par[[i]] <- model$marginal_par
      out$coef_lambda[[i]] <- model$coef_lambda
    }
    
    # Assign the class
    class(out) <- "bootstrap_mvoprobit"
  }
  
  # Routine for mnprobit
  if (is(object = object, class2 = "mnprobit"))
  {
    # Prepare a list to store the output
    out <- list(par = matrix(NA, nrow = iter, ncol = length(object$par)),
                coef = vector(mode = "list", length = iter),
                coef2 = vector(mode = "list", length = iter),
                sigma = vector(mode = "list", length = iter),
                var2 = vector(mode = "list", length = iter),
                cov2 = vector(mode = "list", length = iter),
                coef_lambda = vector(mode = "list", length = iter))
    
    # Estimate the model
    n <- nrow(object$data)
    for (i in 1:iter)
    {
      # Select indexes of observations to include into the sample
      ind <- sample(x = 1:n, size = n, replace = TRUE)
      
      # Estimate the model
      model <- mnprobit(formula = object$formula, formula2 = object$formula2,
                        data = object$data[ind, ], regimes = object$regimes,
                        opt_type = opt_type, opt_args = opt_args,
                        start = object$par, estimator = object$estimator,
                        cov_type = object$cov_type, degrees = object$degrees,
                        regularization = object$other$regularization)
      
      # Store the results
      out$par[i, ] <- model$par
      out$coef[[i]] <- model$coef
      out$coef2[[i]] <- model$coef2
      out$sigma[[i]] <- model$sigma
      out$var2[[i]] <- model$var2
      out$cov2[[i]] <- model$cov2
      out$coef_lambda[[i]] <- model$coef_lambda
    }
    
    # Assign the class
    class(out) <- "bootstrap_mnprobit"
  }
  
  # Routine for mnlogit
  if (is(object = object, class2 = "mnlogit"))
  {
    # Prepare a list to store the output
    out <- list(par = matrix(NA, nrow = iter, ncol = length(object$par)),
                coef = vector(mode = "list", length = iter),
                coef2 = vector(mode = "list", length = iter),
                coef_lambda = vector(mode = "list", length = iter))
    
    # Estimate the model
    n <- nrow(object$data)
    for (i in 1:iter)
    {
      # Select indexes of observations to include into the sample
      ind <- sample(x = 1:n, size = n, replace = TRUE)
      
      # Estimate the model
      model <- mnlogit(formula = object$formula, formula2 = object$formula2,
                       data = object$data[ind, ], regimes = object$regimes,
                       opt_type = opt_type, opt_args = opt_args,
                       start = object$par, estimator = object$estimator,
                       cov_type = object$cov_type, degrees = object$degrees,
                       regularization = object$other$regularization)
      
      # Store the results
      out$par[i, ] <- model$par
      out$coef[[i]] <- model$coef
      out$coef2[[i]] <- model$coef2
      out$var2[[i]] <- model$var2
      out$cov2[[i]] <- model$cov2
      out$coef_lambda[[i]] <- model$coef_lambda
    }
    
    # Assign the class
    class(out) <- "bootstrap_mnlogit"
  }
  
  # Additional elements of the output
  out$iter <- iter
  out$cov <- cov(out$par)
  
  # Return the results
  return(out)
}

#' @name bootstrap
bootstrap_test <- function(object, bootstrap = NULL, 
                           fn, fn_args = list(), cl = 0.95)
{
  # Perform bootstrap if need
  if (is.null(bootstrap))
  {
    bootstrap <- bootstrap_base(object)
  }
  
  # Prepare matrix to store the results
  fn_args$object <- object
  fn_val0 <- do.call(what = fn, args = fn_args)
  if (is.matrix(fn_val0))
  {
    if (ncol(fn_val0) > 1)
    {
      stop ("Function 'fn' should return a vector or a single column matrix.")
    }
  }
  n_val <- length(fn_val0)
  fn_val <- matrix(NA, nrow = n_val, ncol = bootstrap$iter)
  
  # Routine for mvoprobit function
  if (is(object = bootstrap, class2 = "bootstrap_mvoprobit"))
  {
    # Estimate the value of the function
    for (i in 1:bootstrap$iter)
    {
      fn_args$object$par <- bootstrap$par[i, ]
      if (length(bootstrap$coef[[1]]) > 0)
      {
        fn_args$object$coef <- bootstrap$coef[[i]]
      }
      if (length(bootstrap$coef_var[[1]]) > 0)
      {
        fn_args$object$coef_var <- bootstrap$coef_var[[i]]
      }
      if (length(bootstrap$cuts[[1]]) > 0)
      {
        fn_args$object$cuts <- bootstrap$cuts[[i]]
      }
      if (length(bootstrap$coef2[[1]]) > 0)
      {
        fn_args$object$coef2 <- bootstrap$coef2[[i]]
      }
      if (length(bootstrap$sigma[[1]]) > 0)
      {
        fn_args$object$sigma <- bootstrap$sigma[[i]]
      }
      if (length(bootstrap$var2[[1]]) > 0)
      {
        fn_args$object$var2 <- bootstrap$var2[[i]]
      }
      if (length(bootstrap$cov2[[1]]) > 0)
      {
        fn_args$object$cov2<- bootstrap$cov2[[i]]
      }
      if (length(bootstrap$sigma2[[1]]) > 0)
      {
        fn_args$object$sigma2 <- bootstrap$sigma2[[i]]
      }
      if (length(bootstrap$marginal_par[[1]]) > 0)
      {
        fn_args$object$marginal_par <- bootstrap$marginal_par[[i]]
      }
      if (length(bootstrap$coef_lambda[[1]]) > 0)
      {
        fn_args$object$coef_lambda <- bootstrap$coef_lambda[[i]]
      }
      fn_val[, i] <- do.call(what = fn, args = fn_args)
    }
  }
  
  # Routine for mnprobit function
  if (is(object = bootstrap, class2 = "bootstrap_mnprobit"))
  {
    # Estimate the value of the function
    for (i in 1:bootstrap$iter)
    {
      fn_args$object$par <- bootstrap$par[i, ]
      if (length(bootstrap$coef[[1]]) > 0)
      {
        fn_args$object$coef <- bootstrap$coef[[i]]
      }
      if (length(bootstrap$coef2[[1]]) > 0)
      {
        fn_args$object$coef2 <- bootstrap$coef2[[i]]
      }
      if (length(bootstrap$sigma[[1]]) > 0)
      {
        fn_args$object$sigma <- bootstrap$sigma[[i]]
      }
      if (length(bootstrap$var2[[1]]) > 0)
      {
        fn_args$object$var2 <- bootstrap$var2[[i]]
      }
      if (length(bootstrap$cov2[[1]]) > 0)
      {
        fn_args$object$cov2<- bootstrap$cov2[[i]]
      }
      if (length(bootstrap$coef_lambda[[1]]) > 0)
      {
        fn_args$object$coef_lambda <- bootstrap$coef_lambda[[i]]
      }
      fn_val[, i] <- do.call(what = fn, args = fn_args)
    }
  }
  
  # Routine for mnlogit function
  if (is(object = bootstrap, class2 = "bootstrap_mnlogit"))
  {
    # Estimate the value of the function
    for (i in 1:bootstrap$iter)
    {
      fn_args$object$par <- bootstrap$par[i, ]
      if (length(bootstrap$coef[[1]]) > 0)
      {
        fn_args$object$coef <- bootstrap$coef[[i]]
      }
      if (length(bootstrap$coef2[[1]]) > 0)
      {
        fn_args$object$coef2 <- bootstrap$coef2[[i]]
      }
      if (length(bootstrap$var2[[1]]) > 0)
      {
        fn_args$object$var2 <- bootstrap$var2[[i]]
      }
      if (length(bootstrap$cov2[[1]]) > 0)
      {
        fn_args$object$cov2<- bootstrap$cov2[[i]]
      }
      if (length(bootstrap$coef_lambda[[1]]) > 0)
      {
        fn_args$object$coef_lambda <- bootstrap$coef_lambda[[i]]
      }
      fn_val[, i] <- do.call(what = fn, args = fn_args)
    }
  }
  
  # Store the values of the function
  val <- fn_val0
  val_bootstrap <- fn_val
  
  # Calculate standard errors
  se <- apply(fn_val, 1, sd) 
  
  # Get bounds of the bootstrap confidence interval
  lwr.b <- apply(fn_val, 1, quantile, type = 1, 
                 probs = (1 - cl) / 2 + 1e-8) 
  upr.b <- apply(fn_val, 1, quantile, type = 1, 
                 probs = cl + (1 - cl) / 2 - 1e-8) 
  
  # Get bounds of the asymptotic confidence interval i.e., under
  # the assumption of asymptotic normality of the estimator
  b <- qnorm(cl + (1 - cl) / 2) * se
  lwr.a <- fn_val0 - b
  upr.a <- fn_val0 + b
  
  # Get p-values
  z_value <- fn_val0 / se
  p_value <- rep(NA, n_val)
  for (i in 1:n_val)
  {
    p_value[i] <- 2 * min(pnorm(z_value[i]), 1 - pnorm(z_value[i]))
  }
  
  # Store the output
  out <- list(bootstrap = fn_val, tbl = cbind(fn_val0, se,
                                              lwr.b, upr.b, 
                                              lwr.a, upr.a, 
                                              p_value = p_value))
  colnames(out$tbl) <- c("val", "se",
                         "lwr.b", "upr.b",
                         "lwr.a", "upr.a", 
                         "p_value")
  
  # Assign the class
  class(out) <- "bootstrap_test"
   
  # Return the results
  return (out)
}

#' Summary for an Object of Class bootstrap_test
#' @description Provides summary for an object of class 'bootstrap_test'.
#' @param object object of class 'bootstrap_test'
#' @param ... further arguments (currently ignored)
#' @return Returns an object of class 'summary.bootstrap_test'.
summary.bootstrap_test <- function(object, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  class(object) <- "summary.bootstrap_test"
  
  return(object)
}

#' Print summary for an Object of Class bootstrap_test
#' @description Prints summary for an object of class 'bootstrap_test'.
#' @param x object of class 'bootstrap_test'
#' @param ... further arguments (currently ignored)
#' @return The function returns input argument \code{x}.
print.summary.bootstrap_test <- function(x, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  class(x) <- "bootstrap_test"

  printCoefmat(x$tbl, signif.legend = TRUE, has.Pvalue = TRUE)
  
  cat("---\n")
  cat(paste0("The number of iterations of the bootstrap algorithm = ", 
             x$iter, "\n"))
  
  return(x)
}

#' @name bootstrap
bootstrap_combine <- function(...)
{
  # Collect the models into the list
  b <- list(...)
  
  # Retrieve the first set of bootstrap results
  out <- b[[1]]
  if (length(b) == 1)
  {
    return (out)
  }
  
  # Combine the first set with other sets
  for (i in length(b))
  {
    for (j in names(b[[i]]))
    {
      if (is.list(b[[i]][[j]]))
      {
        out[[j]] <- c(out[[j]], b[[i]][[j]])
      }
    }
    out$par <- rbind(out$par, b[[i]]$par)
    out$iter <- out$iter + b[[i]]$iter
  }
  out$cov <- cov(out$par)
  
  # Return the results
  return(out)
}