// [[Rcpp::depends(mnorm)]]
#define ARMA_DONT_USE_OPENMP
#include <RcppArmadillo.h>
using namespace Rcpp;

#ifdef _OPENMP
// [[Rcpp::plugins(openmp)]]
#endif

//' Log-likelihood Function of Multinomial Logit Model
//' @description Calculates log-likelihood function of multinomial logit model.
//' @param par vector of parameters.
//' @param control_lnL list with some additional parameters.
//' @param out_type string representing the output type of the function.
//' @param n_sim curretnly ignored.
//' @param n_cores the number of cores to be used.
//' @param regularization list of regularization parameters.
//' @export
// [[Rcpp::export(rng = false)]]
NumericMatrix lnL_mnlogit(const arma::vec par,
                          const List control_lnL,
                          const String out_type = "val",
                          const int n_sim = 1000,
                          const int n_cores = 1,
                          const Nullable<List> regularization = R_NilValue)
{
  // Determine whether gradient and Jacobian should be estimated
  const bool is_grad = (out_type == "grad");
  const bool is_jac = (out_type == "jac");
  const bool is_diff = is_grad | is_jac;

  // Get some dimensional data
  const int n_par = control_lnL["n_par"];
  const int n_alt = control_lnL["n_alt"];
  const int n_obs = control_lnL["n_obs"];
  const int n_coef = control_lnL["n_coef"];
  
  // Get data
  const arma::vec z = control_lnL["z"];
  const arma::mat W = control_lnL["W"];

  // Get indexes of observations associated with different
  // alternatives and regimes
  const arma::field<arma::uvec> ind_alt = control_lnL["ind_alt"];

  // Determine indexes of coefficients and 
  // covariances in the vector of parameters
  const arma::umat coef_ind_alt = control_lnL["coef_ind_alt"];
  
  // Get parameters of the regularization
  List regularization1(regularization);
  arma::uvec ridge_ind;
  arma::uvec lasso_ind;
  arma::vec ridge_scale;
  arma::vec ridge_location;
  arma::vec lasso_scale;
  arma::vec lasso_location;
  bool is_ridge = false;
  bool is_lasso = false;
  const bool is_regularization = regularization1.size() > 0;
  if (is_regularization)
  {
    // Ridge parameters
    is_ridge = regularization1.containsElementNamed("ridge_ind");
    
    if (is_ridge)
    {
      // Indexes
      arma::uvec ridge_ind_tmp = regularization1["ridge_ind"];
      ridge_ind = ridge_ind_tmp;
      
      // Scales
      arma::vec ridge_scale_tmp = regularization1["ridge_scale"];
      ridge_scale = ridge_scale_tmp;
      
      // Locations
      arma::vec ridge_location_tmp = regularization1["ridge_location"];
      ridge_location = ridge_location_tmp;
    }
    
    // Lasso parameters
    is_lasso = regularization1.containsElementNamed("lasso_ind");
    
    if (is_lasso)
    {
      // Indexes
      arma::uvec lasso_ind_tmp = regularization1["lasso_ind"];
      lasso_ind = lasso_ind_tmp;
      
      // Scales
      arma::vec lasso_scale_tmp = regularization1["lasso_scale"];
      lasso_scale = lasso_scale_tmp;
      
      // Locations
      arma::vec lasso_location_tmp = regularization1["lasso_location"];
      lasso_location = lasso_location_tmp;
    }
  }
  
  // Initialize Jacobian matrix
  arma::mat jac;
  if (is_diff)
  {
    jac = arma::mat(n_obs, n_par);
  }

  // Store the coefficients for each alternative
  arma::mat coef(n_coef, n_alt - 1);
  for (int i = 0; i < (n_alt - 1); i++) 
  {
    coef.col(i) = par.elem(coef_ind_alt.col(i));
  }

  // Estimate the linear index for each alternative
  arma::mat li(n_obs, n_alt);
  for (int i = 0; i < (n_alt - 1); i++)
  {
    li.col(i) = W * coef.col(i);
  }
  li.col(n_alt - 1).fill(0);

  // Calculate exponent of the linear index for each alternative
  arma::mat li_exp(n_obs, n_alt);
  for (int i = 0; i < (n_alt - 1); i++)
  {
    li_exp.col(i) = exp(li.col(i));
  }
  li_exp.col(n_alt - 1).fill(1);
  
  // Calculate probabilities
  arma::mat prob = li_exp.each_col() / sum(li_exp, 1);

  // Vector to store log-likelihood information
  arma::vec lnL(n_obs);

  // Calculate log-likelihood depending on the alternative
  for (int i = 0; i < n_alt; i++)
  {
    // Get indexes of observations related to the alternative
    int n_alt_obs = ind_alt(i).size();

    // Calculate log-likelihoods
    arma::uvec i_adj = {(unsigned int)i};
    lnL.elem(ind_alt(i)) = log(prob.submat(ind_alt(i), i_adj));

    // Differentiate if need
    if (is_diff)
    {
      arma::mat W_i = W.rows(ind_alt(i));
      arma::mat prob2 = arma::pow(prob, 2);
      for (int j = 0; j < (n_alt - 1); j++)
      {
        arma::uvec j_adj = {(unsigned int)j};
        if (i == j)
        {
          jac.submat(ind_alt(i), coef_ind_alt.col(j)) = 
            W_i.each_col() % 
            ((prob.submat(ind_alt(i), j_adj) - 
              prob2.submat(ind_alt(i), j_adj)) / 
             prob.submat(ind_alt(i), i_adj));
        }
        else
        {
          jac.submat(ind_alt(i), coef_ind_alt.col(j)) = 
            W_i.each_col() % (-prob.submat(ind_alt(i), j_adj));
        }
      }
    }
  }
  
  // Return jacobian if need
  if (is_jac)
  {
    return(wrap(jac));
  }

  // Return gradient if need
  if (is_grad)
  {
    arma::rowvec grad = sum(jac, 0);
    // Account for regularization if need
    if (is_regularization)
    {
      // Ridge
      if (is_ridge)
      {
        arma::vec par_ridge = par.elem(ridge_ind) - ridge_location;
        grad.elem(ridge_ind) = grad.elem(ridge_ind) - 
          2 * par_ridge % ridge_scale;
      }
      // Lasso
      if (is_lasso)
      {
        arma::vec par_lasso = par.elem(lasso_ind) - lasso_location;
        grad.elem(lasso_ind) = grad.elem(lasso_ind) - 
          arma::sign(par_lasso) % lasso_scale;
      }
    }
    return(wrap(grad));
  }

  // Calculate log-likelihood
  double lnL_val = sum(lnL);

  // Perform regularization if need
  if (is_regularization)
  {
    if (is_ridge)
    {
      arma::vec par_ridge = par.elem(ridge_ind) - ridge_location;
      lnL_val -= sum(pow(par_ridge, 2) % ridge_scale);
    }
    if (is_lasso)
    {
      arma::vec par_lasso = par.elem(lasso_ind) - lasso_location;
      lnL_val -= sum(arma::abs(par_lasso) % lasso_scale);
    }
  }
  
  // Return the log-likelihood
  NumericMatrix lnL_mat(1, 1);
  lnL_mat(0, 0) = lnL_val;

  return(lnL_mat);
}

//' Gradient of the Log-likelihood Function of Multinomial Probit Model
//' @description Calculates gradient of the log-likelihood function of 
//' multinomial probit model.
//' @param par vector of parameters.
//' @param control_lnL list with some additional parameters.
//' @param out_type string represeint the output type of the function.
//' @param n_sim the number of random draws for multivariate 
//' normal probabilities.
//' @param n_cores the number of cores to be used. 
//' @param regularization list of regularization parameters.
//' @export
// [[Rcpp::export(rng = false)]]
NumericMatrix grad_mnlogit(const arma::vec par,
                           const List control_lnL,
                           const String out_type = "grad",
                           const int n_sim = 1000,
                           const int n_cores = 1,
                           const Nullable<List> regularization = R_NilValue)
{
  return(lnL_mnlogit(par, control_lnL, "grad", 
                     n_sim, n_cores, regularization));
}
