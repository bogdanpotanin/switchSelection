# ---------------------------------------------------------
# Validation of the learners and predictors
# ---------------------------------------------------------

#' @title Validate and normalize a learner, predictor or control list
#'
#' @description Converts a single function, a named list or a list with
#' an \code{"all"} entry into a uniform named list of lists.
#'
#' @details
#' The function is used internally by
#' \code{\link[sdml]{mseldml}} to normalize the arguments
#' \code{learner}, \code{predictor}, \code{data_transform},
#' \code{control_learner}, \code{control_predictor} and
#' \code{control_transform} into a single canonical form: a named list
#' whose entries are lists of the required length.
#'
#' Four input forms are accepted:
#' \enumerate{
#' \item A single function is broadcast to every name in \code{l},
#' replicated \code{l[[name]]} times.
#' \item A list with an \code{"all"} entry uses that entry as the
#' function for every name in \code{l}, with the same replication.
#' \item A named list is used as is, with the following normalization:
#' entries shorter than their required count are recycled, entries of
#' the correct length are kept unchanged, and entries longer than
#' their required count raise an error.
#' \item The empty list \code{list()}, accepted only when
#' \code{type = "control"}, is interpreted as "no additional arguments"
#' for every name in \code{l}.
#' }
#'
#' An unnamed list with two or more elements is not a supported form
#' and raises an error. When \code{type = "function"}, every name in
#' \code{l} with a strictly positive count must be present in a named
#' list. Missing entries are allowed for \code{type = "control"}, and
#' names whose requested count is zero are always filled with empty
#' argument lists.
#'
#' @param x a function, a named list, an empty list, or a list with an
#' \code{"all"} entry.
#' @param l a named integer vector giving the required names and their
#' minimum number of entries. Names must be unique. Values must be
#' non-negative integers.
#' @param type a character, either \code{"function"} or
#' \code{"control"}. Determines how entries are normalized.
#'
#' @return A named list of lists of functions (when
#' \code{type = "function"}) or argument lists (when
#' \code{type = "control"}).
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{nuisance}}
#'
#' @examples
#' # Two required names: A twice, B once
#' l <- c(A = 2L, B = 1L)
#'
#' # A single function is broadcast to every name
#' str(nuisance_validate(mean, l))
#'
#' # The same result via the "all" shortcut
#' str(nuisance_validate(list(all = mean), l))
#'
#' # A named list is used as is
#' str(nuisance_validate(list(A = mean, B = sum), l))
#'
#' # An entry of length two is kept; an entry of length one is recycled
#' str(nuisance_validate(list(A = list(mean, sum), B = prod), l))
#'
#' # Control list: the empty list means "no arguments"
#' str(nuisance_validate(list(), l, type = "control"))
#'
#' @export
nuisance_validate <- function(x, l, type = "function")
{
  # Validate 'l'
  l_names <- names(l)
  if (is.null(l_names) || any(l_names == ""))
  {
    stop("The argument 'l' must be a named integer vector.")
  }
  if (anyDuplicated(l_names))
  {
    stop("The argument 'l' must have only unique names.")
  }
  if (!is.numeric(l) || anyNA(l) || any(l < 0L) || any(l != floor(l)))
  {
    stop("The argument 'l' must contain only non-negative integers.")
  }
  
  # Validate 'type'
  if (length(type) != 1L || !is.character(type) ||
      !(type %in% c("function", "control")))
  {
    stop("The argument 'type' must be either 'function' or 'control'.")
  }
  
  # Case 1: a single function is broadcast to every name
  if (is.function(x))
  {
    val      <- x
    x        <- vector(mode = "list", length = length(l_names))
    names(x) <- l_names
    for (i in seq_along(l_names))
    {
      cnt             <- l[[l_names[i]]]
      x[[l_names[i]]] <- rep(list(val), cnt)
    }
    return(x)
  }
  
  # Case 2: the "all" entry is broadcast to every name
  if (is.list(x) && !is.null(names(x)) && "all" %in% names(x))
  {
    val      <- x[["all"]]
    x        <- vector(mode = "list", length = length(l_names))
    names(x) <- l_names
    for (i in seq_along(l_names))
    {
      cnt             <- l[[l_names[i]]]
      x[[l_names[i]]] <- rep(list(val), cnt)
    }
    return(x)
  }
  
  # Case 3: the empty list is accepted only for 'type = "control"'
  if (is.list(x) && length(x) == 0L)
  {
    if (type == "function")
    {
      stop("The argument 'x' must not be an empty list when ",
           "type = \"function\".")
    }
    val      <- list()
    x        <- vector(mode = "list", length = length(l_names))
    names(x) <- l_names
    for (i in seq_along(l_names))
    {
      cnt             <- l[[l_names[i]]]
      x[[l_names[i]]] <- rep(list(val), cnt)
    }
    return(x)
  }
  
  # Case 4: any other form must be a named list
  if (!is.list(x) || is.null(names(x)))
  {
    stop("The argument 'x' must be a function, a named list, a list ",
         "with an 'all' entry, or an empty list.")
  }
  
  # Reject names of 'x' that were not declared in 'l'
  extra <- setdiff(names(x), l_names)
  if (length(extra) > 0L)
  {
    stop("The argument 'x' contains names not declared in 'l': ",
         paste(extra, collapse = ", "), ".")
  }
  
  # Normalize each entry of the named list
  for (i in seq_along(l_names))
  {
    # Extract the entry to normalize
    name  <- l_names[i]
    cnt   <- l[[name]]
    entry <- x[[name]]
    
    # Missing entries: functions require one when cnt > 0, controls do not
    if (is.null(entry))
    {
      if (type == "function" && cnt > 0L)
      {
        stop("The entry '", name, "' is missing from 'x'.")
      }
      x[[name]] <- rep(list(list()), cnt)
      next
    }
    
    # Function entries: must be a function or a list of functions
    if (type == "function")
    {
      # A single function is replicated cnt times
      if (is.function(entry))
      {
        x[[name]] <- rep(list(entry), cnt)
        next
      }
      # Any other entry must be a list of functions
      if (!is.list(entry))
      {
        stop("The entry '", name, "' must be a function or a list of ",
             "functions.")
      }
      # An empty list is allowed only when no functions are required
      if (length(entry) == 0L)
      {
        if (cnt == 0L)
        {
          x[[name]] <- list()
          next
        }
        stop("The entry '", name, "' contains an empty list of functions.")
      }
      # Every element must be a function
      if (!all(vapply(entry, is.function, logical(1L))))
      {
        stop("All elements of the entry '", name, "' must be functions.")
      }
      # An entry of the correct length is kept unchanged
      if (length(entry) == cnt)
      {
        next
      }
      # Longer entries are an error: the required count is fixed by 'l'
      if (length(entry) > cnt)
      {
        stop("The entry '", name, "' contains more functions (",
             length(entry), ") than required (", cnt, ").")
      }
      # Shorter entries are recycled to the required length
      reps      <- ceiling(cnt / length(entry))
      x[[name]] <- rep(entry, reps)[seq_len(cnt)]
      next
    }
    
    # Control entries: must be a list of arguments
    if (!is.list(entry))
    {
      stop("The entry '", name, "' must be a list of arguments.")
    }
    # A single control list is wrapped in an outer list
    if (cnt == 1L)
    {
      x[[name]] <- list(entry)
      next
    }
    # A list of exactly cnt argument lists is kept unchanged
    if (length(entry) == cnt &&
        all(vapply(entry, is.list, logical(1L))))
    {
      next
    }
    # A list of more than cnt argument lists is an error
    if (length(entry) > cnt &&
        all(vapply(entry, is.list, logical(1L))))
    {
      stop("The entry '", name, "' contains more argument lists (",
           length(entry), ") than required (", cnt, ").")
    }
    # Otherwise the control list is replicated cnt times
    x[[name]] <- rep(list(entry), cnt)
  }
  
  return(x)
}