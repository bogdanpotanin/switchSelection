# ---------------------------------------------------------
# Descriptive statistics of the data used in the fit
# ---------------------------------------------------------

#' @title Descriptive statistics of the data used in a mseldml fit
#'
#' @description Computes descriptive statistics of the outcome, the
#' treatment, the selection variables, the covariates and the exclusion
#' restrictions, optionally split by the treatment level.
#'
#' @details
#' The function operates on the data stored inside the fitted
#' \code{\link[sdml]{mseldml}} object, that is, on the sample that
#' actually entered the estimation after the missing-value handling
#' governed by \code{na_action}. Rows with \code{Y = NA} for not selected
#' observations are included, so their \code{Y} value contributes nothing
#' to the summary statistics because the summary functions use
#' \code{na.rm = TRUE}.
#'
#' Each table has one row per variable and six columns:
#' \itemize{
#' \item \code{mean} - the sample mean;
#' \item \code{se} - the standard error of the mean,
#'   \eqn{s / \sqrt{n}};
#' \item \code{min} - the sample minimum;
#' \item \code{median} - the sample median;
#' \item \code{max} - the sample maximum;
#' \item \code{role} - a character label with one of \code{"Y"},
#'   \code{"D"}, \code{"Z"}, \code{"X"} or \code{"W_Z"}, indicating
#'   which argument of \code{mseldml} the variable came from.
#' }
#' Row names are the variable names taken from the fitted object. The
#' rows are ordered as \code{Y}, \code{D} (only when \code{split =
#' FALSE}), \code{Z}, \code{X}, \code{W_Z}.
#'
#' @param model an object of class \code{"mseldml"}.
#' @param split one of \code{TRUE} (the default), \code{FALSE}, or
#' \code{"all"}. When \code{TRUE}, separate tables are produced for the
#' control group (\code{D == d0}), the treated group (\code{D == d1}),
#' and, if \code{D} takes additional values, an \code{Other} table for
#' the remaining observations. When \code{FALSE}, a single table is
#' produced for the whole estimation sample. When \code{"all"}, one
#' table is produced for every observed value of \code{D}.
#'
#' @return If \code{split = FALSE}, then a single data frame is returned.
#' Otherwise, the function returns a named list of data frames, one per subset. 
#' Names are of the form \code{"D=0"}, \code{"D=1"}, \code{"Other"} for 
#' \code{split = TRUE}, or \code{"D=<value>"} for \code{split = "all"}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{summary.mseldml}}
#'
#' @examples
#' \donttest{
#' library("mnorm")
#' set.seed(123)
#'
#' n  <- 1000
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#' w1 <- rnorm(n)
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' Z1 <- rbinom(n, size = 1, prob = 0.6)
#' Y  <- 1 + x1 + D + rnorm(n)
#' Y[Z1 == 0] <- NA
#'
#' model <- mseldml(X     = cbind(x1, x2), 
#'                  W_Z   = cbind(w1),
#'                  D     = D, 
#'                  Y     = Y,
#'                  Z     = cbind(Z1), 
#'                  z     = 1, 
#'                  z_max = 1)
#'
#' # Split by treatment status
#' desc <- mseldml_descriptive(model)
#' names(desc)
#' desc[[1]]
#'
#' # Single table for the whole estimation sample
#' mseldml_descriptive(model, split = FALSE)
#'
#' # Split by every observed value of D
#' mseldml_descriptive(model, split = "all")
#' }
#'
#' @export
mseldml_descriptive <- function(model, split = TRUE)
{
  # Validate the class of 'model'
  if (!inherits(model, "mseldml"))
  {
    stop("The argument 'model' must inherit from class 'mseldml'.")
  }
  
  # Validate 'split'
  split_valid <- (is.logical(split) && length(split) == 1L && !is.na(split)) ||
                 (is.character(split) && (length(split) == 1L)               &&
                 identical(split, "all"))
  if (!split_valid)
  {
    stop("The argument 'split' must be TRUE, FALSE, or \"all\".")
  }
  
  # Extract the data used in the fit
  if (is.null(model$data))
  {
    stop("The model object does not carry the data. Refit the model with ",
         "the current version of mseldml().")
  }
  d <- model$data
  
  # Helper: assemble a wide data frame from a subset of the data blocks
  build_df <- function(Y, D, Z, X, W_Z)
  {
    cols  <- list()
    roles <- character(0)
    nms   <- character(0)
    
    # Outcome
    cols[[length(cols) + 1L]] <- as.numeric(Y)
    nms                       <- c(nms, "Y")
    roles                     <- c(roles, "Y")
    
    # Treatment
    cols[[length(cols) + 1L]] <- as.numeric(D)
    nms                       <- c(nms, "D")
    roles                     <- c(roles, "D")
    
    # Selection variables
    if (!is.null(Z))
    {
      nm_Z <- colnames(Z)
      for (j in seq_len(ncol(Z)))
      {
        nm <- if (!is.null(nm_Z) && nzchar(nm_Z[j])) nm_Z[j] else paste0("Z", j)
        cols[[length(cols) + 1L]] <- as.numeric(Z[, j])
        nms                       <- c(nms, nm)
        roles                     <- c(roles, "Z")
      }
    }
    
    # Covariates
    if (!is.null(X))
    {
      nm_X <- colnames(X)
      for (j in seq_len(ncol(X)))
      {
        nm <- if (!is.null(nm_X) && nzchar(nm_X[j])) nm_X[j] else paste0("X", j)
        cols[[length(cols) + 1L]] <- as.numeric(X[, j])
        nms                       <- c(nms, nm)
        roles                     <- c(roles, "X")
      }
    }
    
    # Exclusion restrictions
    if (!is.null(W_Z))
    {
      nm_W <- colnames(W_Z)
      for (j in seq_len(ncol(W_Z)))
      {
        nm <- if (!is.null(nm_W) && nzchar(nm_W[j])) nm_W[j] else paste0("W_Z", j)
        cols[[length(cols) + 1L]] <- as.numeric(W_Z[, j])
        nms                       <- c(nms, nm)
        roles                     <- c(roles, "W_Z")
      }
    }
    
    # Assemble the data frame
    df <- as.data.frame(cols, stringsAsFactors = FALSE)
    colnames(df) <- nms
    attr(df, "roles") <- roles
    df
  }
  
  # Helper: compute the descriptive table for one data frame
  build_table <- function(df)
  {
    roles <- attr(df, "roles")
    
    # In a split table, D is constant, so drop it from the report
    if (length(unique(df[["D"]])) <= 1L)
    {
      df[["D"]] <- NULL
      roles     <- roles[roles != "D"]
    }
    
    # Helper function
    safe_extreme <- function(v, which)
    {
      v <- v[!is.na(v)]
      if (!length(v)) return (NA_real_)
      if (which == "min") min(v) else max(v)
    }
    
    # Compute the descriptive columns
    mu  <- sapply(df, function(v) mean(v, na.rm = TRUE))
    se  <- sapply(df, function(v)
    {
      v <- v[!is.na(v)]
      if (length(v) < 2L) return (NA_real_)
      sd(v) / sqrt(length(v))
    })
    mn  <- vapply(df, safe_extreme, numeric(1L), which = "min")
    med <- sapply(df, function(v) median(v, na.rm = TRUE))
    mx  <- vapply(df, safe_extreme, numeric(1L), which = "max")
    
    # Assemble the table
    tab <- data.frame(mean   = mu,
                      se     = se,
                      min    = mn,
                      median = med,
                      max    = mx,
                      role   = roles,
                      stringsAsFactors = FALSE)
    rownames(tab) <- names(df)
    tab
  }
  
  # Extract the raw blocks
  Y   <- d$Y
  D   <- d$D
  Z   <- d$Z
  X   <- d$X
  W_Z <- d$W_Z
  
  # Fetch d0 and d1 from the fitted object
  d0 <- model$d0
  d1 <- model$d1
  
  # Single table
  if (isFALSE(split))
  {
    df  <- build_df(Y, D, Z, X, W_Z)
    tab <- build_table(df)
    class(tab) <- c("mseldml_descriptive", class(tab))
    return (tab)
  }
  
  # Split by treatment status: control, treated, other
  if (isTRUE(split))
  {
    out <- list()
    
    idx_c <- which(D == d0)
    if (length(idx_c) > 0L)
    {
      out[[paste0("D=", d0)]] <- build_table(
        build_df(Y[idx_c], D[idx_c],
                 if (is.null(Z)) NULL else Z[idx_c, , drop = FALSE],
                 X[idx_c, , drop = FALSE],
                 W_Z[idx_c, , drop = FALSE])
      )
    }
    
    idx_t <- which(D == d1)
    if (length(idx_t) > 0L)
    {
      out[[paste0("D=", d1)]] <- build_table(
        build_df(Y[idx_t], D[idx_t],
                 if (is.null(Z)) NULL else Z[idx_t, , drop = FALSE],
                 X[idx_t, , drop = FALSE],
                 W_Z[idx_t, , drop = FALSE])
      )
    }
    
    idx_o <- which(!(D %in% c(d0, d1)))
    if (length(idx_o) > 0L)
    {
      out[["Other"]] <- build_table(
        build_df(Y[idx_o], D[idx_o],
                 if (is.null(Z)) NULL else Z[idx_o, , drop = FALSE],
                 X[idx_o, , drop = FALSE],
                 W_Z[idx_o, , drop = FALSE])
      )
    }
    
    class(out) <- c("mseldml_descriptive", class(out))
    return (out)
  }
  
  # Split by every observed value of D
  if (is.character(split) && identical(split, "all"))
  {
    vals <- sort(unique(D))
    out  <- vector(mode = "list", length = length(vals))
    for (k in seq_along(vals))
    {
      v   <- vals[k]
      idx <- which(D == v)
      out[[k]] <- build_table(
        build_df(Y[idx], D[idx],
                 if (is.null(Z)) NULL else Z[idx, , drop = FALSE],
                 X[idx, , drop = FALSE],
                 W_Z[idx, , drop = FALSE])
      )
    }
    names(out) <- paste0("D=", vals)
    class(out) <- c("mseldml_descriptive", class(out))
    
    # Return the results
    return (out)
  }
}

#' @title Print descriptive statistics from a mseldml fit
#'
#' @description Displays each table produced by
#' \code{\link[sdml]{mseldml_descriptive}} with a heading that names
#' the subset and columns aligned for readability.
#'
#' @param x an object returned by
#' \code{\link[sdml]{mseldml_descriptive}}, either a single data frame
#' or a named list of data frames.
#' @param digits an integer giving the number of decimal places used
#' when printing the numeric columns. Defaults to \code{3}.
#' @param ... further arguments. Currently ignored.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml_descriptive}}
#'
#' @export
print.mseldml_descriptive <- function(x, digits = 3, ...)
{
  # One table or a list of tables?
  is_list <- is.list(x) && !is.data.frame(x)
  
  if (!is_list)
  {
    .mseldml_print_descriptive_table(x, label = NULL, digits = digits)
  }
  else
  {
    for (nm in names(x))
    {
      .mseldml_print_descriptive_table(x[[nm]],
                                       label = nm,
                                       digits = digits)
    }
  }
  
  return (invisible(x))
}

#' @title Print one descriptive-statistics table
#'
#' @description Internal helper for
#' \code{\link[sdml]{print.mseldml_descriptive}}. Formats the numeric
#' columns of a single table and prints it with an optional heading.
#'
#' @param tab a data frame with columns \code{mean}, \code{se},
#' \code{min}, \code{median}, \code{max} and \code{role}.
#' @param label an optional character string used as the heading. If
#' \code{NULL}, no heading is printed.
#' @param digits the number of decimal places.
#'
#' @return The table, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml_descriptive}}
#'
#' @keywords internal
.mseldml_print_descriptive_table <- function(tab, label, digits = 3)
{
  # Heading
  if (!is.null(label))
  {
    n_width <- 6L + nchar(label) + 6L
    cat("\n")
    cat(strrep("-", n_width), "\n", sep = "")
    cat("  ", label, "\n", sep = "")
    cat(strrep("-", n_width), "\n", sep = "")
  }
  
  # Format the numeric columns to a fixed number of decimals
  num_cols <- c("mean", "se", "min", "median", "max")
  disp <- data.frame(Mean   = formatC(tab$mean,   digits = digits,
                                      format = "f"),
                     SE     = formatC(tab$se,     digits = digits,
                                      format = "f"),
                     Min    = formatC(tab$min,    digits = digits,
                                      format = "f"),
                     Median = formatC(tab$median, digits = digits,
                                      format = "f"),
                     Max    = formatC(tab$max,    digits = digits,
                                      format = "f"),
                     Role   = tab$role,
                     row.names = rownames(tab),
                     stringsAsFactors = FALSE)
  
  # Print the formatted table
  print(disp, right = TRUE, quote = FALSE)
  
  # Return the results
  return (invisible(tab))
}