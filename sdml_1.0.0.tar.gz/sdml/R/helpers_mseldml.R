# ---------------------------------------------------------
# Internal helper: resolve a `data` argument to a matrix/vector
# ---------------------------------------------------------

#' @title Resolve column names to a matrix or vector
#'
#' @description Extracts a subset of columns of a data frame by name
#' and returns it as a numeric matrix or a numeric vector. Used by
#' \code{\link[sdml]{mseldml}} to implement the data-frame interface.
#'
#' @details
#' When the \code{data} argument of \code{mseldml} is supplied, the
#' arguments \code{X}, \code{W_Z}, \code{D}, \code{Y} and \code{Z} are
#' interpreted as character vectors of column names rather than as
#' numeric objects. This helper performs the extraction and returns
#' the result in the form the estimator expects.
#'
#' If \code{as_matrix = TRUE}, the selected columns are coerced to a
#' numeric matrix via \code{as.matrix}. If \code{as_matrix = FALSE},
#' exactly one column must be named and it is coerced to a numeric
#' vector. In both cases, the values are not further validated; that
#' is the responsibility of the caller.
#'
#' A \code{NULL} value of \code{cols} is returned unchanged, so the
#' caller can use \code{mseldml_resolve_data(data, Z, "Z")} without a
#' special case for \code{Z = NULL}.
#'
#' @param data a data frame supplying the columns.
#' @param cols a character vector of column names, or \code{NULL}.
#' @param arg_name a character string naming the corresponding argument
#' of the calling function; used in error messages.
#' @param as_matrix a logical value. If \code{TRUE} (the default), the
#' result is a numeric matrix. If \code{FALSE}, then exactly one column
#' must be named and the result is a numeric vector.
#'
#' @return A numeric matrix, a numeric vector, or \code{NULL}.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @keywords internal
mseldml_resolve_data <- function(data, cols, arg_name, as_matrix = TRUE)
{
  # Return NULL if the argument was not supplied
  if (is.null(cols))
  {
    return (NULL)
  }
  
  # Validate that the argument is a character vector of column names
  if (!is.character(cols))
  {
    stop("The argument '", arg_name, "' must be a character vector of ",
         "column names when 'data' is supplied.")
  }
  
  # Verify that all requested columns exist in 'data'
  missing_cols <- setdiff(cols, names(data))
  if (length(missing_cols) > 0L)
  {
    stop("The argument '", arg_name, "' refers to column(s) not found in ",
         "'data': ", paste(missing_cols, collapse = ", "), ".")
  }
  
  # Extract the requested columns
  sub <- data[, cols, drop = FALSE]
  
  # Return the columns as a matrix
  if (as_matrix)
  {
    return (as.matrix(sub))
  }
  
  # Return the single column as a numeric vector and preserve its name
  if (ncol(sub) != 1L)
  {
    stop("The argument '", arg_name, "' must name a single column of ",
         "'data' when 'as_matrix = FALSE'.")
  }
  value <- sub[[1L]]
  if (!is.numeric(value))
  {
    stop("The column '", cols[[1L]], "' supplied for '", arg_name,
         "' must be numeric. Convert factor or character coding ",
         "explicitly before calling mseldml().")
  }
  vec                  <- as.numeric(value)
  attr(vec, "colname") <- cols[[1L]]
  
  # Return the results
  return (vec)
}

# ---------------------------------------------------------
# Internal helper: trimming
# ---------------------------------------------------------

#' @keywords internal
.mseldml_normalize_trim_prob <- function(trim_prob)
{
  if (!is.numeric(trim_prob)              ||
      !(length(trim_prob) %in% c(1L, 2L)) ||
      anyNA(trim_prob)                    || 
      any(is.nan(trim_prob)))
  {
    stop("The argument 'trim_prob' must be a numeric scalar or a ",
         "length-2 vector.")
  }
  
  if (length(trim_prob) == 1L)
  {
    t <- trim_prob
    if (!is.finite(t) || t < 0 || t > 1)
    {
      stop("A scalar 'trim_prob' must lie in [0, 1].")
    }
    trim_prob <- if (t <= 0.5) c(t, Inf) else c(-Inf, t)
  }
  
  lo    <- trim_prob[1L]
  hi    <- trim_prob[2L]
  lo_ok <- (is.finite(lo) && lo >= 0 && lo <= 1) || (is.infinite(lo) && lo < 0)
  hi_ok <- (is.finite(hi) && hi >= 0 && hi <= 1) || (is.infinite(hi) && hi > 0)
  
  if (!lo_ok || !hi_ok || !(lo < hi))
  {
    stop("The argument 'trim_prob' must be an ordered probability ",
         "interval with endpoints in [0, 1] (or -Inf/Inf at the ",
         "respective ends).")
  }
  
  # Return the results
  return (trim_prob)
}

# ---------------------------------------------------------
# Internal helper: suggest stratification for small groups
# ---------------------------------------------------------

#' @keywords internal
.mseldml_suggest_strata <- function(D, Z, z, d0, d1, Z_joint, cf_folds)
{
  # A group is flagged when it has fewer than twice as many observations
  # as there are folds
  threshold <- 2L * as.integer(cf_folds)
  small     <- character(0)
  
  n_d0 <- sum(D == d0, na.rm = TRUE)
  n_d1 <- sum(D == d1, na.rm = TRUE)
  if (n_d0 < threshold)
  {
    small <- c(small, paste0("D == d0: n = ", n_d0))
  }
  if (n_d1 < threshold)
  {
    small <- c(small, paste0("D == d1: n = ", n_d1))
  }
  
  if (!is.null(Z))
  {
    n_z1 <- sum(Z_joint == 1L, na.rm = TRUE)
    if (n_z1 < threshold)
    {
      small <- c(small, paste0("Z_tilde == 1: n = ", n_z1))
    }
    for (j in seq_len(ncol(Z)))
    {
      n_j <- sum(Z[, j] == z[j], na.rm = TRUE)
      if (n_j < threshold)
      {
        small <- c(small, paste0("Z[, ", j, "] == ", z[j],
                                 ": n = ", n_j))
      }
    }
  }
  
  if (length(small) > 0L)
  {
    warning("Some groups are small relative to 'cf_folds = ", cf_folds,
            "' (threshold = 2 * cf_folds = ", threshold, "): ",
            paste(small, collapse = "; "),
            ". Consider passing 'strata' to 'mseldml()' to balance the ",
            "folds, for example 'strata = cbind(D, Z_tilde)'. The ",
            "warning may be printed once per repetition when ",
            "'n_rep > 1'.")
  }
  
  # Return the results
  invisible(NULL)
}

# ---------------------------------------------------------
# Internal helper: safe quantile computation
# ---------------------------------------------------------

#' @keywords internal
.mseldml_quantile_safe <- function(v, probs)
{
  v <- v[is.finite(v)]
  if (length(v) == 0L)
  {
    return (rep(NA_real_, length(probs)))
  }
  val <- as.numeric(stats::quantile(v, 
                                    probs = probs, 
                                    na.rm = TRUE, 
                                    names = FALSE))
  # Return the results
  return (val)
}

# ---------------------------------------------------------
# Internal helper: cluster-sum covariance of an influence-function matrix
# ---------------------------------------------------------

#' @keywords internal
.mseldml_cluster_cov <- function(EIF, cluster, n, correction = TRUE)
{
  if (is.null(cluster))
  {
    return(crossprod(EIF) / n^2)
  }
  cl_fac  <- droplevels(as.factor(cluster))
  S       <- rowsum(EIF, cl_fac, reorder = FALSE)
  C       <- nrow(S)
  cov_mat <- crossprod(S) / n^2
  if (correction && C > 1L)
  {
    cov_mat <- cov_mat * (C / (C - 1))
  }
  cov_mat
}