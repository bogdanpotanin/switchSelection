# ---------------------------------------------------------
# Implementation of the data transformation method
# ---------------------------------------------------------

#' @title Default transformation of the data
#'
#' @description Appends polynomial columns to the data.
#'
#' @details
#'
#' The function provides a polynomial transformation of the groups (blocks)
#' of the data \code{x} defined in the list \code{vars}.
#'
#' \strong{Naming of the appended columns}
#'
#' Appended columns are named after the source columns of \code{x}. A
#' single-column term is named \code{<name>_<exponent>}, so the square
#' of a column named \code{X2} becomes \code{X2_2}. A multi-column term
#' chains the source columns and their exponents with underscores, so
#' \eqn{X2 \cdot X3} becomes \code{X2_1_X3_1} and
#' \eqn{X2^{2} \cdot X3^{3}} becomes \code{X2_2_X3_3}. A source column
#' without a name is referred to by its absolute position in \code{x},
#' so the square of column 4 becomes \code{4_2}.
#'
#' @template template_x_ind_vars
#' @param interactions a logical value. If \code{FALSE} (the default),
#' then polynomials have no interaction terms. If \code{TRUE}, the
#' interactions (cross-products), such as \eqn{x_{1}^{2} \cdot x_{2}^{3}},
#' are also used.
#' @param vars a named list specifying which columns of \code{x} to
#' transform. Let \code{l} be a name in \code{vars}. If \code{l ==
#' "all"}, the block is the whole matrix \code{x}; if \code{l} appears
#' in \code{names(ind_vars)}, the block is the columns \code{ind_vars[[l]]};
#' otherwise \code{l} refers to no columns. Each entry is either a
#' single \code{NA}, transforming the whole block (valid only when the
#' block is non-empty), or a vector giving positions or names within
#' the block. When the block is empty, the vector must use absolute
#' positions or names of \code{x}. For example, \code{list("all" =
#' NA)} transforms every column of \code{x}, \code{list(X = NA)}
#' transforms the whole block \code{X}, \code{list(X = c(1, 3))}
#' transforms its 1st and 3rd columns, \code{list(X = c("X1", "X2"))}
#' transforms its columns \code{X1} and \code{X2}, and
#' \code{list("all" = c(1, 5))} transforms the 1st and 5th columns of
#' \code{x}. Names must be unique. Each entry receives its own maximum
#' degree from \code{degree}. Cross-products are generated between the
#' columns selected by each entry when \code{interactions = TRUE}.
#' @param degree the maximum polynomial degree for each entry of
#' \code{vars}. May be a single positive integer (applied to every
#' entry), an unnamed positive integer vector of length
#' \code{length(vars)} (matched to entries of \code{vars}
#' positionally), or a named positive integer vector or list whose
#' names match the names of \code{vars} (matched by name). For
#' example, \code{degree = 2} applies degree 2 to every entry,
#' \code{degree = c(2, 3)} applies degree 2 to the first entry and
#' degree 3 to the second, and \code{degree = c(X = 3, P = 2)} applies
#' degree 3 to \code{X} and degree 2 to \code{P}. All values must be
#' positive integers not less than 1. An entry of \code{vars} whose
#' degree equals 1 contributes no new columns.
#' @param ... further arguments (currently ignored).
#'
#' @return A numeric matrix. If every entry of \code{vars} has
#' \code{degree = 1}, \code{x} is returned unchanged. Otherwise
#' \code{x} is augmented with the polynomial columns.
#'
#' @examples
#' # A matrix with covariates X, treatment D, and probabilities P
#' x <- cbind(X1 = 1:5,
#'            X2 = 6:10,
#'            D  = c(0,   1,   0,   1,   1),
#'            P1 = c(0.2, 0.4, 0.3, 0.6, 0.5),
#'            P2 = c(0.7, 0.5, 0.8, 0.4, 0.6))
#'
#' # Correspondence between the groups (blocks) and the data
#' ind_vars <- list(X = c(1, 2), D = 3, P = c(4, 5))
#'
#' # -----------------------------------------------------
#' # Transforming the whole matrix
#' # -----------------------------------------------------
#'
#' # Second-order polynomial without interactions
#' data_transform_default(x, vars = list("all" = NA), degree = 2)
#'
#' # Second-order polynomial with interactions
#' data_transform_default(x, vars = list("all" = NA), degree = 2,
#'                        interactions = TRUE)
#'
#' # -----------------------------------------------------
#' # Transforming individual groups (blocks)
#' # -----------------------------------------------------
#'
#' # Transform the whole group 'X'
#' data_transform_default(x, vars = list(X = NA),
#'                        ind_vars = ind_vars, degree = 2)
#'
#' # Transform the whole group 'P'
#' data_transform_default(x, vars = list(P = NA),
#'                        ind_vars = ind_vars, degree = 2)
#'
#' # Transform the 1st column of 'X'
#' data_transform_default(x, vars = list(X = 1),
#'                        ind_vars = ind_vars, degree = 2)
#'
#' # Transform the column 'X2' of 'X'
#' data_transform_default(x, vars = list(X = "X2"),
#'                        ind_vars = ind_vars, degree = 2)
#'
#' # -----------------------------------------------------
#' # The three forms of 'degree'
#' # -----------------------------------------------------
#'
#' # Scalar: applied to every entry of 'vars'
#' data_transform_default(x, vars = list(X = NA, P = NA),
#'                        ind_vars = ind_vars, degree = 2)
#'
#' # Positional: degree 1 for 'X', degree 3 for 'P'
#' data_transform_default(x, vars = list(X = NA, P = NA),
#'                        ind_vars = ind_vars, degree = c(1, 3))
#'
#' # Named: matched by the labels of 'vars'
#' data_transform_default(x, vars = list(X = NA, P = NA),
#'                        ind_vars = ind_vars, degree = c(P = 3, X = 1))
#'
#' # -----------------------------------------------------
#' # Degree 1 contributes no new columns
#' # -----------------------------------------------------
#'
#' # The input matrix is returned unchanged
#' data_transform_default(x, vars = list(X = NA, P = NA),
#'                        ind_vars = ind_vars, degree = 1)
#' @export
data_transform_default <- function(x,
                                   ind_vars     = list(),
                                   interactions = FALSE,
                                   vars         = list("P" = NA),
                                   degree       = 1,
                                   ...)
{
  # Validate 'interactions'
  if (!is.logical(interactions) || length(interactions) != 1L ||
      is.na(interactions))
  {
    stop("The argument 'interactions' must be a single non-missing logical ",
         "value.")
  }
  
  # Get the number of variables
  n_vars <- length(vars)
  
  # Return the initial matrix if no transformations are required
  if (n_vars == 0L)
  {
    return (x)
  }
  
  # Validate 'vars'
  if (is.null(names(vars)) || any(names(vars) == ""))
  {
    stop("The argument 'vars' must be a named list.")
  }
  if (anyDuplicated(names(vars)))
  {
    stop("The argument 'vars' must have only unique names.")
  }
  
  # Save the names of the entries
  names_vars <- names(vars)
  
  # Validate 'degree' and normalize it to a plain integer vector
  if (is.list(degree))
  {
    # Convert a list into a vector
    degree <- unlist(degree, use.names = TRUE)
  }
  if (!is.numeric(degree) || length(degree) == 0L)
  {
    stop("The argument 'degree' must be a scalar, a vector of length ", n_vars,
         ", or a named vector/list.")
  }
  if (!is.null(names(degree)))
  {
    # Check for missing names in 'degree'
    miss <- setdiff(names_vars, names(degree))
    if (length(miss) > 0L)
    {
      stop("The argument 'degree' is missing for the following variables: ",
           paste(miss, collapse = ", "), ".")
    }
    degree <- degree[names_vars]
  }
  else if (length(degree) == 1L)
  {
    # Assign the same value to every degrees
    degree <- rep(degree, n_vars)
  }
  else if (length(degree) != n_vars)
  {
    stop("The argument 'degree' must be a scalar, a vector of length ", n_vars,
         ", or a named vector/list.")
  }
  if (anyNA(degree)    || any(!is.finite(degree)) ||
      any(degree < 1L) || any(degree != floor(degree)))
  {
    stop("The argument 'degree' must contain only finite positive ",
         "integers not less than 1.")
  }
  
  # Convert into integers
  degree <- as.integer(degree)
  
  # Return the initial matrix if all degrees equal 1
  if (all(degree == 1L))
  {
    return (x)
  }
  
  # Resolve each entry of 'vars' into a vector of column indices of 'x'
  x_names <- colnames(x)
  for (i in seq_len(n_vars))
  {
    # Resolve the label to a group of columns of 'x'
    label <- names_vars[i]
    value <- vars[[i]]
    if (label == "all")
    {
      group <- seq_len(ncol(x))
    }
    else if (hasName(x = ind_vars, name = label))
    {
      group <- ind_vars[[label]]
    }
    else
    {
      group <- NULL
    }
    
    # Validate that the resolved block refers to valid columns of 'x'
    if (!is.null(group))
    {
      if (!is.numeric(group) || anyNA(group) || any(!is.finite(group)) ||
          any(group != floor(group))         || any(group < 1L)        ||
          any(group > ncol(x)))
      {
        stop("The block '", label,
             "' in 'ind_vars' contains invalid column indices.")
      }
    }
    
    # Case 1: NA, use the whole group
    if (length(value) == 1L && is.na(value))
    {
      if (is.null(group))
      {
        stop("The entry 'vars$", label, "' is NA but '", label,
             "' is not present in 'ind_vars'.")
      }
      vars[[i]] <- group
    }
    
    # Case 2: integer vector, indexes within the group if it exists,
    # otherwise absolute indexes into 'x'
    else if (is.numeric(value))
    {
      if (anyNA(value) || any(!is.finite(value)) || any(value != floor(value)))
      {
        stop("The entry 'vars$", label,
             "' must contain finite integer column indices.")
      }
      
      base <- if (is.null(group)) ncol(x) else length(group)
      if (any(value < 1L) || any(value > base))
      {
        stop("The entry 'vars$", label, "' contains indexes outside 1:",
             base, ".")
      }
      if (anyDuplicated(value))
      {
        stop("The entry 'vars$", label, "' must not repeat a column index.")
      }
      
      vars[[i]] <- if (is.null(group))
      {
        as.integer(value)
      }
      else
      {
        group[as.integer(value)]
      }
    }
    
    # Case 3: character vector, names within the group if it exists,
    # otherwise names within 'x'
    else if (is.character(value))
    {
      target <- if (is.null(group)) x_names else x_names[group]
      if (is.null(target))
      {
        stop("The entry 'vars$", label, "' is a character vector, but ",
             "the corresponding columns have no names.")
      }
      idx <- match(value, target)
      if (anyNA(idx))
      {
        stop("The entry 'vars$", label, "' contains unknown column ",
             "names: ", paste(value[is.na(idx)], collapse = ", "), ".")
      }
      vars[[i]] <- if (is.null(group))
      {
        idx
      }
      else
      {
        group[idx]
      }
    }
    
    # Case 4: unsupported type
    else
    {
      stop("The entry 'vars$", label, "' must be NA, a numeric vector ",
           "of indexes, or a character vector of names.")
    }
    
    # Check the resolved indices
    if (length(vars[[i]]) == 0L)
    {
      stop("The entry 'vars$", label, "' has no columns.")
    }
  }
  
  # Build the expansion entry by entry
  for (i in seq_len(n_vars))
  {
    # Skip entries of degree 1
    d      <- degree[i]
    cols   <- as.integer(vars[[i]])
    n_cols <- length(cols)
    if (d == 1L)
    {
      next
    }
    
    # Subset the columns of this entry
    xs <- x[, cols, drop = FALSE]
    
    if (!interactions)
    {
      # Only univariate powers are needed: avoid enumerating cross-products
      n_terms <- n_cols * (d - 1L)
      g <- matrix(0L, nrow = n_terms, ncol = n_cols)
      k <- 0L
      for (m in seq_len(n_cols))
      {
        for (q in seq.int(2L, d))
        {
          k <- k + 1L
          g[k, m] <- q
        }
      }
    }
    else
    {
      g <- .mseldml_exponent_grid(n_cols, d)
    }
    # Build the terms
    x1 <- matrix(1, nrow(xs), nrow(g))
    for (m in seq_len(n_cols))
    {
      x1 <- x1 * outer(xs[, m], g[, m], `^`)
    }
    
    # Rename columns to the package convention
    colnames(x1) <- apply(g, 1L,
                          function(e)
                          {
                            pos <- e > 0L
                            v   <- if (is.null(x_names)) as.character(cols[pos])
                            else ifelse(is.na(x_names[cols[pos]]),
                                        as.character(cols[pos]),
                                        x_names[cols[pos]])
                            paste(paste0(v, "_", e[pos]), collapse = "_")
                          })
    
    # Append the new columns
    x <- cbind(x, x1)
  }
  
  return (x)
}

# ---------------------------------------------------------
# Helper
# ---------------------------------------------------------
.mseldml_exponent_grid <- function(n_cols, degree)
{
  if (n_cols < 1L || degree < 2L)
  {
    return(matrix(integer(0L), nrow = 0L, ncol = n_cols))
  }
  
  rows <- list()
  
  recurse <- function(prefix, remaining_cols, remaining_degree)
  {
    if (remaining_cols == 0L)
    {
      total <- sum(prefix)
      if (total >= 2L)
      {
        rows[[length(rows) + 1L]] <<- as.integer(prefix)
      }
      return(invisible(NULL))
    }
    
    for (e in 0L:remaining_degree)
    {
      recurse(c(prefix, e), remaining_cols - 1L, remaining_degree - e)
    }
    invisible(NULL)
  }
  
  recurse(integer(0L), n_cols, degree)
  if (length(rows) == 0L)
  {
    return(matrix(integer(0L), nrow = 0L, ncol = n_cols))
  }
  do.call(rbind, rows)
}