# ---------------------------------------------------------
# Internal helper: resolve a `data` argument to a matrix/vector
# ---------------------------------------------------------

#' @title Resolve column names to a matrix or vector
#'
#' @description Extracts a subset of columns of a data frame by name
#' and returns it as a numeric matrix or a numeric vector. Used by
#' \code{\link[sdml]{mseldml}} to implement the data-frame interface.
#'
#' @details
#' When the \code{data} argument of \code{mseldml} is supplied, the
#' arguments \code{X}, \code{W_Z}, \code{D}, \code{Y} and \code{Z} are
#' interpreted as character vectors of column names rather than as
#' numeric objects. This helper performs the extraction and returns
#' the result in the form the estimator expects.
#'
#' If \code{as_matrix = TRUE}, the selected columns are coerced to a
#' numeric matrix via \code{as.matrix}. If \code{as_matrix = FALSE},
#' exactly one column must be named and it is coerced to a numeric
#' vector. In both cases, the values are not further validated; that
#' is the responsibility of the caller.
#'
#' A \code{NULL} value of \code{cols} is returned unchanged, so the
#' caller can use \code{mseldml_resolve_data(data, Z, "Z")} without a
#' special case for \code{Z = NULL}.
#'
#' @param data a data frame supplying the columns.
#' @param cols a character vector of column names, or \code{NULL}.
#' @param arg_name a character string naming the corresponding argument
#' of the calling function; used in error messages.
#' @param as_matrix a logical value. If \code{TRUE} (the default), the
#' result is a numeric matrix. If \code{FALSE}, then exactly one column
#' must be named and the result is a numeric vector.
#'
#' @return A numeric matrix, a numeric vector, or \code{NULL}.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @keywords internal
mseldml_resolve_data <- function(data, cols, arg_name, as_matrix = TRUE)
{
  # Return NULL if the argument was not supplied
  if (is.null(cols))
  {
    return(NULL)
  }
  
  # Validate that the argument is a character vector of column names
  if (!is.character(cols))
  {
    stop("The argument '", arg_name, "' must be a character vector of ",
         "column names when 'data' is supplied.")
  }
  
  # Verify that all requested columns exist in 'data'
  missing_cols <- setdiff(cols, names(data))
  if (length(missing_cols) > 0L)
  {
    stop("The argument '", arg_name, "' refers to column(s) not found in ",
         "'data': ", paste(missing_cols, collapse = ", "), ".")
  }
  
  # Extract the requested columns
  sub <- data[, cols, drop = FALSE]
  
  # Return the columns as a matrix
  if (as_matrix)
  {
    return(as.matrix(sub))
  }
  
  # Return the single column as a vector
  if (ncol(sub) != 1L)
  {
    stop("The argument '", arg_name, "' must name a single column of ",
         "'data' when 'as_matrix = FALSE'.")
  }
  
  # Convert the single column into a vector, preserving its name
  vec        <- as.numeric(sub[[1L]])
  names(vec) <- cols
  
  # Return the results
  return (vec)
}