# ---------------------------------------------------------
# Implementations of the learners
# ---------------------------------------------------------

#' @title Learner based on glmnet
#'
#' @description Fits \code{glmnet} models, either two (one for each
#' treatment level) or a single one on the whole sample, using
#' cross-validated penalty selection.
#'
#' @details
#'
#' This is the default learner for \code{\link[sdml]{mseldml}}.
#' It uses lasso regression with cross-validated \eqn{\lambda} by
#' default.
#'
#' \strong{Family selection}
#'
#' When \code{auto_type = TRUE}, the family is chosen automatically:
#' \code{"binomial"} if \code{y} takes exactly the values \code{c(0, 1)},
#' and \code{"gaussian"} otherwise. If \code{y} uses a different binary
#' coding, set \code{auto_type = FALSE} and supply the family manually
#' through \code{control_glmnet$family}.
#'
#' @template template_two_learner
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param two_learner a logical value. If \code{TRUE} (the default) and
#' \code{D} is in \code{ind_vars}, the learner fits two models, one per
#' treatment level. If \code{FALSE}, a single model is fitted on the
#' whole sample with \code{D} kept as a regressor.
#' @param auto_type a logical value. If \code{TRUE} (the default), the
#' family is selected automatically.
#' @param control_glmnet a list of control arguments passed to
#' \code{\link[glmnet]{cv.glmnet}} and \code{\link[glmnet]{glmnet}}.
#'
#' @return A named list with elements:
#' \itemize{
#' \item \code{model0}, \code{model1} --- the fitted
#'   \code{\link[glmnet]{glmnet}} objects for the control and treated
#'   groups. In single-learner mode \code{model0} is an empty list and
#'   \code{model1} holds the model fitted on the whole sample.
#' \item \code{two_learner} --- a logical value indicating whether the
#'   two-learner split was used. This is the effective mode, which is
#'   \code{TRUE} only when \code{two_learner = TRUE} and \code{D} is in
#'   \code{ind_vars}.
#' }
#'
#' @seealso \code{\link[sdml]{predictor_glmnet}},
#' \code{\link[sdml]{learner_ranger}}
#'
#' @examples
#' # Simulate the data
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#'
#' # Two-learner estimation
#' xd      <- cbind(x, D = D)
#' fit_two <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3))
#' names(fit_two)
#' fit_two$two_learner
#'
#' # Single-learner estimation
#' fit_one <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' fit_one$two_learner
#'
#' # Single-learner estimation applied automatically
#' fit_no_D <- learner_glmnet(x = x, y = y, ind_vars = list())
#' fit_no_D$two_learner
#'
#' @export
learner_glmnet <- function(x, y,
                           d0             = 0,
                           d1             = 1,
                           ind_vars       = NULL,
                           two_learner    = TRUE,
                           auto_type      = TRUE,
                           control_glmnet = list(family  = "gaussian",
                                                 alpha   = 1,
                                                 nlambda = 10,
                                                 nfolds  = 3,
                                                 control = list(maxit = 1e+06)))
{
  # Validate 'two_learner'
  if (!is.logical(two_learner) || length(two_learner) != 1L ||
      is.na(two_learner))
  {
    stop("The argument 'two_learner' must be a single non-missing logical ",
         "value.")
  }
  
  # Select the family automatically when requested
  if (auto_type)
  {
    u <- unique(y[!is.na(y)])
    if (length(u) == 2L && setequal(u, c(0, 1)))
    {
      control_glmnet$family <- "binomial"
    }
    else
    {
      control_glmnet$family <- "gaussian"
    }
  }
  
  # Determine the effective mode: two learners require D in 'ind_vars'
  has_D         <- "D" %in% names(ind_vars)
  effective_two <- two_learner && has_D
  
  # Fit a single model on the whole sample
  if (!effective_two)
  {
    x_all <- as.matrix(x)
    y_all <- as.vector(y)
    
    model1 <- list()
    if (length(y_all) > 0)
    {
      args        <- c(list(x = x_all, y = y_all), control_glmnet)
      model_cv    <- do.call(what = glmnet::cv.glmnet, args = args)
      args        <- args[names(args) %in% names(formals(glmnet::glmnet))]
      args$lambda <- model_cv$lambda.min
      model1      <- do.call(what = glmnet::glmnet, args = args)
    }
    
    return(list(model0      = list(),
                model1      = model1,
                two_learner = FALSE))
  }
  
  # Split the sample by treatment level
  D    <- x[, ind_vars[["D"]]]
  ind1 <- which(D == d1)
  ind0 <- which(D == d0)
  
  # Split the regressors into treated and control subsamples
  x1 <- as.matrix(x[ind1, , drop = FALSE])
  x0 <- as.matrix(x[ind0, , drop = FALSE])
  x1 <- x1[, -ind_vars[["D"]], drop = FALSE]
  x0 <- x0[, -ind_vars[["D"]], drop = FALSE]
  y1 <- as.vector(y[ind1])
  y0 <- as.vector(y[ind0])
  
  # Initialize the two model containers
  model1 <- list()
  model0 <- list()
  
  # Fit the treated-group model with cross-validated lambda
  if (length(ind1) > 0)
  {
    args1        <- c(list(x = x1, y = y1), control_glmnet)
    model_cv1    <- do.call(what = glmnet::cv.glmnet, args = args1)
    args1        <- args1[names(args1) %in% names(formals(glmnet::glmnet))]
    args1$lambda <- model_cv1$lambda.min
    model1       <- do.call(what = glmnet::glmnet, args = args1)
  }
  
  # Fit the control-group model with cross-validated lambda
  if (length(ind0) > 0)
  {
    args0        <- c(list(x = x0, y = y0), control_glmnet)
    model_cv0    <- do.call(what = glmnet::cv.glmnet, args = args0)
    args0        <- args0[names(args0) %in% names(formals(glmnet::glmnet))]
    args0$lambda <- model_cv0$lambda.min
    model0       <- do.call(what = glmnet::glmnet, args = args0)
  }
  
  return(list(model0      = model0,
              model1      = model1,
              two_learner = TRUE))
}

#' @title Learner based on random forest
#'
#' @description Fits \code{ranger} models, either two (one for each
#' treatment level) or a single one on the whole sample.
#'
#' @details
#'
#' When \code{auto_type = TRUE}, the outcome is converted to a factor
#' and \code{probability = TRUE} is set only when \code{y} takes
#' exactly the values \code{c(0, 1)}. For any other binary coding, the
#' function treats \code{y} as a numeric outcome.
#'
#' @template template_two_learner
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param two_learner a logical value. If \code{TRUE} (the default) and
#' \code{D} is in \code{ind_vars}, the learner fits two models, one per
#' treatment level. If \code{FALSE}, a single model is fitted on the
#' whole sample with \code{D} kept as a regressor.
#' @param auto_type a logical value. If \code{TRUE} (the default), the
#' outcome type is selected automatically.
#' @param control_ranger a list of control arguments passed to
#' \code{\link[ranger]{ranger}}.
#'
#' @return A named list with elements:
#' \itemize{
#' \item \code{model0}, \code{model1} --- the fitted
#'   \code{\link[ranger]{ranger}} objects for the control and treated
#'   groups. In single-learner mode \code{model0} is an empty list and
#'   \code{model1} holds the model fitted on the whole sample.
#' \item \code{two_learner} --- a logical value indicating whether the
#'   two-learner split was used.
#' }
#'
#' @seealso \code{\link[sdml]{predictor_ranger}},
#' \code{\link[sdml]{learner_glmnet}}
#'
#' @examples
#' # A small data set: two regressors, a binary treatment D
#' set.seed(1)
#' x  <- cbind(X1 = rnorm(100), X2 = rnorm(100))
#' D  <- rbinom(100, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(100)
#'
#' # Two-learner estimation
#' xd <- cbind(x, D = D)
#' fit_two <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3))
#' fit_two$two_learner
#'
#' # Single-learner estimation
#' fit_one <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' fit_one$two_learner
#'
#' # Binary outcome: ranger switches to probability estimation
#' yb <- rbinom(100, size = 1, prob = plogis(x[, "X1"]))
#' fit_b <- learner_ranger(x = x, y = yb, ind_vars = list())
#' fit_b$model1$treetype
#'
#' @export
learner_ranger <- function(x, y,
                           d0             = 0,
                           d1             = 1,
                           ind_vars       = NULL,
                           two_learner    = TRUE,
                           auto_type      = TRUE,
                           control_ranger = list(num.trees     = 100,
                                                 min.node.size = 20))
{
  # Validate 'two_learner'
  if (!is.logical(two_learner) || length(two_learner) != 1L ||
      is.na(two_learner))
  {
    stop("The argument 'two_learner' must be a single non-missing logical ",
         "value.")
  }
  
  # Convert the outcome to a factor when it is binary
  if (auto_type)
  {
    u <- unique(y[!is.na(y)])
    if (length(u) == 2L && setequal(u, c(0, 1)))
    {
      y                          <- as.factor(y)
      control_ranger$probability <- TRUE
    }
  }
  
  # Determine the effective mode: two learners require D in 'ind_vars'
  has_D         <- "D" %in% names(ind_vars)
  effective_two <- two_learner && has_D
  
  # Fit a single model on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    y_all <- y
    
    model1 <- list()
    if (length(y_all) > 0)
    {
      args1  <- c(list(x = x_all, y = y_all), control_ranger)
      model1 <- do.call(what = ranger, args = args1)
    }
    
    return(list(model0      = list(),
                model1      = model1,
                two_learner = FALSE))
  }
  
  # Split the sample by treatment level
  D    <- x[, ind_vars[["D"]]]
  ind1 <- which(D == d1)
  ind0 <- which(D == d0)
  
  # Split the regressors into treated and control subsamples
  x1 <- as.data.frame(x[ind1, , drop = FALSE])
  x0 <- as.data.frame(x[ind0, , drop = FALSE])
  x1 <- x1[, -ind_vars[["D"]], drop = FALSE]
  x0 <- x0[, -ind_vars[["D"]], drop = FALSE]
  y1 <- y[ind1]
  y0 <- y[ind0]
  
  # Initialize the two model containers
  model1 <- list()
  model0 <- list()
  
  # Fit the treated-group model
  if (length(ind1) > 0)
  {
    args1  <- c(list(x = x1, y = y1), control_ranger)
    model1 <- do.call(what = ranger, args = args1)
  }
  
  # Fit the control-group model
  if (length(ind0) > 0)
  {
    args0  <- c(list(x = x0, y = y0), control_ranger)
    model0 <- do.call(what = ranger, args = args0)
  }
  
  return(list(model0      = model0,
              model1      = model1,
              two_learner = TRUE))
}