# ---------------------------------------------------------
# Implementations of the learners
# ---------------------------------------------------------

#' @title Learner based on glmnet
#'
#' @description Fits \code{glmnet} models, either two (one for each
#' treatment level) or a single one on the whole sample, using
#' cross-validated penalty selection.
#'
#' @details
#'
#' This is the default learner for \code{\link[sdml]{mseldml}}.
#' It uses lasso regression with cross-validated \eqn{\lambda} by
#' default.
#'
#' \strong{Family selection}
#'
#' When \code{auto_type = TRUE}, the family is chosen automatically:
#' \code{"binomial"} if \code{y} takes exactly the values \code{c(0, 1)},
#' and \code{"gaussian"} otherwise. If \code{y} uses a different binary
#' coding, set \code{auto_type = FALSE} and supply the family manually
#' through \code{control_glmnet$family}.
#'
#' @template template_two_learner
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param two_learner a logical value. If \code{TRUE} (the default) and
#' \code{D} is in \code{ind_vars}, the learner fits two models, one per
#' treatment level. If \code{FALSE}, a single model is fitted on the
#' whole sample with \code{D} kept as a regressor.
#' @param auto_type a logical value. If \code{TRUE} (the default), the
#' family is selected automatically.
#' @param control_glmnet a list of control arguments passed to
#' \code{\link[glmnet]{cv.glmnet}} and \code{\link[glmnet]{glmnet}}.
#'
#' @return A named list with elements:
#' \itemize{
#' \item \code{model0}, \code{model1} --- the fitted
#'   \code{\link[glmnet]{glmnet}} objects for the control and treated
#'   groups. In single-learner mode \code{model0} is an empty list and
#'   \code{model1} holds the model fitted on the whole sample.
#' \item \code{two_learner} --- a logical value indicating whether the
#'   two-learner split was used. This is the effective mode, which is
#'   \code{TRUE} only when \code{two_learner = TRUE} and \code{D} is in
#'   \code{ind_vars}.
#' }
#'
#' @seealso \code{\link[sdml]{predictor_glmnet}},
#' \code{\link[sdml]{learner_ranger}}
#'
#' @examples
#' # Simulate the data
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#'
#' # Two-learner estimation
#' xd      <- cbind(x, D = D)
#' fit_two <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3))
#' names(fit_two)
#' fit_two$two_learner
#'
#' # Single-learner estimation
#' fit_one <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' fit_one$two_learner
#'
#' # Single-learner estimation applied automatically
#' fit_no_D <- learner_glmnet(x = x, y = y, ind_vars = list())
#' fit_no_D$two_learner
#'
#' @export
learner_glmnet <- function(x, y,
                           d0             = 0,
                           d1             = 1,
                           ind_vars       = NULL,
                           two_learner    = TRUE,
                           auto_type      = TRUE,
                           control_glmnet = list(family  = "gaussian",
                                                 alpha   = 1,
                                                 nlambda = 10,
                                                 nfolds  = 3,
                                                 control = list(maxit = 1e+06)))
{
  # Validate 'two_learner'
  if (!is.logical(two_learner) || length(two_learner) != 1L ||
      is.na(two_learner))
  {
    stop("The argument 'two_learner' must be a single non-missing logical ",
         "value.")
  }
  
  # Select the family automatically when requested
  if (auto_type)
  {
    u <- unique(y[!is.na(y)])
    if (length(u) == 2L && setequal(u, c(0, 1)))
    {
      control_glmnet$family <- "binomial"
    }
    else if (length(u) == 1L && u %in% c(0, 1))
    {
      stop("The outcome 'y' takes only the value ", u,
           " in this training fold. A binary nuisance requires both ",
           "classes. Consider stratified folds or a learner that ",
           "handles this case.")
    }
    else
    {
      control_glmnet$family <- "gaussian"
    }
  }
  
  # Determine the effective mode: two learners require D in 'ind_vars'
  has_D         <- "D" %in% names(ind_vars)
  effective_two <- two_learner && has_D
  
  # Fit a single model on the whole sample
  if (!effective_two)
  {
    x_all <- as.matrix(x)
    y_all <- as.vector(y)
    
    model1 <- list()
    if (length(y_all) > 0)
    {
      args        <- c(list(x = x_all, y = y_all), control_glmnet)
      model_cv    <- do.call(what = cv.glmnet, args = args)
      args        <- args[names(args) %in% names(formals(glmnet))]
      args$lambda <- model_cv$lambda.min
      model1      <- do.call(what = glmnet, args = args)
    }
    
    return (list(model0      = list(),
                 model1      = model1,
                 two_learner = FALSE))
  }
  
  # Split the sample by treatment level
  D        <- x[, ind_vars[["D"]]]
  D_levels <- sort(unique(D[!is.na(D)]))
  
  # Initialize the model container
  models        <- vector(mode = "list", length = length(D_levels))
  names(models) <- as.character(D_levels)
  
  # Fit a separate model for every treatment level
  for (k in seq_along(D_levels))
  {
    # Level of the treatment variable
    lv <- D_levels[k]
    
    # Observations with this treatment level
    ind_lv <- which(D == lv)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.matrix(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    y_lv <- as.vector(y[ind_lv])
    
    # Fit the model for this treatment level with cross-validated lambda
    args_lv        <- c(list(x = x_lv, y = y_lv), control_glmnet)
    model_cv_lv    <- do.call(what = cv.glmnet, args = args_lv)
    args_lv        <- args_lv[names(args_lv) %in% names(formals(glmnet))]
    args_lv$lambda <- model_cv_lv$lambda.min
    models[[k]]    <- do.call(what = glmnet, args = args_lv)
  }
  
  # Backward-compatible pointers for the control and treated groups
  model0 <- models[[as.character(d0)]]
  model1 <- models[[as.character(d1)]]
  if (is.null(model0)) model0 <- list()
  if (is.null(model1)) model1 <- list()
  
  # Return the results
  return (list(model0      = model0,
               model1      = model1,
               models      = models,
               two_learner = TRUE))
}

#' @title Learner based on random forest
#'
#' @description Fits \code{ranger} models, either two (one for each
#' treatment level) or a single one on the whole sample.
#'
#' @details
#'
#' When \code{auto_type = TRUE}, the outcome is converted to a factor
#' and \code{probability = TRUE} is set only when \code{y} takes
#' exactly the values \code{c(0, 1)}. For any other binary coding, the
#' function treats \code{y} as a numeric outcome.
#'
#' @template template_two_learner
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param two_learner a logical value. If \code{TRUE} (the default) and
#' \code{D} is in \code{ind_vars}, the learner fits two models, one per
#' treatment level. If \code{FALSE}, a single model is fitted on the
#' whole sample with \code{D} kept as a regressor.
#' @param auto_type a logical value. If \code{TRUE} (the default), the
#' outcome type is selected automatically.
#' @param control_ranger a list of control arguments passed to
#' \code{\link[ranger]{ranger}}.
#'
#' @return A named list with elements:
#' \itemize{
#' \item \code{model0}, \code{model1} --- the fitted
#'   \code{\link[ranger]{ranger}} objects for the control and treated
#'   groups. In single-learner mode \code{model0} is an empty list and
#'   \code{model1} holds the model fitted on the whole sample.
#' \item \code{two_learner} --- a logical value indicating whether the
#'   two-learner split was used.
#' }
#'
#' @seealso \code{\link[sdml]{predictor_ranger}},
#' \code{\link[sdml]{learner_glmnet}}
#'
#' @examples
#' # A small data set: two regressors, a binary treatment D
#' set.seed(1)
#' x  <- cbind(X1 = rnorm(100), X2 = rnorm(100))
#' D  <- rbinom(100, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(100)
#'
#' # Two-learner estimation
#' xd <- cbind(x, D = D)
#' fit_two <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3))
#' fit_two$two_learner
#'
#' # Single-learner estimation
#' fit_one <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' fit_one$two_learner
#'
#' # Binary outcome: ranger switches to probability estimation
#' yb <- rbinom(100, size = 1, prob = plogis(x[, "X1"]))
#' fit_b <- learner_ranger(x = x, y = yb, ind_vars = list())
#' fit_b$model1$treetype
#'
#' @export
learner_ranger <- function(x, y,
                           d0             = 0,
                           d1             = 1,
                           ind_vars       = NULL,
                           two_learner    = TRUE,
                           auto_type      = TRUE,
                           control_ranger = list(num.trees     = 100,
                                                 min.node.size = 20))
{
  # Validate 'two_learner'
  if (!is.logical(two_learner) || length(two_learner) != 1L ||
      is.na(two_learner))
  {
    stop("The argument 'two_learner' must be a single non-missing logical ",
         "value.")
  }
  
  # Convert the outcome to a factor when it is binary
  if (auto_type)
  {
    u <- unique(y[!is.na(y)])
    if (length(u) == 2L && setequal(u, c(0, 1)))
    {
      y                          <- as.factor(y)
      control_ranger$probability <- TRUE
    }
    else if (length(u) == 1L && u %in% c(0, 1))
    {
      stop("The outcome 'y' takes only the value ", u,
           " in this training fold. A binary nuisance requires both ",
           "classes. Consider stratified folds or a learner that ",
           "handles this case.")
    }
  }
  
  # Determine the effective mode: two learners require D in 'ind_vars'
  has_D         <- "D" %in% names(ind_vars)
  effective_two <- two_learner && has_D
  
  # Fit a single model on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    y_all <- y
    
    model1 <- list()
    if (length(y_all) > 0)
    {
      args1  <- c(list(x = x_all, y = y_all), control_ranger)
      model1 <- do.call(what = ranger, args = args1)
    }
    
    return (list(model0      = list(),
                 model1      = model1,
                 two_learner = FALSE))
  }
  
  # Split the sample by treatment level
  D        <- x[, ind_vars[["D"]]]
  D_levels <- sort(unique(D[!is.na(D)]))
  
  # Initialize the model container
  models        <- vector(mode = "list", length = length(D_levels))
  names(models) <- as.character(D_levels)
  
  # Fit a separate model for every treatment level
  for (k in seq_along(D_levels))
  {
    # Level of the treatment variable
    lv <- D_levels[k]
    
    # Observations with this treatment level
    ind_lv <- which(D == lv)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.data.frame(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    y_lv <- y[ind_lv]
    
    # Fit the model for this treatment level
    args_lv     <- c(list(x = x_lv, y = y_lv), control_ranger)
    models[[k]] <- do.call(what = ranger, args = args_lv)
  }
  
  # Backward-compatible pointers for the control and treated groups
  model0 <- models[[as.character(d0)]]
  model1 <- models[[as.character(d1)]]
  if (is.null(model0)) model0 <- list()
  if (is.null(model1)) model1 <- list()
  
  # Return the results
  return (list(model0      = model0,
               model1      = model1,
               models      = models,
               two_learner = TRUE))
}

#' @title Learner based on glm
#'
#' @description Fits \code{glm} models, either two (one for each
#' treatment level) or a single one on the whole sample.
#'
#' @details
#'
#' This learner is intended for nuisances that are naturally modelled as
#' probabilities, such as the treatment propensity \code{D_prob} or the
#' selection probabilities \code{Z_prob}. The link function is
#' controlled through \code{control_glm$link}; the default is
#' \code{"logit"}, and \code{"probit"} is also supported. Because the
#' model is unregularized, a small number of covariates is recommended;
#' for large covariate sets, \code{\link[sdml]{learner_glmnet}} is
#' usually preferable.
#'
#' \strong{Family selection}
#'
#' When \code{auto_type = TRUE}, the family is chosen automatically:
#' \code{"binomial"} if \code{y} takes exactly the values \code{c(0, 1)},
#' and \code{"gaussian"} otherwise. If \code{y} uses a different binary
#' coding, set \code{auto_type = FALSE} and supply the family manually
#' through \code{control_glm$family}.
#'
#' @template template_two_learner
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param two_learner a logical value. If \code{TRUE} (the default) and
#' \code{D} is in \code{ind_vars}, the learner fits two models, one per
#' treatment level. If \code{FALSE}, a single model is fitted on the
#' whole sample with \code{D} kept as a regressor.
#' @param auto_type a logical value. If \code{TRUE} (the default), the
#' family is selected automatically.
#' @param control_glm a list of control arguments passed to
#' \code{\link[stats]{glm}}. The element \code{family} selects the
#' distribution; \code{"binomial"} and \code{"gaussian"} are supported.
#' The element \code{link} selects the link function used with the
#' binomial family; \code{"logit"} (the default) and \code{"probit"}
#' are supported. Any remaining elements (for example \code{maxit}) are
#' passed through unchanged.
#'
#' @return A named list with elements:
#' \itemize{
#' \item \code{model0}, \code{model1} --- the fitted
#'   \code{\link[stats]{glm}} objects for the control and treated
#'   groups. In single-learner mode \code{model0} is an empty list and
#'   \code{model1} holds the model fitted on the whole sample.
#' \item \code{two_learner} --- a logical value indicating whether the
#'   two-learner split was used. This is the effective mode, which is
#'   \code{TRUE} only when \code{two_learner = TRUE} and \code{D} is in
#'   \code{ind_vars}.
#' }
#'
#' @seealso \code{\link[sdml]{predictor_glm}},
#' \code{\link[sdml]{learner_glmnet}},
#' \code{\link[sdml]{learner_ranger}}
#'
#' @examples
#' # Simulate a small binary data set
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- rbinom(n, size = 1, prob = plogis(x[, "X1"]))
#'
#' # Two-learner estimation, logit link (default)
#' xd      <- cbind(x, D = D)
#' fit_two <- learner_glm(x = xd, y = y, ind_vars = list(D = 3))
#' fit_two$two_learner
#'
#' # Two-learner estimation, probit link
#' fit_probit <- learner_glm(x = xd, y = y, ind_vars = list(D = 3),
#'                           control_glm = list(family = "binomial",
#'                                              link   = "probit"))
#' fit_probit$two_learner
#'
#' # Single-learner estimation
#' fit_one <- learner_glm(x = xd, y = y, ind_vars = list(D = 3),
#'                        two_learner = FALSE)
#' fit_one$two_learner
#'
#' @export
learner_glm <- function(x, y,
                        d0          = 0,
                        d1          = 1,
                        ind_vars    = NULL,
                        two_learner = TRUE,
                        auto_type   = TRUE,
                        control_glm = list(family = "binomial",
                                           link   = "logit",
                                           maxit  = 100L))
{
  # Validate 'two_learner'
  if (!is.logical(two_learner) || length(two_learner) != 1L ||
      is.na(two_learner))
  {
    stop("The argument 'two_learner' must be a single non-missing logical ",
         "value.")
  }
  
  # Select the family automatically when requested
  if (auto_type)
  {
    u <- unique(y[!is.na(y)])
    if (length(u) == 2L && setequal(u, c(0, 1)))
    {
      control_glm$family <- "binomial"
    }
    else if (length(u) == 1L && u %in% c(0, 1))
    {
      stop("The outcome 'y' takes only the value ", u,
           " in this training fold. A binary nuisance requires both ",
           "classes. Consider stratified folds or a learner that ",
           "handles this case.")
    }
    else
    {
      control_glm$family <- "gaussian"
    }
  }
  
  # Resolve the family and link strings into a family object
  family_name <- control_glm$family
  link_name   <- control_glm$link
  if (is.null(family_name)) family_name <- "gaussian"
  if (is.null(link_name))   link_name   <- "logit"
  if (!is.character(family_name) || length(family_name) != 1L)
  {
    stop("The element 'control_glm$family' must be a single character ",
         "string.")
  }
  if (!is.character(link_name) || length(link_name) != 1L)
  {
    stop("The element 'control_glm$link' must be a single character ",
         "string.")
  }
  family_obj <- switch(family_name,
                       "binomial" = binomial(link = link_name),
                       "gaussian" = gaussian(),
                       stop("Unsupported family: ", family_name, ". ",
                            "Use 'binomial' or 'gaussian'."))
  
  # Remaining control arguments (family and link are handled separately)
  ctrl <- control_glm[setdiff(names(control_glm), c("family", "link"))]
  
  # Determine the effective mode: two learners require D in 'ind_vars'
  has_D         <- "D" %in% names(ind_vars)
  effective_two <- two_learner && has_D
  
  # Fit a single model on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    y_all <- as.vector(y)
    
    model1 <- list()
    if (length(y_all) > 0)
    {
      df1    <- cbind(y = y_all, x_all)
      args1  <- c(list(formula = y ~ ., data = df1,
                       family  = family_obj),
                  ctrl)
      model1 <- do.call(what = glm, args = args1)
    }
    
    return (list(model0      = list(),
                 model1      = model1,
                 two_learner = FALSE))
  }
  
  # Split the sample by treatment level
  D        <- x[, ind_vars[["D"]]]
  D_levels <- sort(unique(D[!is.na(D)]))
  
  # Initialize the model container
  models        <- vector(mode = "list", length = length(D_levels))
  names(models) <- as.character(D_levels)
  
  # Fit a separate model for every treatment level
  for (k in seq_along(D_levels))
  {
    # Level of the treatment variable
    lv <- D_levels[k]
    
    # Observations with this treatment level
    ind_lv <- which(D == lv)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.data.frame(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    y_lv <- as.vector(y[ind_lv])
    
    # Fit the model for this treatment level
    df_lv   <- cbind(y = y_lv, x_lv)
    args_lv <- c(list(formula = y ~ ., data = df_lv,
                      family  = family_obj),
                 ctrl)
    models[[k]] <- do.call(what = glm, args = args_lv)
  }
  
  # Backward-compatible pointers for the control and treated groups
  model0 <- models[[as.character(d0)]]
  model1 <- models[[as.character(d1)]]
  if (is.null(model0)) model0 <- list()
  if (is.null(model1)) model1 <- list()
  
  # Return the results
  return (list(model0      = model0,
               model1      = model1,
               models      = models,
               two_learner = TRUE))
}