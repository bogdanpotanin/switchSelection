# ---------------------------------------------------------
# Splitting of the sample
# ---------------------------------------------------------

#' @title Split a sample for cross-fitting
#'
#' @description Divides a sample size or an index vector into roughly
#' equal folds.
#'
#' @details
#' The elements of the sample are shuffled before being partitioned, so
#' the resulting folds are random rather than contiguous. If the sample
#' size is not divisible by \code{n_folds}, the first
#' \code{n \%\% n_folds} folds receive one extra observation each.
#'
#' @param x either an integer sample size (if \code{x_is_size = TRUE})
#' or an integer vector of indices (if \code{x_is_size = FALSE}).
#' @param n_folds a positive integer representing the number of folds.
#' @param x_is_size a logical value distinguishing a sample size from
#' an index vector. Defaults to \code{FALSE}.
#'
#' @return A list of length \code{n_folds} whose elements are integer
#' index vectors that partition \code{1:x} (if \code{x_is_size}) or
#' \code{x} (otherwise).
#'
#' @seealso \code{\link[sdml]{cf_ind_combine}},
#' \code{\link[sdml]{mseldml}}
#'
#' @examples
#' # Split a sample size into three folds
#' set.seed(123)
#' folds <- cf_ind_split(x = 10, n_folds = 3, x_is_size = TRUE)
#' folds
#'
#' # Every observation appears exactly once
#' sort(unlist(folds, use.names = FALSE))
#'
#' # Split an index vector into two folds
#' folds2 <- cf_ind_split(x = c(3, 7, 11, 15, 19), n_folds = 2,
#'                        x_is_size = FALSE)
#' folds2
#'
#' @export
cf_ind_split <- function(x, n_folds, x_is_size = FALSE)
{
  # Validate 'x' as a sample size and draw a shuffled index vector
  if (x_is_size)
  {
    if (length(x) != 1L || !is.finite(x) || x < 1 || x != floor(x))
    {
      stop("The argument 'x' must be a positive integer sample size.")
    }
    ind <- sample.int(x)
  }
  # Validate 'x' as an index vector and shuffle it
  else
  {
    if (length(x) == 0L || anyNA(x) ||
        any(!is.finite(x)) || any(x != floor(x)))
    {
      stop("The argument 'x' must be a nonempty vector of integer indices.")
    }
    ind <- x[sample.int(length(x))]
  }
  
  # Get the number of elements to split
  n <- length(ind)
  
  # Validate 'n_folds'
  if (length(n_folds) != 1L || !is.finite(n_folds) ||
      n_folds != floor(n_folds) || n_folds < 1L || n_folds > n)
  {
    stop("The argument 'n_folds' must be an integer between 1 and ",
         "length(x).")
  }
  
  # Compute the size of each fold, distributing the remainder
  group_sizes <- rep(n %/% n_folds, n_folds)
  remainder   <- n %% n_folds
  if (remainder > 0L)
  {
    group_sizes[seq_len(remainder)] <- group_sizes[seq_len(remainder)] + 1L
  }
  
  # Assign each element to a fold and split
  groups <- rep(seq_len(n_folds), times = group_sizes)
  
  # Return the results
  return (split(ind, factor(groups, levels = seq_len(n_folds))))
}

#' @title Combine index vectors from several folds
#'
#' @description Concatenates the elements of \code{x} listed in
#' \code{folds}.
#'
#' @details
#' Negative indices are interpreted as positions to exclude, in the
#' same way as R's ordinary negative indexing. This is convenient for
#' building outer training samples as the complement of a single fold.
#'
#' @param x a list of integer index vectors.
#' @param folds a vector of fold indices or their negations.
#'
#' @return An integer vector.
#'
#' @seealso \code{\link[sdml]{cf_ind_split}},
#' \code{\link[sdml]{mseldml}}
#'
#' @examples
#' # Split a sample into three folds
#' set.seed(123)
#' folds <- cf_ind_split(x = 10, n_folds = 3, x_is_size = TRUE)
#' folds
#'
#' # Combine the first two folds
#' cf_ind_combine(folds, c(1, 2))
#'
#' # Combine all folds
#' cf_ind_combine(folds, 1:3)
#'
#' # Exclude one fold: the complement of fold 1
#' cf_ind_combine(folds, -1)
#'
#' @export
cf_ind_combine <- function(x, folds)
{
  # Get the number of folds
  n_folds <- length(x)
  
  # Convert negative indices into their positive complements
  if (any(folds < 0))
  {
    folds <- (1:n_folds)[folds]
  }
  
  # Concatenate the selected fold index vectors
  val <- NULL
  for (i in folds)
  {
    val <- c(val, x[[i]])
  }
  
  # Return the results
  return(val)
}