# ---------------------------------------------------------
# Splitting of the sample
# ---------------------------------------------------------

#' @title Split a sample for cross-fitting
#'
#' @description Divides a sample size or an index vector into roughly
#' equal folds.
#'
#' @details
#' The elements of the sample are shuffled before being partitioned, so
#' the resulting folds are random rather than contiguous. If the sample
#' size is not divisible by \code{n_folds}, the first
#' \code{n \%\% n_folds} folds receive one extra observation each.
#'
#' @param x either an integer sample size (if \code{x_is_size = TRUE})
#' or an integer vector of indices (if \code{x_is_size = FALSE}).
#' @param n_folds a positive integer representing the number of folds.
#' @param x_is_size a logical value distinguishing a sample size from
#' an index vector. Defaults to \code{FALSE}.
#' @param strata an optional vector, matrix or data frame with one entry
#' (or row) per observation, used to construct stratified folds. Each
#' distinct combination of strata values defines a stratum, and folds
#' are drawn by round-robin assignment within each stratum. Multiple
#' columns are combined into a single factor. Defaults to \code{NULL},
#' which draws not stratified folds.
#' @param cluster an optional vector with one entry per observation in
#' \code{x} (or of length \code{x} when \code{x_is_size = TRUE}),
#' identifying the cluster of each observation. When supplied, folds
#' are constructed at the cluster level: every observation of a
#' cluster is assigned to the same fold, and clusters are balanced
#' greedily by size. If \code{strata} is also supplied, the stratum
#' of each cluster is the most common stratum among its observations
#' (with a warning when a cluster spans multiple strata). Defaults
#' to \code{NULL}, which draws folds at the observation level.
#'
#' @return A list of length \code{n_folds} whose elements are integer
#' index vectors that partition \code{1:x} (if \code{x_is_size}) or
#' \code{x} (otherwise).
#'
#' @seealso \code{\link[sdml]{cf_ind_combine}},
#' \code{\link[sdml]{mseldml}}
#'
#' @examples
#' # Split a sample size into three folds
#' set.seed(123)
#' folds <- cf_ind_split(x = 10, n_folds = 3, x_is_size = TRUE)
#' folds
#'
#' # Every observation appears exactly once
#' sort(unlist(folds, use.names = FALSE))
#'
#' # Split an index vector into two folds
#' folds2 <- cf_ind_split(x = c(3, 7, 11, 15, 19), n_folds = 2,
#'                        x_is_size = FALSE)
#' folds2
#'
#' @export
cf_ind_split <- function(x, n_folds, 
                         x_is_size = FALSE, 
                         strata    = NULL, 
                         cluster   = NULL)
{
  # Validate 'x_is_size'
  if (!is.logical(x_is_size) || length(x_is_size) != 1L || is.na(x_is_size))
  {
    stop("The argument 'x_is_size' must be a single non-missing logical ",
         "value.")
  }
  
  # Validate 'x' as a sample size or as an index vector
  if (x_is_size)
  {
    if (length(x) != 1L || !is.finite(x) || x < 1 || x != floor(x))
    {
      stop("The argument 'x' must be a positive integer sample size.")
    }
    n       <- as.integer(x)
    ind_all <- seq_len(n)
  }
  else
  {
    if (length(x) == 0L || anyNA(x) ||
        any(!is.finite(x)) || any(x != floor(x)))
    {
      stop("The argument 'x' must be a nonempty vector of integer indices.")
    }
    n       <- length(x)
    ind_all <- x
  }
  
  # Validate 'n_folds'
  if (length(n_folds) != 1L || !is.finite(n_folds) ||
      n_folds != floor(n_folds) || n_folds < 1L || n_folds > n)
  {
    stop("The argument 'n_folds' must be an integer between 1 and ",
         "length(x).")
  }
  
  # Validate and normalize 'strata'
  strata_key <- NULL
  if (!is.null(strata))
  {
    if (is.list(strata) && is.null(dim(strata)))
    {
      stop("The argument 'strata' must be a vector, matrix or data frame, ",
           "not a list.")
    }
    if (is.null(dim(strata)))
    {
      if (length(strata) != n)
      {
        stop("The argument 'strata' must have one entry per observation.")
      }
      strata_key <- as.character(strata)
    }
    else
    {
      if (nrow(strata) != n)
      {
        stop("The argument 'strata' must have one row per observation.")
      }
      strata_key <- do.call(
        paste,
        c(lapply(seq_len(ncol(strata)),
                 function(j) as.character(strata[, j])),
          sep = "\r"))
    }
    if (anyNA(strata_key) || any(strata_key == ""))
    {
      stop("The argument 'strata' must not contain missing or empty values.")
    }
    strata_key <- factor(strata_key)
  }
  
  # Validate 'cluster'
  if (!is.null(cluster))
  {
    if (length(cluster) != n)
    {
      stop("The argument 'cluster' must have length ", n,
           " (aligned to 'x' or to the sample size).")
    }
    if (anyNA(cluster))
    {
      stop("The argument 'cluster' must not contain missing values.")
    }
  }
  
  # Cluster-level split
  if (!is.null(cluster))
  {
    cluster_fac <- droplevels(as.factor(cluster))
    cluster_ids <- levels(cluster_fac)
    n_clusters  <- length(cluster_ids)
    if (n_folds > n_clusters)
    {
      stop("The argument 'n_folds' (", n_folds,
           ") exceeds the number of clusters (", n_clusters, "). ",
           "Reduce 'n_folds' or drop 'cluster'.")
    }
    
    # Cluster sizes
    cluster_sizes <- as.integer(tabulate(cluster_fac, nbins = n_clusters))
    
    # Stratum of each cluster
    if (is.null(strata_key))
    {
      cluster_strata <- rep("__single__", n_clusters)
    } else
    {
      strata_split <- split(as.character(strata_key), cluster_fac)
      cluster_strata <- vapply(
        strata_split,
        function(s)
        {
          tab <- table(s)
          names(tab)[which.max(tab)]
        },
        character(1L))
      cluster_strata <- unname(cluster_strata)
      varies <- vapply(strata_split,
                       function(s) length(unique(s)) > 1L,
                       logical(1L))
      if (any(varies))
      {
        warning("The argument 'strata' varies within ", sum(varies),
                " cluster(s). Using the most common stratum per cluster ",
                "for stratified fold construction.")
      }
    }
    
    # Greedy size-balanced assignment, global fold sizes across strata
    cluster_fold <- integer(n_clusters)
    fold_sizes   <- integer(n_folds)
    for (s in unique(cluster_strata))
    {
      idx_s <- which(cluster_strata == s)
      if (length(idx_s) == 0L) next
      ord_s <- idx_s[order(-cluster_sizes[idx_s],
                           sample.int(length(idx_s)))]
      for (k in ord_s)
      {
        smallest             <- which.min(fold_sizes)
        cluster_fold[k]      <- smallest
        fold_sizes[smallest] <- fold_sizes[smallest] + cluster_sizes[k]
      }
    }
    
    groups <- cluster_fold[as.integer(cluster_fac)]
    ind    <- ind_all
    
    # Check that every fold contains at least one observation
    if (any(tabulate(groups, nbins = n_folds) == 0L))
    {
      stop("Cluster-aware fold construction produced at least one empty ",
           "fold. This should not happen when n_folds <= n_clusters; ",
           "please report.")
    }
  }
  else if (is.null(strata_key))
  {
    # Unstratified observation split (unchanged)
    ind         <- ind_all[sample.int(n)]
    group_sizes <- rep(n %/% n_folds, n_folds)
    remainder   <- n %% n_folds
    if (remainder > 0L)
    {
      group_sizes[seq_len(remainder)] <- group_sizes[seq_len(remainder)] + 1L
    }
    groups <- rep(seq_len(n_folds), times = group_sizes)
  }
  else
  {
    # Stratified observation split (unchanged)
    groups <- integer(n)
    for (s in seq_along(levels(strata_key)))
    {
      idx_s <- which(strata_key == levels(strata_key)[s])
      if (length(idx_s) == 0L) next
      idx_s_shuffled         <- idx_s[sample.int(length(idx_s))]
      offset                 <- (s - 1L) %% n_folds
      assign_s               <- ((seq_along(idx_s_shuffled) - 1L + offset) %%
                                 n_folds) + 1L
      groups[idx_s_shuffled] <- assign_s
    }
    if (any(tabulate(groups, nbins = n_folds) == 0L))
    {
      stop("Stratified fold construction produced at least one empty ",
           "fold. Reduce 'n_folds' or use coarser strata.")
    }
    ind <- ind_all
  }
  
  # Return the results
  return (split(ind, factor(groups, levels = seq_len(n_folds))))
}

#' @title Combine index vectors from several folds
#'
#' @description Concatenates the elements of \code{x} listed in
#' \code{folds}.
#'
#' @details
#' Negative indices are interpreted as positions to exclude, in the
#' same way as R's ordinary negative indexing. This is convenient for
#' building outer training samples as the complement of a single fold.
#'
#' @param x a list of integer index vectors.
#' @param folds a vector of fold indices or their negations.
#'
#' @return An integer vector.
#'
#' @seealso \code{\link[sdml]{cf_ind_split}},
#' \code{\link[sdml]{mseldml}}
#'
#' @examples
#' # Split a sample into three folds
#' set.seed(123)
#' folds <- cf_ind_split(x = 10, n_folds = 3, x_is_size = TRUE)
#' folds
#'
#' # Combine the first two folds
#' cf_ind_combine(folds, c(1, 2))
#'
#' # Combine all folds
#' cf_ind_combine(folds, 1:3)
#'
#' # Exclude one fold: the complement of fold 1
#' cf_ind_combine(folds, -1)
#'
#' @export
cf_ind_combine <- function(x, folds)
{
  # Get the number of folds
  n_folds <- length(x)
  
  # Validate 'x'
  if (!is.list(x))
  {
    stop("The argument 'x' must be a list of fold index vectors, as ",
         "returned by 'cf_ind_split()'.")
  }
  
  # Validate 'folds'
  if (!is.numeric(folds)     || (length(folds) == 0L)      || anyNA(folds) ||
      any(!is.finite(folds)) || any(folds != floor(folds)) ||
      any(folds == 0)        || any(abs(folds) > n_folds))
  {
    stop("The argument 'folds' must contain valid nonzero integer fold ",
         "indices or their negative complements.")
  }
  if (any(folds < 0) && any(folds > 0))
  {
    stop("Do not mix positive and negative fold indices in 'folds'.")
  }
  
  # Convert negative indices into their positive complements
  if (any(folds < 0))
  {
    folds <- (1:n_folds)[folds]
  }
  
  # Concatenate the selected fold index vectors
  val <- NULL
  for (i in folds)
  {
    val <- c(val, x[[i]])
  }
  
  # Return the results
  return (val)
}