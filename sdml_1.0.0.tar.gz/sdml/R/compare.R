# ---------------------------------------------------------
# Pairwise comparisons of the four causal parameters
# ---------------------------------------------------------

#' @title Pairwise comparisons of the four causal parameters
#'
#' @description Computes pairwise differences of the four estimated
#' causal parameters (ATE, ATES, ATT, ATTS) and returns standard errors,
#' p-values, significance stars and a formatted display matrix.
#'
#' @details
#' Let \eqn{\theta = (\theta_1, \theta_2, \theta_3, \theta_4)'} collect the
#' four causal parameters in canonical order
#' \eqn{(\mathrm{ATE}, \mathrm{ATES}, \mathrm{ATT}, \mathrm{ATTS})}, and
#' let \eqn{\widehat{\Sigma}} denote the estimated covariance matrix of
#' \eqn{\hat\theta} returned in the \code{cov} (or \code{cov_nograd})
#' slot of the fitted \code{mseldml} object.
#'
#' The function returns the matrix \eqn{D} with entries
#' \deqn{D_{ij} = \hat\theta_i - \hat\theta_j.}
#' For \eqn{i \neq j}, the standard error of \eqn{D_{ij}} follows from
#' the delta method:
#' \deqn{\widehat{\mathrm{SE}}(D_{ij}) =
#'       \sqrt{\widehat{\Sigma}_{ii} + \widehat{\Sigma}_{jj}
#'             - 2 \widehat{\Sigma}_{ij}}.}
#' A two-sided normal test is applied with the null hypothesis that the
#' difference is zero. Significance stars follow the convention implied
#' by \code{sig_levels}: the first threshold corresponds to \code{*},
#' the second to \code{**}, the third to \code{***}. With the defaults
#' \code{sig_levels = c(0.10, 0.05, 0.01)}, this gives \code{***} for
#' \eqn{p < 0.01}, \code{**} for \eqn{p < 0.05}, and \code{*} for
#' \eqn{p < 0.10}.
#'
#' The diagonal entries \eqn{D_{ii}} are zero by construction and are
#' displayed as \code{0}.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param nograd a logical value. If \code{TRUE}, the comparison is
#' performed on the derivative-free estimates using
#' \code{object$cov_nograd}. If \code{FALSE}, the comparison is
#' performed on the derivative-corrected estimates using
#' \code{object$cov}. If \code{NULL} (the default), the value stored in
#' \code{object$nograd} is used.
#' @param sig_levels a numeric vector of length three representing the
#' significance thresholds for \code{*}, \code{**}, \code{***}.
#' Defaults to \code{c(0.10, 0.05, 0.01)}.
#'
#' @return An object of class \code{"mseldml_compare"}, a list with
#' elements:
#' \itemize{
#' \item \code{diff} - a 4\eqn{\times}4 numeric matrix of pairwise
#'   differences.
#' \item \code{se} - a 4\eqn{\times}4 numeric matrix of standard errors.
#' \item \code{p_value} - a 4\eqn{\times}4 numeric matrix of p-values.
#' \item \code{stars} - a 4\eqn{\times}4 character matrix of
#'   significance stars.
#' \item \code{display} - a 4\eqn{\times}4 character matrix of formatted
#'   strings ready for printing.
#' \item \code{par_order} - the canonical parameter ordering used.
#' \item \code{nograd} - the same as the \code{nograd} input.
#' }
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{print.mseldml_compare}}
#'
#' @examples
#' \donttest{
#' # Simulate a small data set
#' library("mnorm")
#' set.seed(123)
#' n  <- 500
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#' w1 <- rnorm(n)
#' w2 <- rnorm(n)
#'
#' sigma_ZY       <- matrix(0.8, nrow = 3, ncol = 3)
#' diag(sigma_ZY) <- 1
#' U_ZY           <- mnorm::rmnorm(n, c(0, 0, 0), sigma_ZY)
#'
#' D  <- as.numeric(x1 + rnorm(n) >= 0)
#' Z1 <- as.numeric(x1 + 0.2 * (D + w1 + w2) + U_ZY[, 1] >= 0)
#' Z2_latent          <- x2 - 0.2 * (D + w1 + w2) - U_ZY[, 2]
#' Z2                 <- rep(1, n)
#' Z2[Z2_latent < -1] <- 0
#' Z2[Z2_latent >  1] <- 2
#' Z_joint            <- as.numeric((Z1 == 1) & (Z2 == 1))
#' Y                  <- 1 + x1 + D + U_ZY[, 3]
#' Y[Z_joint == 0]    <- NA
#'
#' # Estimate the model
#' model <- mseldml(X = cbind(x1, x2), W_Z = cbind(w1, w2),
#'                  D = D, Y = Y,
#'                  Z = cbind(Z1, Z2), z = c(1, 1), z_max = c(1, 2))
#'
#' # Pairwise comparison of the derivative-corrected estimates
#' cmp <- mseldml_compare(model)
#' print(cmp)
#'
#' # Pairwise comparison of the derivative-free estimates
#' cmp0 <- mseldml_compare(model, nograd = TRUE)
#' print(cmp0)
#' }
#'
#' @export
mseldml_compare <- function(object, nograd = NULL,
                            sig_levels = c(0.10, 0.05, 0.01))
{
  # Validate the class of 'object'
  if (!inherits(object, "mseldml"))
  {
    stop("The argument 'object' must inherit from class 'mseldml'.")
  }
  
  # Default 'nograd' to the value stored in the model
  if (is.null(nograd))
  {
    nograd <- isTRUE(object$nograd)
  }
  
  # Validate 'nograd'
  if (!is.logical(nograd) || length(nograd) != 1L || is.na(nograd))
  {
    stop("The argument 'nograd' must be a single logical value or NULL.")
  }
  
  # Validate 'sig_levels'
  if (!is.numeric(sig_levels))
  {
    stop("The argument 'sig_levels' must be numeric.")
  }
  if (length(sig_levels) != 3L || anyNA(sig_levels) ||
      any(!is.finite(sig_levels)) || any(sig_levels <= 0) ||
      any(sig_levels >= 1))
  {
    stop("The argument 'sig_levels' must be a vector of three ",
         "probabilities strictly between 0 and 1.")
  }
  if (anyDuplicated(sig_levels))
  {
    stop("The argument 'sig_levels' must contain three distinct thresholds.")
  }
  
  # Sort the thresholds in decreasing order for the star assignment
  sig_levels <- sort(sig_levels, decreasing = TRUE)
  
  # Canonical ordering of the four parameters
  par_order <- c("ATE", "ATES", "ATT", "ATTS")
  
  # Select the covariance matrix and the estimates
  if (nograd)
  {
    cov_mat <- object$cov_nograd
    est_vec <- object$estimates[paste0(par_order, "_DML0")]
  }
  else
  {
    cov_mat <- object$cov
    est_vec <- object$estimates[paste0(par_order, "_DML")]
  }
  
  # Fail if the selected covariance is not available
  if (is.null(cov_mat))
  {
    stop("The requested covariance matrix is not available in the object. ",
         if (nograd) "Refit the model with the current version of mseldml()."
         else        "Refit the model with 'nograd = FALSE'.")
  }
  
  # Restrict the covariance to the canonical parameter ordering
  cov_mat <- cov_mat[par_order, par_order, drop = FALSE]
  
  # Validate the covariance matrix
  if (!is.matrix(cov_mat) || !is.numeric(cov_mat) ||
      !identical(dim(cov_mat), c(4L, 4L)) ||
      any(!is.finite(cov_mat)))
  {
    stop("The covariance matrix must be a finite numeric 4 x 4 matrix.")
  }
  if (!isSymmetric(cov_mat, tol = 1e-8))
  {
    stop("The supplied covariance matrix is not symmetric; pairwise ",
         "comparisons are not meaningful.")
  }
  
  # Symmetrise and check positive semidefiniteness
  cov_sym <- (cov_mat + t(cov_mat)) / 2
  ev      <- eigen(cov_sym, symmetric = TRUE, only.values = TRUE)$values
  psd_tol <- 1e-10 * max(1, max(abs(ev)))
  if (min(ev) < -psd_tol)
  {
    stop("The supplied covariance matrix is not positive semidefinite.")
  }
  
  # Validate the estimates
  names(est_vec) <- par_order
  if (any(!is.finite(est_vec)) || any(is.na(names(est_vec))))
  {
    stop("The selected estimate vector contains non-finite or unnamed ",
         "entries.")
  }
  
  # Allocate the output matrices
  n_par    <- length(par_order)
  diff_mat <- matrix(NA_real_, n_par, n_par,
                     dimnames = list(par_order, par_order))
  se_mat   <- matrix(NA_real_, n_par, n_par,
                     dimnames = list(par_order, par_order))
  p_mat    <- matrix(NA_real_, n_par, n_par,
                     dimnames = list(par_order, par_order))
  star_mat <- matrix("", n_par, n_par,
                     dimnames = list(par_order, par_order))
  disp_mat <- matrix("", n_par, n_par,
                     dimnames = list(par_order, par_order))
  
  # Fill the matrices cell by cell
  for (i in seq_len(n_par))
  {
    for (j in seq_len(n_par))
    {
      # Diagonal cells: the difference is zero by construction
      if (i == j)
      {
        diff_mat[i, j] <- 0
        se_mat[i, j]   <- 0
        disp_mat[i, j] <- "0"
        next
      }
      
      # Compute the difference and its delta-method variance
      d <- est_vec[i] - est_vec[j]
      v <- cov_sym[i, i] + cov_sym[j, j] - 2 * cov_sym[i, j]
      
      # Guard against materially negative variances
      tol <- 1e-10 * max(1,
                         abs(cov_sym[i, i]),
                         abs(cov_sym[j, j]),
                         abs(cov_sym[i, j]))
      if (v < -tol)
      {
        stop("Negative variance for the pairwise difference (",
             par_order[i], " - ", par_order[j], "): ",
             format(v, digits = 6), ". Check the covariance matrix.")
      }
      s <- sqrt(max(v, 0))
      
      # Store the difference and standard error
      diff_mat[i, j] <- d
      se_mat[i, j]   <- s
      
      # Compute the two-sided p-value
      if (s > 0)
      {
        z <- d / s
        p <- 2 * stats::pnorm(-abs(z))
      }
      else
      {
        p <- NA_real_
      }
      p_mat[i, j] <- p
      
      # Assign the significance stars
      star <- ""
      if (!is.na(p))
      {
        if (p < sig_levels[3])
        {
          star <- "***"
        }
        else if (p < sig_levels[2])
        {
          star <- "**"
        }
        else if (p < sig_levels[1])
        {
          star <- "*"
        }
      }
      star_mat[i, j] <- star
      
      # Format the display string
      disp_mat[i, j] <- paste0(
        formatC(d, digits = 3, format = "f"), star, "\n",
        "(", formatC(s, digits = 3, format = "f"), ")"
      )
    }
  }
  
  # Assemble and return the output
  out <- list(
    diff      = diff_mat,
    se        = se_mat,
    p_value   = p_mat,
    stars     = star_mat,
    display   = disp_mat,
    par_order = par_order,
    nograd    = nograd
  )
  class(out) <- "mseldml_compare"
  return(out)
}

#' @title Print a mseldml_compare object
#'
#' @description Displays the matrix of pairwise differences of the four
#' causal parameters, with significance stars and delta-method standard
#' errors.
#'
#' @details
#' Each parameter occupies two rows. The first row displays the pairwise
#' difference with significance stars. The second row, indented under
#' the parameter name, displays the standard error in parentheses. Rows
#' correspond to the minuend, columns to the subtrahend: cell
#' \eqn{(i, j)} reports \eqn{\hat\theta_i - \hat\theta_j}. Diagonal
#' cells are displayed as \code{0} without a standard error.
#'
#' @param x an object of class \code{"mseldml_compare"}.
#' @param ... further arguments. Currently ignored.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml_compare}}
#'
#' @export
print.mseldml_compare <- function(x, ...)
{
  # Print the header
  cat("Pairwise differences of causal parameters\n")
  cat("---\n")
  cat(sprintf("Estimator: %s\n",
              if (isTRUE(x$nograd)) "derivative-free (DML0)"
              else                  "derivative-corrected (DML)"))
  cat("Cell (i, j) reports theta(i) - theta(j).\n")
  cat("---\n")
  
  # Extract the parameter ordering and layout constants
  par_order  <- x$par_order
  n_par      <- length(par_order)
  cell_width <- 16
  
  # Print the column headers
  cat(sprintf("%-8s", ""))
  for (j in seq_len(n_par))
  {
    cat(sprintf("  %-*s", cell_width, par_order[j]))
  }
  cat("\n")
  
  # Print the body, one pair of rows per parameter
  for (i in seq_len(n_par))
  {
    # First row: pairwise difference with significance stars
    cat(sprintf("%-8s", par_order[i]))
    for (j in seq_len(n_par))
    {
      if (i == j)
      {
        cell_val <- "0"
      }
      else
      {
        cell_val <- paste0(
          formatC(x$diff[i, j], digits = 3, format = "f"),
          x$stars[i, j]
        )
      }
      cat(sprintf("  %-*s", cell_width, cell_val))
    }
    cat("\n")
    
    # Second row: standard error in parentheses
    cat(sprintf("%-8s", ""))
    for (j in seq_len(n_par))
    {
      if (i == j)
      {
        cell_se <- ""
      }
      else
      {
        cell_se <- paste0("(",
                          formatC(x$se[i, j], digits = 3, format = "f"),
                          ")")
      }
      cat(sprintf("  %-*s", cell_width, cell_se))
    }
    cat("\n")
  }
  
  # Print the footer
  cat("---\n")
  cat("Signif. codes:  0 '***' 0.01 '**' 0.05 '*' 0.1\n")
  cat("Standard errors are shown in parentheses on the second row ",
      "of each cell.\n", sep = "")
  
  return(invisible(x))
}