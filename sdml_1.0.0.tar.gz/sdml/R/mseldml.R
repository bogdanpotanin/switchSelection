# ---------------------------------------------------------
# Double machine learning estimator
# ---------------------------------------------------------

#' @title Double machine learning for a multivariate sample selection model
#'
#' @description Estimates the average treatment effect (ATE), the average
#' treatment effect on the selected subpopulation (ATES), the average
#' treatment effect on the treated (ATT), and the average treatment
#' effect on the treated within the selected subpopulation (ATTS) in the
#' multivariate sample selection model with ordinal selection equations.
#'
#' @details
#' \strong{Model}
#'
#' Consider \eqn{n} i.i.d. observations indexed by
#' \eqn{i\in\{1,...,n\}}. The model consists of:
#' \itemize{
#' \item a categorical treatment \eqn{D_i} with support
#'   \eqn{\{d_0, d_1\}};
#' \item potential outcomes \eqn{Y_{di}}, with the observable outcome
#'   defined as \eqn{Y_i = \sum_{d\in\{d_0, d_1\}} Y_{di} I(D_i = d)};
#' \item ordinal selection variables \eqn{Z_{ji}\in\{0,...,m_j\}},
#'   \eqn{j\in\{1,...,J\}};
#' \item covariates \eqn{X_i};
#' \item exclusion restrictions \eqn{W_i}.
#' }
#'
#' Each selection variable follows an ordinal latent-index mechanism:
#' \deqn{Z_{ji} = k \iff c_{jk} < g_j(D_i, X_i, W_i) + U_{ji}
#'       \leq c_{j,k+1},}
#' where \eqn{c_{j1} < c_{j2} < ...} are scalar thresholds and
#' \eqn{U_{ji}} are random errors. The outcome is observable only when
#' \eqn{\tilde{Z}_i = I(Z_i = z^*) = 1}, where \eqn{z^*} is a vector of
#' target categories.
#'
#' Identification uses the conditional exogeneity assumption
#' \deqn{(Y_{di}, U_i) \perp (D_i, W_i) \mid X_i,}
#' where \eqn{U_i = (U_{1i},...,U_{Ji})}. Under this assumption, the
#' control function
#' \deqn{P_i^{0} = \big(p^{0,z^* - (1,...,1)}(D_i, X_i, W_i),\;
#'                       p^{0,z^*}(D_i, X_i, W_i)\big)}
#' restores independence between \eqn{Y_{di}} and \eqn{D_i} in the
#' selected subpopulation.
#'
#' \strong{Estimators}
#'
#' Four causal parameters are estimated:
#' \itemize{
#' \item \eqn{\mathrm{ATES}} - the average treatment effect among the
#'   selected subpopulation;
#' \item \eqn{\mathrm{ATTS}} - the average treatment effect on the
#'   treated within the selected subpopulation;
#' \item \eqn{\mathrm{ATE}} - the average treatment effect in the full
#'   population (additional homogeneity and support assumptions
#'   required);
#' \item \eqn{\mathrm{ATT}} - the average treatment effect on the
#'   treated in the full population.
#' }
#'
#' All estimators use the Neyman-orthogonal scores of the accompanying
#' article. Two versions of each estimator are computed:
#' \itemize{
#' \item the derivative-corrected DML estimator (suffix \code{_DML});
#' \item the derivative-free version with the sensitivity term set to
#'   zero (suffix \code{_DML0}).
#' }
#'
#' Set \code{nograd = TRUE} to compute only the derivative-free
#' versions.
#'
#' \strong{Reading the output}
#'
#' The returned object carries two families of estimates, labelled by
#' the suffix in \code{out$estimates}:
#'
#' \tabular{lll}{
#'   \strong{Name}        \tab \strong{Population}   \tab \strong{Conditioning} \cr
#'   \code{ATE_DML}       \tab full population       \tab none \cr
#'   \code{ATES_DML}      \tab selected subpopulation \tab \eqn{\tilde{Z} = 1} \cr
#'   \code{ATT_DML}       \tab full population       \tab \eqn{D = d_1} \cr
#'   \code{ATTS_DML}      \tab selected subpopulation \tab \eqn{\tilde{Z} = 1, D = d_1} \cr
#' }
#'
#' Estimands with a trailing \code{_DML0} are the derivative-free
#' versions; they are numerically identical to \code{_DML} only when
#' the derivative-correction term vanishes. ATE and ATES coincide with
#' each other, and ATT with ATTS, only when there is no sample
#' selection (that is, when \code{Z = NULL}).
#'
#' \strong{Data input}
#'
#' If \code{data} is supplied, \code{X}, \code{W_Z}, \code{D}, \code{Y}
#' and \code{Z} are interpreted as character vectors of column names in
#' \code{data}; otherwise they are treated as the data themselves. The
#' two interfaces are mutually exclusive: supplying \code{data} together
#' with matrix / vector arguments raises an error.
#'
#' \strong{Nuisance functions}
#'
#' The following nuisances are estimated internally unless supplied
#' through \code{nuisances}:
#' \itemize{
#' \item \code{Z_prob} - CDF probabilities associated with \eqn{Z};
#' \item \code{Y_mean} - outcome regression on \eqn{(D, X, P)};
#' \item \code{Z_joint_prob2} - exact-selection probability
#'   \eqn{P(\tilde{Z}_i = 1 \mid D, X, W)};
#' \item \code{D_prob} - conditional treatment probability
#'   \eqn{P(D_i = d \mid X, P)}.
#' }
#'
#' \strong{Cross-fitting}
#'
#' Cross-fitting removes the plug-in bias of the first-stage nuisances.
#' The outer training sample is split into \code{cf_folds} folds; each
#' fold in turn serves as the test sample.
#'
#' If \code{is_nested = TRUE} (the default), each outer training sample
#' is further split into two halves: one half fits \code{Z_prob}, and
#' the other fits the second-stage nuisances \code{Y_mean} and
#' \code{D_prob}. This nested structure removes the correlation between
#' the fitted control functions and the residuals of the second-stage
#' regressions.
#'
#' If \code{is_nested = FALSE}, the entire outer training sample is used
#' at both stages. This is faster but less protected against
#' overfitting.
#'
#' \strong{Repeated estimation}
#'
#' If \code{n_rep > 1}, the estimator is refit \code{n_rep} times with
#' independently drawn folds. Point estimates are aggregated by the
#' coordinate-wise median of the per-split estimates. For covariance
#' aggregation, each split contributes the adjusted matrix
#' \eqn{\hat\Sigma_s + (\hat\theta^s - \tilde\theta)
#' (\hat\theta^s - \tilde\theta)'}, where \eqn{\tilde\theta} is the
#' coordinate-wise median estimate, and the reported covariance matrix
#' is the adjusted matrix whose operator norm is the median of the
#' operator norms across splits (Chernozhukov et al., 2018, Definition
#' 3.3, equation 3.14). When \code{n_rep} is even, the lower of the two
#' middle ranks is chosen, which makes the selection invariant to the
#' order of the repetitions. Reported standard errors are the square
#' roots of the diagonal of the selected covariance matrices, so that
#' the per-parameter inference and the joint covariance used by
#' \code{\link[sdml]{mseldml_compare}} are mutually
#' consistent.
#'
#' \strong{Trimming}
#'
#' \code{trim_prob} is a length-2 numeric vector
#' \code{c(lower, upper)}. Observations whose estimated control-function
#' values (\eqn{\hat P_i^{(d)}}, \eqn{\hat P_i^{(d^*)}}, and
#' \eqn{\hat{\tilde P}_i}) fall outside \code{[lower, upper]} are
#' removed from the estimation sample. A scalar argument is interpreted
#' as the corresponding one-sided bound. The default \code{c(0, Inf)}
#' disables trimming, since all estimated probabilities lie in
#' \eqn{(0, 1)}.
#'
#' \strong{Ordinal support}
#'
#' Selection variables are assumed to be integer-coded from \eqn{0} to a
#' known upper support \eqn{z_{\max,j}} supplied through \code{z_max}.
#' The support maximum must be the theoretical upper endpoint, not the
#' maximum observed in the sample. If \code{z_max} is \code{NULL},
#' \code{apply(Z, 2, max)} is used as a fallback and a message is
#' printed; this fallback is only safe when the theoretical support
#' coincides with the observed support.
#'
#' The estimated CDF probabilities of a given \eqn{Z_j} must also
#' satisfy the ordering constraint
#' \eqn{P(Z_j \le z_j - 1 \mid \cdot) \le P(Z_j \le z_j \mid \cdot)}.
#' Because the two threshold indicators are fitted separately, this
#' ordering is enforced by a one-sided monotonicity repair inside the
#' cross-fitting loop before the second-stage nuisances are fitted, so
#' that the control functions used by the second-stage learners and the
#' branch-level control functions entering the score are consistent
#' within each inner branch. In nested mode the two inner branches are
#' aggregated by averaging, as prescribed by the estimators in the
#' accompanying article. The aggregated control functions therefore
#' need not be numerically equal to either branch's control function
#' individually; they equal their average. The monotonicity repair
#' reduces only the fitted lower CDF to equal the fitted upper CDF; the
#' upper CDF, which enters the score for exact selection, is untouched.
#' It is not the Euclidean projection onto
#' \eqn{\{p_{\mathrm{lower}} \le p_{\mathrm{upper}}\}}; it is the
#' repair used in the univariate case by Bia (2024) extended to the
#' ordinal multivariate case. A warning is raised if the repair is
#' active on any observations.
#'
#' @param X a numeric matrix of covariates \eqn{X_i}, or (if
#' \code{data} is supplied) a character vector of column names.
#' @param W_Z a numeric matrix of exclusion restrictions \eqn{W_i}, or
#' a character vector of column names when \code{data} is supplied.
#' @param D a numeric vector of treatment values, or a single column
#' name when \code{data} is supplied. Must take exactly the two values
#' \code{d0} and \code{d1}.
#' @param Y a numeric vector of outcomes, or a single column name when
#' \code{data} is supplied; entries outside the selected subpopulation
#' may be \code{NA}.
#' @param Z an integer matrix of selection variables \eqn{Z_i}, or a
#' character vector of column names when \code{data} is supplied, or
#' \code{NULL} if no sample selection is assumed.
#' @param z an integer vector of target categories \eqn{z^*}, one value
#' per column of \code{Z}. Must be \code{NULL} when \code{Z} is
#' \code{NULL}.
#' @param z_max an integer vector of declared support maxima, one value
#' per column of \code{Z}. Ignored when \code{Z} is \code{NULL}. If
#' \code{NULL} and \code{Z} is not, the observed column maxima are
#' used and a message is printed.
#' @param d0 a numeric value of \code{D} coding the control group.
#' Defaults to \code{0}.
#' @param d1 a numeric value of \code{D} coding the treatment group.
#' Defaults to \code{1}. Must differ from \code{d0}.
#' @param data an optional data frame. When supplied, \code{X},
#' \code{W_Z}, \code{D}, \code{Y} and \code{Z} must be character
#' vectors of column names.
#' @param na_action one of \code{"na.omit"} (default), \code{"na.fail"},
#' or \code{"na.pass"}. \code{na.omit} drops rows with missing values
#' in \code{X}, \code{W_Z}, \code{D}, or \code{Z} (with a warning);
#' \code{na.fail} raises an error; \code{na.pass} leaves missing values
#' in place (they will fail further downstream). Missing values in
#' \code{Y} are permitted whenever the corresponding observation is not
#' selected, regardless of \code{na_action}.
#' @param learner a named list of learner functions. See 'Details'.
#' @param predictor a named list of predictor functions. See 'Details'.
#' @param data_transform a function that transforms the regressor matrix
#' before fitting and prediction.
#' @param control_learner a named list of additional arguments passed
#' through to \code{learner}.
#' @param control_predictor a named list of additional arguments passed
#' through to \code{predictor}.
#' @param control_transform a named list of additional arguments passed
#' through to \code{data_transform}.
#' @param cf_folds a positive integer representing the number of
#' cross-fitting folds. Must lie between \code{2} and \code{n}.
#' Defaults to \code{5}.
#' @param is_nested a logical value. See 'Details'.
#' @param trim_prob a length-2 numeric vector \code{c(lower, upper)}
#' specifying the trimming interval for estimated probabilities. A
#' scalar \code{t} is interpreted as \code{c(t, Inf)} if
#' \code{t <= 0.5} and as \code{c(-Inf, t)} otherwise. See 'Details'.
#' @param ind_test an optional list of length \code{cf_folds} whose
#' elements are integer vectors partitioning \eqn{1,...,n}. If
#' \code{NULL}, folds are drawn automatically. Cannot be combined
#' with \code{n_rep > 1}.
#' @param nuisances an optional named list of pre-fitted nuisances. Only
#' fully aggregated out-of-sample predictions are accepted.
#' @param is_P_D a logical value. If \code{TRUE} (the default),
#' selection probabilities are estimated conditional on \eqn{D};
#' otherwise they are estimated conditional on \eqn{(X, W)} only.
#' @param n_rep a positive integer representing the number of
#' independent cross-fitting repetitions. See 'Details'.
#' @param nograd a logical value. If \code{TRUE}, only the
#' derivative-free estimators are computed and returned; the summary
#' displays a single \code{"Estimates"} table.
#'
#' @return This function returns an object of class \code{"mseldml"}. It
#' is a list which may contain the following elements:
#'
#' \strong{Estimates and standard errors}
#' \itemize{
#' \item \code{estimates} - a named numeric vector of point estimates;
#' \item \code{se} - a named numeric vector of standard errors.
#' }
#'
#' \strong{Covariance matrices}
#' \itemize{
#' \item \code{cov} - a \eqn{4\times 4} covariance matrix of the four
#'   derivative-corrected parameters, with rows and columns ordered
#'   \code{(ATE, ATES, ATT, ATTS)}. Present only when
#'   \code{nograd = FALSE}.
#' \item \code{cov_nograd} - the corresponding covariance matrix of the
#'   four derivative-free parameters.
#' }
#'
#' \strong{Diagnostics}
#' \itemize{
#' \item \code{diagnostics} - a list containing selection and treatment
#'   rates, ranges of the estimated control functions, and trimming
#'   counts. Printed at the end of \code{summary()}.
#' }
#'
#' \strong{Nuisance functions}
#' \itemize{
#' \item \code{nuisances} - a list containing \code{Z_prob},
#'   \code{Y1_mean}, \code{Y0_mean}, \code{Z_joint_prob2},
#'   \code{D1_prob} and \code{D0_prob}. If \code{nograd = FALSE}, it
#'   additionally contains \code{grad1}, \code{grad0} and the
#'   out-of-fold matrix \code{Z_prob_oof}.
#' }
#'
#' \strong{Influence functions}
#' \itemize{
#' \item \code{EIF} - an \eqn{n\times 4} matrix of influence functions
#'   for the derivative-corrected estimators, with columns
#'   \code{ATES}, \code{ATTS}, \code{ATE}, \code{ATT}. Present only
#'   when \code{nograd = FALSE}.
#' \item \code{EIF0} - the corresponding matrix for the derivative-free
#'   estimators.
#' }
#'
#' \strong{Metadata}
#' \itemize{
#' \item \code{trim} - an \eqn{n\times 4} logical matrix of trimming
#'   indicators. \code{TRUE} means the observation is kept;
#' \item \code{ind_test} - the list of test-fold index vectors used
#'   during cross-fitting;
#' \item \code{dim} - a list with elements \code{n}, \code{n_X},
#'   \code{n_Z}, \code{n_prob};
#' \item \code{is_Z} - a logical value indicating whether \code{Z} was
#'   supplied;
#' \item \code{is_P_D}, \code{is_nested}, \code{nograd} - the same as
#'   the corresponding input arguments;
#' \item \code{call} - the matched call, used by \code{update()};
#' \item \code{names} - a list of column names for \code{D}, \code{X},
#'   \code{Z} and \code{W_Z}.
#' }
#'
#' \strong{Per-split results}
#' \itemize{
#' \item \code{models} - present only when \code{n_rep > 1}. A list with
#'   elements \code{estimates} and \code{se} containing the per-split
#'   results.
#' }
#'
#' The returned nuisance objects distinguish two versions of the
#' control-function matrix:
#' \itemize{
#' \item \code{Z_prob} is an intermediate matrix that is repeatedly
#'   overwritten during cross-fitting as different folds are processed.
#'   It is not a single out-of-fold prediction matrix.
#' \item \code{Z_prob_oof} is the matrix assembled from out-of-fold
#'   predictions on each outer test fold.
#' }
#'
#' @references
#' V. Chernozhukov, D. Chetverikov, M. Demirer, E. Duflo, C. Hansen,
#' W. Newey, J. Robins (2018). Double/debiased machine learning for
#' treatment and structural parameters. The Econometrics Journal,
#' vol. 21(1), pages C1-C68.
#'
#' @examples
#' \donttest{
#' # ---------------------------------------
#' # Simulated data example
#' # Double sample selection
#' # ---------------------------------------
#'
#' library("mnorm")
#' library("glmnet")
#' library("ranger")
#' set.seed(123)
#'
#' n <- 1000
#'
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#' w1 <- rnorm(n)
#' w2 <- rnorm(n)
#'
#' sigma_ZY       <- matrix(0.8, nrow = 3, ncol = 3)
#' diag(sigma_ZY) <- 1
#' U_ZY           <- mnorm::rmnorm(n, c(0, 0, 0), sigma_ZY)
#'
#' D <- as.numeric(x1 + rnorm(n) >= 0)
#'
#' Z1                 <- as.numeric(x1 + 0.2 * (D + w1 + w2)
#'                                  + U_ZY[, 1] >= 0)
#' Z2_latent          <- x2 - 0.2 * (D + w1 + w2) - U_ZY[, 2]
#' Z2                 <- rep(1, n)
#' Z2[Z2_latent < -1] <- 0
#' Z2[Z2_latent >  1] <- 2
#' Z_joint            <- as.numeric((Z1 == 1) & (Z2 == 1))
#'
#' Y               <- 1 + x1 + D + U_ZY[, 3]
#' Y[Z_joint == 0] <- NA
#'
#' # Matrix interface
#' model <- mseldml(X = cbind(x1, x2), W_Z = cbind(w1, w2),
#'                  D = D, Y = Y,
#'                  Z = cbind(Z1, Z2), z = c(1, 1), z_max = c(1, 2))
#'
#' # Point estimates
#' coef(model)
#'
#' # Confidence intervals
#' confint(model)
#'
#' # Data-frame interface
#' df <- data.frame(wage = Y, treat = D, X1 = x1, X2 = x2,
#'                  W1 = w1, W2 = w2, Z1 = Z1, Z2 = Z2)
#' model2 <- mseldml(data = df,
#'                   X = c("X1", "X2"), W_Z = c("W1", "W2"),
#'                   D = "treat", Y = "wage",
#'                   Z = c("Z1", "Z2"), z = c(1, 1), z_max = c(1, 2))
#'
#' # The two interfaces produce the same estimates
#' isTRUE(all.equal(coef(model), coef(model2)))
#'
#' # Plot of the four causal estimates
#' plot(model2)
#'
#' # Refit with more cross-fitting folds
#' model3 <- update(model2, cf_folds = 10)
#' coef(model3)
#' }
#' @seealso \code{\link[sdml]{learner_glmnet}},
#' \code{\link[sdml]{predictor_glmnet}},
#' \code{\link[sdml]{data_transform_default}},
#' \code{\link[sdml]{summary.mseldml}},
#' \code{\link[sdml]{print.mseldml}},
#' \code{\link[sdml]{mseldml_compare}}
#'
#' @export
mseldml <- function(X, W_Z, D, Y, Z, z = NULL, z_max = NULL, d0 = 0, d1 = 1,
                    data      = NULL,
                    na_action = c("na.omit", "na.fail", "na.pass"),
                    learner   = list(Z_prob        = learner_glmnet,
                                     Y_mean        = learner_glmnet,
                                     Z_joint_prob2 = learner_glmnet,
                                     D_prob        = learner_glmnet),
                    predictor = list(Z_prob        = predictor_glmnet,
                                     Y_mean        = predictor_glmnet,
                                     Z_joint_prob2 = predictor_glmnet,
                                     D_prob        = predictor_glmnet),
                    data_transform    = data_transform_default,
                    control_learner   = list(),
                    control_predictor = list(),
                    control_transform = list(),
                    cf_folds          = 5,
                    is_nested         = TRUE,
                    trim_prob         = c(0.01, Inf),
                    ind_test          = NULL,
                    nuisances         = list(),
                    is_P_D            = TRUE,
                    n_rep             = 1,
                    nograd            = FALSE)
{
  # Initialize the output and save the call
  out        <- list()
  call_saved <- match.call()
  na_action  <- match.arg(na_action)
  
  # -----------------------------------
  # Validate scalar arguments
  # -----------------------------------
  if (length(n_rep) != 1L ||
      !is.numeric(n_rep) ||
      !is.finite(n_rep) ||
      n_rep < 1L ||
      n_rep != floor(n_rep))
  {
    stop("The argument 'n_rep' must be a positive integer.")
  }
  
  if (!is.logical(is_nested) || length(is_nested) != 1L || is.na(is_nested))
  {
    stop("The argument 'is_nested' must be a single non-missing logical ",
         "value.")
  }
  if (!is.logical(is_P_D) || length(is_P_D) != 1L || is.na(is_P_D))
  {
    stop("The argument 'is_P_D' must be a single non-missing logical value.")
  }
  if (!is.logical(nograd) || length(nograd) != 1L || is.na(nograd))
  {
    stop("The argument 'nograd' must be a single non-missing logical value.")
  }
  if (!is.numeric(cf_folds))
  {
    stop("The argument 'cf_folds' must be numeric.")
  }
  
  if (n_rep > 1L && !is.null(ind_test))
  {
    stop("The argument 'n_rep' cannot exceed 1 when 'ind_test' is supplied. ",
         "Either set 'n_rep = 1' or leave 'ind_test = NULL' so that ",
         "independent folds are drawn for each repetition.")
  }
  
  # -----------------------------------
  # Resolve the data-frame interface
  # -----------------------------------
  if (!is.null(data))
  {
    if (!is.data.frame(data))
    {
      stop("The argument 'data' must be a data frame.")
    }
    X   <- mseldml_resolve_data(data, X,   "X",   TRUE)
    W_Z <- mseldml_resolve_data(data, W_Z, "W_Z", TRUE)
    D   <- mseldml_resolve_data(data, D,   "D",   FALSE)
    Y   <- mseldml_resolve_data(data, Y,   "Y",   FALSE)
    Z   <- mseldml_resolve_data(data, Z,   "Z",   TRUE)
  }
  
  # -----------------------------------
  # Repeated estimation
  # -----------------------------------
  if (n_rep > 1)
  {
    # Allocate the storage for the per-split estimates and SEs
    est_list <- vector(mode = "list", length = n_rep)
    se_list  <- vector(mode = "list", length = n_rep)
    
    # Refit the estimator once per repetition
    last_model  <- NULL
    models_list <- vector(mode = "list", length = n_rep)
    for (i in seq_len(n_rep))
    {
      model <- mseldml(X = X, W_Z = W_Z, D = D, Y = Y, Z = Z,
                       z = z, z_max = z_max, d0 = d0, d1 = d1,
                       na_action         = na_action,
                       learner           = learner,
                       predictor         = predictor,
                       data_transform    = data_transform,
                       control_learner   = control_learner,
                       control_predictor = control_predictor,
                       control_transform = control_transform,
                       cf_folds          = cf_folds,
                       is_nested         = is_nested,
                       trim_prob         = trim_prob,
                       ind_test          = ind_test,
                       nuisances         = nuisances,
                       is_P_D            = is_P_D,
                       n_rep             = 1,
                       nograd            = nograd)
      models_list[[i]] <- model
      est_list[[i]]    <- model$estimates
      se_list [[i]]    <- model$se
      last_model       <- model
    }
    
    # Aggregate the per-split estimates into matrices
    est_names <- names(est_list[[1]])
    est_mat   <- matrix(NA_real_, nrow = n_rep, ncol = length(est_names))
    se_mat    <- matrix(NA_real_, nrow = n_rep, ncol = length(est_names))
    colnames(est_mat) <- est_names
    colnames(se_mat)  <- est_names
    for (i in seq_len(n_rep))
    {
      est_mat[i, ] <- est_list[[i]]
      se_mat [i, ] <- se_list [[i]]
    }
    
    # Point estimates: coordinate-wise median across splits
    est_med <- apply(est_mat, 2, median)
    names(est_med) <- est_names
    
    # Scalar median variance of Chernozhukov et al. (2018), equation 3.14
    dev_mat <- sweep(est_mat, 2, est_med, FUN = "-")
    var_adj <- se_mat^2 + dev_mat^2
    var_med <- apply(var_adj, 2, median)
    se_out  <- sqrt(var_med)
    names(se_out) <- est_names
    
    # Canonical ordering of the four causal parameters
    par_order <- c("ATE", "ATES", "ATT", "ATTS")
    
    # Build the adjusted covariance matrices for each split
    cov_adj_list  <- vector(mode = "list", length = n_rep)
    cov0_adj_list <- vector(mode = "list", length = n_rep)
    
    for (i in seq_len(n_rep))
    {
      # Adjusted derivative-free covariance
      dev_ng <- est_mat[i, paste0(par_order, "_DML0")] -
        est_med[paste0(par_order, "_DML0")]
      
      cov0_i <- models_list[[i]]$cov_nograd
      if (!is.null(cov0_i))
      {
        cov0_adj_list[[i]] <- unname(cov0_i[par_order, par_order, drop = FALSE]) +
          outer(as.numeric(dev_ng), as.numeric(dev_ng))
      }
      
      # Adjusted derivative-corrected covariance (when applicable)
      if (!nograd)
      {
        dev_dml <- est_mat[i, paste0(par_order, "_DML")] -
          est_med[paste0(par_order, "_DML")]
        
        cov_i <- models_list[[i]]$cov
        if (!is.null(cov_i))
        {
          cov_adj_list[[i]] <- unname(cov_i[par_order, par_order, drop = FALSE]) +
            outer(as.numeric(dev_dml), as.numeric(dev_dml))
        }
      }
    }
    
    # Select the operator-norm median of the adjusted covariances
    if (!nograd && !any(sapply(cov_adj_list, is.null)))
    {
      cov_med <- cov_median(cov_adj_list)
      dimnames(cov_med) <- list(par_order, par_order)
      out$cov <- cov_med
    }
    if (!any(sapply(cov0_adj_list, is.null)))
    {
      cov0_med <- cov_median(cov0_adj_list)
      dimnames(cov0_med) <- list(par_order, par_order)
      out$cov_nograd <- cov0_med
    }
    
    # Override the scalar median SEs with the selected covariance diagonals
    if (!is.null(out$cov))
    {
      se_out[paste0(par_order, "_DML")] <- sqrt(diag(out$cov))
    }
    if (!is.null(out$cov_nograd))
    {
      se_out[paste0(par_order, "_DML0")] <- sqrt(diag(out$cov_nograd))
    }
    
    # Assemble the output of the repeated-fit branch
    out$models      <- list(estimates = est_mat, se = se_mat)
    out$estimates   <- est_med
    out$se          <- se_out
    out$n_rep       <- n_rep
    out$nograd      <- nograd
    out$is_nested   <- is_nested
    out$dim         <- last_model$dim
    out$is_Z        <- last_model$is_Z
    out$is_P_D      <- last_model$is_P_D
    out$names       <- last_model$names
    out$ind_test    <- last_model$ind_test
    out$diagnostics <- last_model$diagnostics
    out$call        <- call_saved
    
    class(out) <- "mseldml"
    return(out)
  }
  
  # -----------------------------------
  # Validation of the input
  # -----------------------------------
  X   <- as.matrix(X)
  W_Z <- as.matrix(W_Z)
  
  # Check that all inputs have the same number of observations
  n <- length(Y)
  if (nrow(X) != n)
  {
    stop("The arguments 'X' and 'Y' must have the same number of ",
         "observations.")
  }
  if (nrow(W_Z) != n)
  {
    stop("The arguments 'W_Z' and 'Y' must have the same number of ",
         "observations.")
  }
  if (length(D) != n)
  {
    stop("The arguments 'D' and 'Y' must have the same number of ",
         "observations.")
  }
  
  # Check that the input types are numeric
  if (!is.numeric(Y))
  {
    stop("The argument 'Y' must be numeric.")
  }
  if (!is.numeric(X) || any(!is.finite(X[!is.na(X)])))
  {
    stop("The argument 'X' must be a numeric matrix.")
  }
  if (!is.numeric(W_Z) || any(!is.finite(W_Z[!is.na(W_Z)])))
  {
    stop("The argument 'W_Z' must be a numeric matrix.")
  }
  if (!is.numeric(D) || any(!is.finite(D[!is.na(D)])))
  {
    stop("The argument 'D' must be a numeric vector.")
  }
  
  # Check the control and treated codes
  if (length(d0) != 1L || !is.numeric(d0) || !is.finite(d0) ||
      length(d1) != 1L || !is.numeric(d1) || !is.finite(d1) ||
      d0 == d1)
  {
    stop("The arguments 'd0' and 'd1' must be distinct finite numeric ",
         "scalars.")
  }
  
  # -----------------------------------
  # Missing-value handling
  # -----------------------------------
  if (na_action != "na.pass")
  {
    # Identify rows with complete covariates, treatment and selection
    complete_X <- complete.cases(X)
    complete_W <- complete.cases(W_Z)
    complete_D <- !is.na(D)
    complete_Z <- if (is.null(Z)) rep(TRUE, n) else complete.cases(Z)
    complete   <- complete_X & complete_W & complete_D & complete_Z
    
    # Drop or fail on incomplete rows
    if (any(!complete))
    {
      if (na_action == "na.fail")
      {
        stop("Missing values found in 'X', 'W_Z', 'D', or 'Z'. ",
             "Use 'na_action = \"na.omit\"' to drop them automatically.")
      }
      warning(sum(!complete), " observation(s) dropped due to missing ",
              "values in 'X', 'W_Z', 'D', or 'Z'.")
      X   <- X[complete, , drop = FALSE]
      W_Z <- W_Z[complete, , drop = FALSE]
      D   <- D[complete]
      Y   <- Y[complete]
      Z   <- if (is.null(Z)) NULL else Z[complete, , drop = FALSE]
      n   <- length(Y)
    }
  }
  
  # Check that the treatment has exactly the two declared levels
  if (!setequal(unique(D), c(d0, d1)))
  {
    stop("The argument 'D' must contain exactly the two levels 'd0' and ",
         "'d1'.")
  }
  
  # Check the number of cross-fitting folds
  if (length(cf_folds) != 1L || !is.finite(cf_folds) ||
      cf_folds != as.integer(cf_folds) || cf_folds < 2L || cf_folds > n)
  {
    stop("The argument 'cf_folds' must be an integer between 2 and n.")
  }
  
  # -----------------------------------
  # Trimming specification
  # -----------------------------------
  if (!is.numeric(trim_prob) || length(trim_prob) == 0L)
  {
    stop("The argument 'trim_prob' must be a numeric vector of length 1 ",
         "or 2.")
  }
  
  # Interpret a scalar as a one-sided bound
  if (length(trim_prob) == 1L)
  {
    if (trim_prob <= 0.5)
    {
      trim_prob <- c(trim_prob, Inf)
    }
    else
    {
      trim_prob <- c(-Inf, trim_prob)
    }
  }
  
  # Validate the resulting interval
  if (length(trim_prob) != 2L ||
      !is.finite(trim_prob[1]) ||
      trim_prob[1] >= trim_prob[2])
  {
    stop("The argument 'trim_prob' must specify a valid trimming interval ",
         "with finite lower bound and lower < upper.")
  }
  
  # -----------------------------------
  # 'Z' and 'z_max' validation
  # -----------------------------------
  Z_joint <- rep(1, n)
  if (!is.null(Z))
  {
    # Coerce to matrix and check dimensions
    Z <- as.matrix(Z)
    if (nrow(Z) != n)
    {
      stop("The arguments 'Z' and 'Y' must have the same number of ",
           "observations.")
    }
    if (ncol(Z) == 0)
    {
      stop("The argument 'Z' must have at least one column.")
    }
    
    # Check the target categories
    if (is.null(z) || length(z) != ncol(Z))
    {
      stop("The argument 'z' must give one target value per column of 'Z'.")
    }
    
    # Check that the codes are integers
    if (!is.numeric(Z) || anyNA(Z) || any(!is.finite(Z)) ||
        any(Z != floor(Z)))
    {
      stop("The argument 'Z' must contain non-missing integer-coded ",
           "ordinal values.")
    }
    if (!is.numeric(z) || anyNA(z) || any(!is.finite(z)) ||
        any(z != floor(z)))
    {
      stop("The argument 'z' must contain finite integer target categories.")
    }
    
    # Default 'z_max' to the observed column maxima if not supplied
    if (is.null(z_max))
    {
      z_max <- apply(Z, 2, max)
      message("Note: 'z_max' defaulted to the observed column maxima (",
              paste(z_max, collapse = ", "),
              "). If the theoretical support is wider, pass 'z_max' ",
              "explicitly; otherwise the control-function coordinates for ",
              "exact selection are computed on the wrong support.")
    }
    
    # Validate the declared support
    if (!is.numeric(z_max) || anyNA(z_max) || any(!is.finite(z_max)) ||
        any(z_max < 0) || any(z_max != floor(z_max)))
    {
      stop("The argument 'z_max' must contain finite nonnegative integer ",
           "support maxima.")
    }
    if (any(z < 0) || any(z > z_max))
    {
      stop("Every target category in 'z' must lie within its declared ",
           "support in 'z_max'.")
    }
    
    # Check that the observed values lie within the declared support
    for (j in seq_len(ncol(Z)))
    {
      if (any(Z[, j] < 0 | Z[, j] > z_max[j]))
      {
        stop("Observed values of 'Z' lie outside the declared support in ",
             "column ", j, ": allowed [0, ", z_max[j], "], observed [",
             min(Z[, j]), ", ", max(Z[, j]), "].")
      }
    }
    
    # Build the joint selection indicator
    Z_joint <- apply(Z, 1, function(row) all(row == z))
    if (length(unique(Z_joint)) == 1L)
    {
      stop("The selection indicator 'Z_joint' is constant. The estimator ",
           "requires variation in the selection indicator. If all ",
           "observations are selected, pass 'Z = NULL' instead.")
    }
  }
  else
  {
    # 'z' is meaningless without selection
    if (!is.null(z))
    {
      stop("The argument 'z' must be NULL when 'Z' is NULL.")
    }
  }
  
  # Mark unselected outcomes as missing
  Y[Z_joint == 0] <- NA
  
  # Check that selected outcomes are fully observed
  Y_selected <- Y[Z_joint == 1]
  if (anyNA(Y_selected) || any(!is.finite(Y_selected)))
  {
    stop("The argument 'Y' must be finite and observed for every selected ",
         "observation.")
  }
  
  # Validate or draw the cross-fitting folds
  if (is.null(ind_test))
  {
    ind_test <- cf_ind_split(x = n, n_folds = cf_folds, x_is_size = TRUE)
  }
  else
  {
    if (length(ind_test) != cf_folds)
    {
      stop("The argument 'ind_test' must contain exactly cf_folds folds.")
    }
    all_idx <- unlist(ind_test)
    if (anyNA(all_idx) || any(!is.finite(all_idx)) ||
        any(all_idx != floor(all_idx)) ||
        any(all_idx < 1 | all_idx > n) ||
        length(all_idx) != n ||
        anyDuplicated(all_idx) != 0L ||
        any(sapply(ind_test, length) == 0L))
    {
      stop("The argument 'ind_test' must partition 1:n with no duplicates, ",
           "no NA, and no empty folds.")
    }
  }
  out$ind_test <- ind_test
  
  # -----------------------------------
  # Preliminary values
  # -----------------------------------
  n_Z <- 0
  if (!is.null(Z))
  {
    n_Z <- ncol(Z)
  }
  
  # Build the matrix of threshold indicators for the selection variables
  Zt       <- NULL
  Zt_pairs <- list()
  n_prob   <- 0
  if (!is.null(Z))
  {
    for (j in seq_len(n_Z))
    {
      lower_idx <- NULL
      upper_idx <- NULL
      if (z[j] > 0)
      {
        Zt <- cbind(Zt, as.numeric(Z[, j] <= z[j] - 1))
        lower_idx <- ncol(Zt)
      }
      if (z[j] < z_max[j])
      {
        Zt <- cbind(Zt, as.numeric(Z[, j] <= z[j]))
        upper_idx <- ncol(Zt)
      }
      if (!is.null(lower_idx) && !is.null(upper_idx))
      {
        Zt_pairs[[length(Zt_pairs) + 1L]] <- c(lower_idx, upper_idx)
      }
    }
    if (is.null(Zt))
    {
      Zt <- matrix(numeric(0), nrow = n, ncol = 0)
    }
    Zt     <- as.matrix(Zt)
    n_prob <- ncol(Zt)
  }
  
  # Dimensions of the data blocks
  n_D   <- 1
  n_X   <- ncol(X)
  n_W_Z <- ncol(W_Z)
  
  # Build the internal bind of covariates, treatment and restrictions
  DXW_data <- cbind(D, X, W_Z)
  
  # Label-to-position maps for the internal bind
  ind_vars_DXW <- list(D   = n_D,
                       X   = (n_D + 1):(n_D + n_X),
                       W_Z = (n_D + n_X + 1):(n_D + n_X + n_W_Z))
  ind_vars_DXP <- list(D = n_D,
                       X = (n_D + 1):(n_D + n_X))
  ind_vars_XW  <- list(X   = 1:n_X,
                       W_Z = (n_X + 1):(n_X + n_W_Z))
  ind_vars_XP  <- list(X = 1:n_X)
  if (n_prob >= 1)
  {
    ind_vars_DXP[["P"]] <- (n_D + n_X + 1):(n_D + n_X + n_prob)
    ind_vars_XP[["P"]]  <- (n_X + 1):(n_X + n_prob)
  }
  
  # Storage for the second-stage nuisances and gradients
  Y1_mean <- matrix(NA_real_, ncol = 2, nrow = n)
  Y0_mean <- matrix(NA_real_, ncol = 2, nrow = n)
  grad1   <- array(NA_real_, dim = c(n, n_prob, 2))
  grad0   <- array(NA_real_, dim = c(n, n_prob, 2))
  
  # Storage for the selection-related nuisances
  Z_prob         <- matrix(NA_real_, ncol = n_prob, nrow = n)
  Z_joint_prob2  <- vector(mode = "numeric",  length = n)
  Z_prob_test    <- array(NA_real_, dim = c(n, n_prob, 2))
  
  # Inspect the user-supplied nuisances
  has_D1 <- hasName(x = nuisances, name = "D1_prob")
  has_D0 <- hasName(x = nuisances, name = "D0_prob")
  
  # Validate 'D1_prob'
  if (has_D1)
  {
    if (!is.numeric(nuisances$D1_prob))
    {
      stop("The entry 'nuisances$D1_prob' must be a numeric vector.")
    }
    if (!is.null(dim(nuisances$D1_prob)) ||
        length(nuisances$D1_prob) != n)
    {
      stop("The entry 'nuisances$D1_prob' must be a length-n vector.")
    }
    D1_supp <- as.numeric(nuisances$D1_prob)
    if (any(!is.finite(D1_supp)) ||
        any(D1_supp <= 0) || any(D1_supp >= 1))
    {
      stop("The entry 'nuisances$D1_prob' must lie strictly in (0, 1).")
    }
  }
  
  # Validate 'D0_prob'
  if (has_D0)
  {
    if (!is.numeric(nuisances$D0_prob))
    {
      stop("The entry 'nuisances$D0_prob' must be a numeric vector.")
    }
    if (!is.null(dim(nuisances$D0_prob)) ||
        length(nuisances$D0_prob) != n)
    {
      stop("The entry 'nuisances$D0_prob' must be a length-n vector.")
    }
    D0_supp <- as.numeric(nuisances$D0_prob)
    if (any(!is.finite(D0_supp)) ||
        any(D0_supp <= 0) || any(D0_supp >= 1))
    {
      stop("The entry 'nuisances$D0_prob' must lie strictly in (0, 1).")
    }
  }
  
  # Complete one of the two supplied propensity vectors
  if (has_D1 && !has_D0)
  {
    D0_supp <- 1 - D1_supp
    has_D0  <- TRUE
  }
  if (has_D0 && !has_D1)
  {
    D1_supp <- 1 - D0_supp
    has_D1  <- TRUE
  }
  if (has_D1 && has_D0)
  {
    if (any(abs(D1_supp + D0_supp - 1) > 1e-8))
    {
      stop("The entries 'D1_prob' and 'D0_prob' must be complementary ",
           "probabilities.")
    }
  }
  
  # Store the propensity matrices
  D1_prob <- if (has_D1) matrix(D1_supp, n, 2) else matrix(NA_real_, n, 2)
  D0_prob <- if (has_D0) matrix(D0_supp, n, 2) else matrix(NA_real_, n, 2)
  
  # Validate 'Z_prob' if supplied
  has_Z_prob <- hasName(x = nuisances, name = "Z_prob")
  if (has_Z_prob)
  {
    if (!is.numeric(nuisances$Z_prob))
    {
      stop("The entry 'nuisances$Z_prob' must be a numeric matrix or vector.")
    }
    Z_prob <- as.matrix(nuisances$Z_prob)
    if (!identical(dim(Z_prob), c(n, n_prob)))
    {
      stop("The entry 'nuisances$Z_prob' must have n rows and n_prob ",
           "columns.")
    }
  }
  
  # Validate 'Z_joint_prob2' if supplied
  has_Z_joint_prob2 <- hasName(x = nuisances, name = "Z_joint_prob2")
  if (has_Z_joint_prob2)
  {
    if (!is.numeric(nuisances$Z_joint_prob2))
    {
      stop("The entry 'nuisances$Z_joint_prob2' must be a numeric vector.")
    }
    if (!is.null(dim(nuisances$Z_joint_prob2)) ||
        length(nuisances$Z_joint_prob2) != n)
    {
      stop("The entry 'nuisances$Z_joint_prob2' must be a length-n vector.")
    }
    Z_joint_prob2 <- as.numeric(nuisances$Z_joint_prob2)
  }
  
  # Without sample selection, the joint selection probability equals one
  if (is.null(Z))
  {
    if (has_Z_joint_prob2 &&
        any(abs(Z_joint_prob2 - 1) > 1e-8))
    {
      warning("Ignoring 'nuisances$Z_joint_prob2' when 'Z = NULL'; ",
              "the selection probability is set to 1.")
    }
    Z_joint_prob2     <- rep(1, n)
    has_Z_joint_prob2 <- TRUE
  }
  
  # Canonical form of the required nuisances
  l <- c("Z_prob"        = n_prob,
         "Y_mean"        = 1L,
         "Z_joint_prob2" = 1L,
         "D_prob"        = 1L)
  
  # Normalize the learner, predictor and control lists
  learner           <- nuisance_validate(x = learner,           l = l, type = "function")
  predictor         <- nuisance_validate(x = predictor,         l = l, type = "function")
  data_transform    <- nuisance_validate(x = data_transform,    l = l, type = "function")
  control_learner   <- nuisance_validate(x = control_learner,   l = l, type = "control")
  control_predictor <- nuisance_validate(x = control_predictor, l = l, type = "control")
  control_transform <- nuisance_validate(x = control_transform, l = l, type = "control")
  
  # -----------------------------------
  # Cross-fitting
  # -----------------------------------
  
  # Decide which columns require numeric derivatives
  ind_grad_use <- NULL
  if (!nograd && n_prob > 0)
  {
    ind_grad_use <- ind_vars_DXP[["P"]]
  }
  
  # Counter of monotonicity repairs applied across all folds
  n_projected <- 0L
  
  for (i in seq_len(cf_folds))
  {
    # Outer training sample as the complement of the current test fold
    full_train <- cf_ind_combine(ind_test, -i)
    
    # Split the outer training sample into inner halves
    if (is_nested)
    {
      if (length(full_train) < 2L)
      {
        stop("Each outer training sample must contain at least two ",
             "observations for nested cross-fitting.")
      }
      ind_train <- cf_ind_split(full_train, 2L, x_is_size = FALSE)
      n_inner   <- 2
    }
    else
    {
      ind_train <- list(full_train, full_train)
      n_inner   <- 1
    }
    
    for (t in seq_len(n_inner))
    {
      # Swap the two inner halves on the second pass
      if ((t == 2) && is_nested)
      {
        ind_train <- list(ind_train[[2]], ind_train[[1]])
      }
      
      # Rows on which the selection nuisances are evaluated
      ind_Z <- c(ind_train[[2]], ind_test[[i]])
      
      # Fit the selection probabilities
      if (n_prob > 0)
      {
        for (j in seq_len(n_prob))
        {
          if (!has_Z_prob)
          {
            if (is_P_D)
            {
              Z_prob[ind_Z, j] <- nuisance(
                x                 = DXW_data,
                y                 = Zt[, j],
                d0                = d0,
                d1                = d1,
                learner           = learner[["Z_prob"]][[j]],
                predictor         = predictor[["Z_prob"]][[j]],
                data_transform    = data_transform[["Z_prob"]][[j]],
                control_learner   = control_learner[["Z_prob"]][[j]],
                control_predictor = control_predictor[["Z_prob"]][[j]],
                control_transform = control_transform[["Z_prob"]][[j]],
                ind_train         = ind_train[[1]],
                ind_test          = ind_Z,
                ind_vars          = ind_vars_DXW)$pred
            }
            else
            {
              Z_prob[ind_Z, j] <- nuisance(
                x                 = DXW_data[, -ind_vars_DXW[["D"]], drop = FALSE],
                y                 = Zt[, j],
                d0                = d0,
                d1                = d1,
                learner           = learner[["Z_prob"]][[j]],
                predictor         = predictor[["Z_prob"]][[j]],
                data_transform    = data_transform[["Z_prob"]][[j]],
                control_learner   = control_learner[["Z_prob"]][[j]],
                control_predictor = control_predictor[["Z_prob"]][[j]],
                control_transform = control_transform[["Z_prob"]][[j]],
                ind_train         = ind_train[[1]],
                ind_test          = ind_Z,
                ind_vars          = ind_vars_XW)$pred
            }
          }
        }
        
        # One-sided monotonicity repair on the fitted CDF probabilities
        if (length(Zt_pairs) > 0)
        {
          for (p in Zt_pairs)
          {
            lower_vals  <- Z_prob[ind_Z, p[1]]
            upper_vals  <- Z_prob[ind_Z, p[2]]
            viol        <- lower_vals > upper_vals
            n_projected <- n_projected + sum(viol, na.rm = TRUE)
            Z_prob[ind_Z, p[1]] <- pmin(lower_vals, upper_vals)
          }
        }
        
        # Save the out-of-fold probabilities used in the score
        if (!nograd)
        {
          Z_prob_test[ind_test[[i]], , t] <-
            Z_prob[ind_test[[i]], , drop = FALSE]
        }
      }
      
      # Internal bind with the fitted probabilities
      DXP_data <- cbind(D, X, Z_prob)
      
      # Fit the outcome regression
      val <- nuisance(
        x                 = DXP_data,
        y                 = Y,
        d0                = d0,
        d1                = d1,
        D_values          = c(d0, d1),
        learner           = learner[["Y_mean"]][[1]],
        predictor         = predictor[["Y_mean"]][[1]],
        data_transform    = data_transform[["Y_mean"]][[1]],
        control_learner   = control_learner[["Y_mean"]][[1]],
        control_predictor = control_predictor[["Y_mean"]][[1]],
        control_transform = control_transform[["Y_mean"]][[1]],
        ind_train         = ind_train[[2]],
        ind_test          = ind_test[[i]],
        ind_vars          = ind_vars_DXP,
        ind_grad          = ind_grad_use)
      
      # Store the fitted potential outcomes
      Y1_mean[ind_test[[i]], t] <- val$pred[, 2]
      Y0_mean[ind_test[[i]], t] <- val$pred[, 1]
      
      # Store the numeric derivatives if computed
      if (!is.null(ind_grad_use) && !is.null(val$grad))
      {
        grad1[ind_test[[i]], , t] <- val$grad[, , 2]
        grad0[ind_test[[i]], , t] <- val$grad[, , 1]
      }
      
      # Fit the propensity score if not supplied
      if (!has_D1)
      {
        D1_prob[ind_test[[i]], t] <- nuisance(
          x                 = DXP_data[, -ind_vars_DXP[["D"]], drop = FALSE],
          y                 = as.numeric(D == d1),
          d0                = d0,
          d1                = d1,
          learner           = learner[["D_prob"]][[1]],
          predictor         = predictor[["D_prob"]][[1]],
          data_transform    = data_transform[["D_prob"]][[1]],
          control_learner   = control_learner[["D_prob"]][[1]],
          control_predictor = control_predictor[["D_prob"]][[1]],
          control_transform = control_transform[["D_prob"]][[1]],
          ind_train         = ind_train[[2]],
          ind_test          = ind_test[[i]],
          ind_vars          = ind_vars_XP)$pred
      }
      
      # Complete the control propensity by complementarity
      if (!has_D0)
      {
        D0_prob[ind_test[[i]], t] <- 1 - D1_prob[ind_test[[i]], t]
      }
    }
    
    # Fit the joint selection probability if not supplied
    if (!has_Z_joint_prob2)
    {
      if (is.null(Z))
      {
        Z_joint_prob2[ind_test[[i]]] <- 1
      }
      else
      {
        Z_joint_prob2[ind_test[[i]]] <- nuisance(
          x                 = DXW_data,
          y                 = as.numeric(Z_joint),
          d0                = d0,
          d1                = d1,
          learner           = learner[["Z_joint_prob2"]][[1]],
          predictor         = predictor[["Z_joint_prob2"]][[1]],
          data_transform    = data_transform[["Z_joint_prob2"]][[1]],
          control_learner   = control_learner[["Z_joint_prob2"]][[1]],
          control_predictor = control_predictor[["Z_joint_prob2"]][[1]],
          control_transform = control_transform[["Z_joint_prob2"]][[1]],
          ind_train         = full_train,
          ind_test          = ind_test[[i]],
          ind_vars          = ind_vars_DXW)$pred
      }
    }
  }
  
  # Warn if the monotonicity repair was active
  if (n_projected > 0L)
  {
    warning("Applied one-sided monotonicity repair to ", n_projected,
            " threshold CDF value(s) across ", n_Z, " selection equation(s). ",
            "Consider a smoother learner for 'Z_prob' (for example, ",
            "learner_glmnet) or an ordinal model if the violations are ",
            "frequent.")
  }
  
  # -----------------------------------
  # Aggregation
  # -----------------------------------
  if (is_nested)
  {
    # Average the two inner branches
    Y1_mean <- rowMeans(Y1_mean)
    Y0_mean <- rowMeans(Y0_mean)
    D1_prob <- if (has_D1) D1_prob[, 1] else rowMeans(D1_prob)
    D0_prob <- if (has_D0) D0_prob[, 1] else rowMeans(D0_prob)
    
    if (!nograd)
    {
      # Average the derivatives and out-of-fold probabilities
      grad1 <- (grad1[, , 1] + grad1[, , 2]) / 2
      grad0 <- (grad0[, , 1] + grad0[, , 2]) / 2
      if (is.vector(grad1))
      {
        grad1 <- matrix(grad1, ncol = 1)
        grad0 <- matrix(grad0, ncol = 1)
      }
      Z_prob_test <- (Z_prob_test[, , 1] + Z_prob_test[, , 2]) / 2
      if (is.vector(Z_prob_test))
      {
        Z_prob_test <- matrix(Z_prob_test, ncol = 1)
      }
    }
  }
  else
  {
    # Take the only computed column
    Y1_mean <- Y1_mean[, 1]
    Y0_mean <- Y0_mean[, 1]
    D1_prob <- D1_prob[, 1]
    D0_prob <- D0_prob[, 1]
    
    if (!nograd)
    {
      grad1 <- grad1[, , 1]
      grad0 <- grad0[, , 1]
      if (is.vector(grad1))
      {
        grad1 <- matrix(grad1, ncol = 1)
        grad0 <- matrix(grad0, ncol = 1)
      }
      Z_prob_test <- Z_prob_test[, , 1]
      if (is.vector(Z_prob_test))
      {
        Z_prob_test <- matrix(Z_prob_test, ncol = 1)
      }
    }
  }
  
  # -----------------------------------
  # Safeguards
  # -----------------------------------
  if (any(!is.finite(Y1_mean)) || any(!is.finite(Y0_mean)))
  {
    stop("Outcome-regression predictions are not finite. Check 'X', ",
         "'W_Z', and the learner.")
  }
  
  if (any(!is.finite(Z_joint_prob2)) ||
      any(Z_joint_prob2 <= 0) || any(Z_joint_prob2 > 1))
  {
    stop("'Z_joint_prob2' must contain finite probabilities in (0, 1].")
  }
  
  if (any(!is.finite(D1_prob)) || any(D1_prob <= 0) || any(D1_prob >= 1) ||
      any(!is.finite(D0_prob)) || any(D0_prob <= 0) || any(D0_prob >= 1))
  {
    stop("'D1_prob' and 'D0_prob' must contain finite probabilities in ",
         "(0, 1).")
  }
  
  if (n_prob > 0)
  {
    if (any(!is.finite(Z_prob)) || any(Z_prob < 0) || any(Z_prob > 1))
    {
      stop("Invalid CDF probabilities in 'Z_prob'.")
    }
  }
  
  if (!nograd)
  {
    if (any(!is.finite(Z_prob_test)) ||
        any(Z_prob_test < 0) || any(Z_prob_test > 1))
    {
      stop("Invalid CDF probabilities in 'Z_prob_test'.")
    }
    if (any(!is.finite(grad1)) || any(!is.finite(grad0)))
    {
      stop("Non-finite gradients in 'grad1' or 'grad0'.")
    }
  }
  
  # -----------------------------------
  # Trimming mask
  # -----------------------------------
  trim_mask <- (D1_prob >= trim_prob[1]) & (D1_prob <= trim_prob[2]) &
    (D0_prob >= trim_prob[1]) & (D0_prob <= trim_prob[2]) &
    (Z_joint_prob2 >= trim_prob[1]) &
    (Z_joint_prob2 <= trim_prob[2])
  
  n_trimmed <- sum(!trim_mask)
  
  if (n_trimmed > 0L && sum(trim_mask) < 10L)
  {
    stop("Trimming removed all but ", sum(trim_mask),
         " observation(s). Relax 'trim_prob'.")
  }
  
  # -----------------------------------
  # Indicators for the estimation sample
  # -----------------------------------
  Z_cond   <- (Z_joint == 1)
  D1_cond  <- (D == d1)
  D0_cond  <- (D == d0)
  D1Z_cond <- D1_cond & Z_cond
  D0Z_cond <- D0_cond & Z_cond
  
  Z_cond_t   <- Z_cond   & trim_mask
  D1_cond_t  <- D1_cond  & trim_mask
  D0_cond_t  <- D0_cond  & trim_mask
  D1Z_cond_t <- D1Z_cond & trim_mask
  D0Z_cond_t <- D0Z_cond & trim_mask
  
  P_Z_t   <- mean(Z_cond_t)
  P_D1_t  <- mean(D1_cond_t)
  P_D0Z_t <- mean(D0Z_cond_t)
  P_D1Z_t <- mean(D1Z_cond_t)
  
  if (!is.finite(P_Z_t)   || P_Z_t   <= 0)
  {
    stop("'ATES' is undefined: no selected observations after trimming.")
  }
  if (!is.finite(P_D1_t)  || P_D1_t  <= 0)
  {
    stop("'ATT' is undefined: no observations with 'D == d1' after ",
         "trimming.")
  }
  if (!is.finite(P_D0Z_t) || P_D0Z_t <= 0)
  {
    stop("The estimators require selected observations in the control ",
         "group.")
  }
  if (!is.finite(P_D1Z_t) || P_D1Z_t <= 0)
  {
    stop("'ATTS' is undefined: no selected observations with 'D == d1' ",
         "after trimming.")
  }
  
  # Retain the untrimmed quantities for the diagnostics block
  P_Z   <- mean(Z_cond)
  P_D1  <- mean(D1_cond)
  P_D0Z <- mean(D0Z_cond)
  P_D1Z <- mean(D1Z_cond)
  
  # Pre-compute the differences used in the scores
  Y1_diff <- Y - Y1_mean
  Y0_diff <- Y - Y0_mean
  Y_diff  <- Y1_mean - Y0_mean
  
  # Shorthand for the joint selection probability
  tildeP  <- Z_joint_prob2
  
  # Ratio of treated to control propensity in the control group
  ratio10           <- rep(0, n)
  ratio10[D0_cond]  <- D1_prob[D0_cond] / D0_prob[D0_cond]
  
  # Storage for the influence functions
  out$trim <- matrix(trim_mask, nrow = n, ncol = 4)
  out$EIF0 <- matrix(0, nrow = n, ncol = 4)
  colnames(out$EIF0) <- c("ATES", "ATTS", "ATE", "ATT")
  if (!nograd)
  {
    out$EIF <- matrix(0, nrow = n, ncol = 4)
    colnames(out$EIF) <- c("ATES", "ATTS", "ATE", "ATT")
  }
  
  # -----------------------------------
  # ATES
  # -----------------------------------
  r_ATES           <- Z_joint * Y_diff
  r_ATES[D1Z_cond] <- r_ATES[D1Z_cond] + Y1_diff[D1Z_cond] / D1_prob[D1Z_cond]
  r_ATES[D0Z_cond] <- r_ATES[D0Z_cond] - Y0_diff[D0Z_cond] / D0_prob[D0Z_cond]
  r_ATES[!trim_mask] <- 0
  
  ATES_DML0 <- sum(r_ATES) / sum(Z_cond_t)
  ATES_IF0  <- (r_ATES - Z_cond_t * ATES_DML0) / P_Z_t
  ATES_DML0_var <- sum(ATES_IF0^2) / n^2
  ATES_DML0_se  <- sqrt(ATES_DML0_var)
  out$EIF0[, "ATES"] <- ATES_IF0
  
  if (!nograd)
  {
    grad_adj <- rep(0, n)
    if (n_prob > 0)
    {
      for (t in seq_len(ncol(grad1)))
      {
        grad_adj <- grad_adj +
          (Zt[, t] - Z_prob_test[, t]) *
          (grad1[, t] * (1 - D1_cond / D1_prob) -
             grad0[, t] * (1 - D0_cond / D0_prob))
      }
    }
    grad_adj[!trim_mask] <- 0
    r_ATES_dml  <- r_ATES + tildeP * grad_adj
    ATES_DML    <- sum(r_ATES_dml) / sum(Z_cond_t)
    ATES_IF     <- (r_ATES_dml - Z_cond_t * ATES_DML) / P_Z_t
    ATES_DML_var <- sum(ATES_IF^2) / n^2
    ATES_DML_se  <- sqrt(ATES_DML_var)
    out$EIF[, "ATES"] <- ATES_IF
  }
  
  # -----------------------------------
  # ATTS
  # -----------------------------------
  r_ATTS <- numeric(n)
  r_ATTS[D1Z_cond] <-  Y0_diff[D1Z_cond]
  r_ATTS[D0Z_cond] <- -ratio10[D0Z_cond] * Y0_diff[D0Z_cond]
  r_ATTS[!trim_mask] <- 0
  
  ATTS_DML0 <- sum(r_ATTS) / sum(D1Z_cond_t)
  ATTS_IF0  <- (r_ATTS - D1Z_cond_t * ATTS_DML0) / P_D1Z_t
  ATTS_DML0_var <- sum(ATTS_IF0^2) / n^2
  ATTS_DML0_se  <- sqrt(ATTS_DML0_var)
  out$EIF0[, "ATTS"] <- ATTS_IF0
  
  if (!nograd)
  {
    grad_adj_ATTS <- numeric(n)
    if (n_prob > 0)
    {
      for (t in seq_len(n_prob))
      {
        grad_adj_ATTS <- grad_adj_ATTS +
          (Zt[, t] - Z_prob_test[, t]) * tildeP *
          grad0[, t] * (ratio10 * D0_cond - D1_cond)
      }
    }
    grad_adj_ATTS[!trim_mask] <- 0
    r_ATTS_dml  <- r_ATTS + grad_adj_ATTS
    ATTS_DML    <- sum(r_ATTS_dml) / sum(D1Z_cond_t)
    ATTS_IF     <- (r_ATTS_dml - D1Z_cond_t * ATTS_DML) / P_D1Z_t
    ATTS_DML_var <- sum(ATTS_IF^2) / n^2
    ATTS_DML_se  <- sqrt(ATTS_DML_var)
    out$EIF[, "ATTS"] <- ATTS_IF
  }
  
  # -----------------------------------
  # ATE
  # -----------------------------------
  r_ATE           <- Y_diff
  r_ATE[D1Z_cond] <- r_ATE[D1Z_cond] +
    Y1_diff[D1Z_cond] / (tildeP[D1Z_cond] * D1_prob[D1Z_cond])
  r_ATE[D0Z_cond] <- r_ATE[D0Z_cond] -
    Y0_diff[D0Z_cond] / (tildeP[D0Z_cond] * D0_prob[D0Z_cond])
  r_ATE[!trim_mask] <- 0
  
  ATE_DML0 <- sum(r_ATE) / sum(trim_mask)
  ATE_IF0  <- (r_ATE - trim_mask * ATE_DML0) / mean(trim_mask)
  ATE_DML0_var <- sum(ATE_IF0^2) / n^2
  ATE_DML0_se  <- sqrt(ATE_DML0_var)
  out$EIF0[, "ATE"] <- ATE_IF0
  
  if (!nograd)
  {
    grad_adj_ATE <- numeric(n)
    if (n_prob > 0)
    {
      for (t in seq_len(n_prob))
      {
        grad_adj_ATE <- grad_adj_ATE -
          (Zt[, t] - Z_prob_test[, t]) *
          (grad1[, t] * D1_cond / D1_prob -
             grad0[, t] * D0_cond / D0_prob)
      }
    }
    grad_adj_ATE[!trim_mask] <- 0
    r_ATE_dml  <- r_ATE + grad_adj_ATE
    ATE_DML    <- sum(r_ATE_dml) / sum(trim_mask)
    ATE_IF     <- (r_ATE_dml - trim_mask * ATE_DML) / mean(trim_mask)
    ATE_DML_var <- sum(ATE_IF^2) / n^2
    ATE_DML_se  <- sqrt(ATE_DML_var)
    out$EIF[, "ATE"] <- ATE_IF
  }
  
  # -----------------------------------
  # ATT
  # -----------------------------------
  r_ATT <- D1_cond * Y_diff
  r_ATT[D1Z_cond] <- r_ATT[D1Z_cond] +
    Y1_diff[D1Z_cond] / tildeP[D1Z_cond]
  r_ATT[D0Z_cond] <- r_ATT[D0Z_cond] -
    ratio10[D0Z_cond] * Y0_diff[D0Z_cond] / tildeP[D0Z_cond]
  r_ATT[!trim_mask] <- 0
  
  ATT_DML0 <- sum(r_ATT) / sum(D1_cond_t)
  ATT_IF0  <- (r_ATT - D1_cond_t * ATT_DML0) / P_D1_t
  ATT_DML0_var <- sum(ATT_IF0^2) / n^2
  ATT_DML0_se  <- sqrt(ATT_DML0_var)
  out$EIF0[, "ATT"] <- ATT_IF0
  
  if (!nograd)
  {
    grad_adj_ATT <- numeric(n)
    if (n_prob > 0)
    {
      for (t in seq_len(n_prob))
      {
        grad_adj_ATT <- grad_adj_ATT -
          (Zt[, t] - Z_prob_test[, t]) *
          (grad1[, t] * D1_cond - grad0[, t] * ratio10)
      }
    }
    grad_adj_ATT[!trim_mask] <- 0
    r_ATT_dml  <- r_ATT + grad_adj_ATT
    ATT_DML    <- sum(r_ATT_dml) / sum(D1_cond_t)
    ATT_IF     <- (r_ATT_dml - D1_cond_t * ATT_DML) / P_D1_t
    ATT_DML_var <- sum(ATT_IF^2) / n^2
    ATT_DML_se  <- sqrt(ATT_DML_var)
    out$EIF[, "ATT"] <- ATT_IF
  }
  
  # -----------------------------------
  # Covariance matrices of the four parameters
  # -----------------------------------
  par_order <- c("ATE", "ATES", "ATT", "ATTS")
  eif_order <- match(par_order, c("ATES", "ATTS", "ATE", "ATT"))
  
  cov_nograd <- crossprod(out$EIF0[, eif_order, drop = FALSE]) / n^2
  dimnames(cov_nograd) <- list(par_order, par_order)
  out$cov_nograd <- cov_nograd
  
  if (!nograd)
  {
    cov_dml <- crossprod(out$EIF[, eif_order, drop = FALSE]) / n^2
    dimnames(cov_dml) <- list(par_order, par_order)
    out$cov <- cov_dml
  }
  
  # -----------------------------------
  # Diagnostics block
  # -----------------------------------
  out$diagnostics <- list(
    P_Z             = P_Z,
    P_D1            = P_D1,
    P_D0Z           = P_D0Z,
    P_D1Z           = P_D1Z,
    D1_range        = range(D1_prob),
    D0_range        = range(D0_prob),
    tildeP_range    = range(tildeP),
    D1_below_05     = sum(D1_prob < 0.05),
    D0_below_05     = sum(D0_prob < 0.05),
    tildeP_below_05 = sum(tildeP  < 0.05),
    n_trimmed       = n_trimmed,
    n_projected     = n_projected,
    trim_prob       = trim_prob
  )
  
  # -----------------------------------
  # Output
  # -----------------------------------
  if (!nograd)
  {
    out$estimates <- c("ATES_DML"  = ATES_DML,    "ATTS_DML"  = ATTS_DML,
                       "ATE_DML"   = ATE_DML,     "ATT_DML"   = ATT_DML,
                       "ATES_DML0" = ATES_DML0,   "ATTS_DML0" = ATTS_DML0,
                       "ATE_DML0"  = ATE_DML0,    "ATT_DML0"  = ATT_DML0)
    out$se        <- c("ATES_DML"  = ATES_DML_se,  "ATTS_DML"  = ATTS_DML_se,
                       "ATE_DML"   = ATE_DML_se,   "ATT_DML"   = ATT_DML_se,
                       "ATES_DML0" = ATES_DML0_se, "ATTS_DML0" = ATTS_DML0_se,
                       "ATE_DML0"  = ATE_DML0_se,  "ATT_DML0"  = ATT_DML0_se)
  }
  else
  {
    out$estimates <- c("ATES_DML0" = ATES_DML0,   "ATTS_DML0" = ATTS_DML0,
                       "ATE_DML0"  = ATE_DML0,    "ATT_DML0"  = ATT_DML0)
    out$se        <- c("ATES_DML0" = ATES_DML0_se, "ATTS_DML0" = ATTS_DML0_se,
                       "ATE_DML0"  = ATE_DML0_se,  "ATT_DML0"  = ATT_DML0_se)
  }
  
  out$nuisances <- list(Z_prob        = Z_prob,
                        Y1_mean       = Y1_mean,
                        Y0_mean       = Y0_mean,
                        Z_joint_prob2 = Z_joint_prob2,
                        D1_prob       = D1_prob,
                        D0_prob       = D0_prob)
  if (!nograd)
  {
    out$nuisances$Z_prob_oof <- Z_prob_test
    out$nuisances$grad1      <- grad1
    out$nuisances$grad0      <- grad0
  }
  
  out$dim       <- list(n = n, n_X = n_X, n_Z = n_Z, n_prob = n_prob)
  out$is_Z      <- !is.null(Z)
  out$is_P_D    <- is_P_D
  out$names     <- list(D = colnames(as.matrix(D)), X = colnames(X),
                        Z = colnames(Z), W_Z = colnames(W_Z))
  out$nograd    <- nograd
  out$is_nested <- is_nested
  out$call      <- call_saved
  
  class(out) <- "mseldml"
  return(out)
}