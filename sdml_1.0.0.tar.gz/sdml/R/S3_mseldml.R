# ---------------------------------------------------------
# S3 methods: coef, vcov, confint, tidy, glance
# ---------------------------------------------------------

#' @title Extract coefficients from a mseldml object
#'
#' @description Returns the named numeric vector of point estimates
#' stored in the fitted model.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... further arguments. Currently ignored.
#'
#' @return A named numeric vector of point estimates.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{vcov.mseldml}},
#' \code{\link[sdml]{confint.mseldml}}
#'
#' @export
coef.mseldml <- function(object, ...)
{
  # Return the stored point estimates
  object$estimates
}

#' @title Extract the covariance matrix from a mseldml object
#'
#' @description Returns \code{object$cov} when \code{nograd = FALSE} and
#' \code{object$cov_nograd} when \code{nograd = TRUE}.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... further arguments. Currently ignored.
#'
#' @return A \eqn{4\times 4} numeric matrix with rows and columns
#' ordered \code{ATE}, \code{ATES}, \code{ATT}, \code{ATTS}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{coef.mseldml}}
#'
#' @export
vcov.mseldml <- function(object, ...)
{
  # Select the covariance matrix matching the requested mode
  if (isTRUE(object$nograd))
  {
    return(object$cov_nograd)
  }
  object$cov
}

#' @title Confidence intervals for a mseldml object
#'
#' @description Normal-theory confidence intervals for the point
#' estimates.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param parm an optional character vector of parameter names to
#' restrict the output to.
#' @param level a numeric value in \eqn{(0, 1)} giving the confidence
#' level. Defaults to \code{0.95}.
#' @param ... further arguments. Currently ignored.
#'
#' @return A numeric matrix with one row per parameter and two columns
#' giving the lower and upper bounds.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{coef.mseldml}}
#'
#' @export
confint.mseldml <- function(object, parm, level = 0.95, ...)
{
  # Extract the point estimates and their standard errors
  est <- coef(object)
  se  <- object$se
  
  # Compute the normal quantile and the bounds
  z     <- stats::qnorm(1 - (1 - level) / 2)
  ci    <- cbind(est - z * se, est + z * se)
  
  # Label the two columns with the tail probabilities
  alpha        <- (1 - level) / 2
  lo_pct       <- format(100 * alpha, trim = TRUE, scientific = FALSE)
  hi_pct       <- format(100 * (1 - alpha), trim = TRUE,
                         scientific = FALSE)
  colnames(ci) <- c(paste0(lo_pct, "%"), paste0(hi_pct, "%"))
  
  # Restrict to a subset of parameters when requested
  if (!missing(parm))
  {
    ci <- ci[parm, , drop = FALSE]
  }
  
  ci
}

#' @title Tidy a mseldml object
#'
#' @description Returns a broom-style data frame with one row per
#' estimate.
#'
#' @details
#' This is an S3 method for \code{generics::tidy}. To use it, ensure
#' the \pkg{generics} package is attached (or call
#' \code{generics::tidy(object)} directly).
#'
#' @param x an object of class \code{"mseldml"}.
#' @param conf.int a logical value. If \code{TRUE}, confidence bounds
#' are added.
#' @param conf.level the confidence level used when
#' \code{conf.int = TRUE}. Defaults to \code{0.95}.
#' @param ... further arguments. Currently ignored.
#'
#' @return A data frame with columns \code{term}, \code{estimate},
#' \code{std.error}, \code{statistic}, \code{p.value}, and, when
#' \code{conf.int = TRUE}, \code{conf.low} and \code{conf.high}.
#'
#' @importFrom generics tidy
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{glance.mseldml}}
#'
#' @export
tidy.mseldml <- function(x, conf.int = FALSE, conf.level = 0.95, ...)
{
  # Extract the point estimates and standard errors
  est <- coef(x)
  se  <- x$se
  
  # Compute the z-statistics and two-sided p-values
  z <- est / se
  p <- 2 * stats::pnorm(-abs(z))
  
  # Assemble the base data frame
  out <- data.frame(
    term      = names(est),
    estimate  = as.numeric(est),
    std.error = as.numeric(se),
    statistic = as.numeric(z),
    p.value   = as.numeric(p),
    stringsAsFactors = FALSE
  )
  
  # Add confidence bounds when requested
  if (conf.int)
  {
    ci            <- confint(x, level = conf.level)
    out$conf.low  <- ci[, 1]
    out$conf.high <- ci[, 2]
  }
  
  out
}

#' @title Glance at a mseldml object
#'
#' @description Returns a one-row summary of the model.
#'
#' @details
#' This is an S3 method for \code{generics::glance}.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param ... further arguments. Currently ignored.
#'
#' @return A one-row data frame with columns \code{nobs},
#' \code{n_select}, \code{n_prob}, \code{cf_folds}, \code{is_nested},
#' \code{n_rep} and \code{nograd}.
#'
#' @importFrom generics glance
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{tidy.mseldml}}
#'
#' @export
glance.mseldml <- function(x, ...)
{
  # Assemble the one-row summary
  data.frame(
    nobs      = x$dim$n,
    n_select  = x$dim$n_Z,
    n_prob    = x$dim$n_prob,
    cf_folds  = length(x$ind_test),
    is_nested = isTRUE(x$is_nested),
    n_rep     = if (is.null(x$n_rep)) 1L else x$n_rep,
    nograd    = isTRUE(x$nograd),
    stringsAsFactors = FALSE
  )
}

# ---------------------------------------------------------
# S3 methods: plot, update, predict
# ---------------------------------------------------------

#' @title Plot a mseldml object
#'
#' @description Produces a forest plot of the four estimates with
#' normal-theory confidence intervals, or a histogram of the estimated
#' control-function columns.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param type one of \code{"forest"} (default) or \code{"zprob"}.
#' @param conf.level the confidence level for the forest plot.
#' Defaults to \code{0.95}.
#' @param ... further arguments passed to \code{\link[graphics]{plot}}
#' (for \code{type = "forest"}) or \code{\link[graphics]{hist}} (for
#' \code{type = "zprob"}).
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @examples
#' \donttest{
#' # Fit a small model, then plot the four estimates
#' data <- data.frame(
#'   y = rnorm(200),
#'   x = rnorm(200),
#'   d = rbinom(200, size = 1, prob = 0.5)
#' )
#' model <- mseldml(data = data,
#'                  X = "x", W_Z = "x", D = "d", Y = "y",
#'                  Z = NULL)
#' plot(model, type = "forest")
#' }
#'
#' @export
plot.mseldml <- function(x, type = c("forest", "zprob"),
                         conf.level = 0.95, ...)
{
  # Match the requested plot type
  type <- match.arg(type)
  
  if (type == "forest")
  {
    # Select the family of estimates to display
    suffix    <- if (isTRUE(x$nograd)) "DML0" else "DML"
    par_order <- c("ATE", "ATES", "ATT", "ATTS")
    
    # Extract the estimates and standard errors
    est <- x$estimates[paste0(par_order, "_", suffix)]
    se  <- x$se[paste0(par_order, "_", suffix)]
    
    # Compute the confidence bounds
    z     <- stats::qnorm(1 - (1 - conf.level) / 2)
    ci_lo <- est - z * se
    ci_hi <- est + z * se
    ylim  <- range(c(ci_lo, ci_hi, est))
    k     <- length(est)
    
    # Draw the point estimates
    graphics::plot(seq_len(k), est, xaxt = "n",
                   ylim = ylim, xlab = "",
                   ylab = "Estimate", pch = 19,
                   main = paste0("Estimates (", suffix, ")"),
                   ...)
    
    # Add the confidence intervals and the zero line
    graphics::segments(seq_len(k), ci_lo, seq_len(k), ci_hi)
    graphics::abline(h = 0, lty = 2, col = "grey50")
    
    # Label the horizontal axis with the parameter names
    graphics::axis(1, at = seq_len(k), labels = par_order)
  }
  else
  {
    # Fail early if there are no selection equations
    if (is.null(x$nuisances$Z_prob) || ncol(x$nuisances$Z_prob) == 0L)
    {
      stop("The model has no selection equations; nothing to plot.")
    }
    
    # Extract the estimated probabilities and set the layout
    zp      <- x$nuisances$Z_prob
    n       <- ncol(zp)
    old_par <- graphics::par(no.readonly = TRUE)
    on.exit(graphics::par(old_par), add = TRUE)
    graphics::par(mfrow = c(1, n))
    
    # Draw one histogram per probability column
    for (j in seq_len(n))
    {
      graphics::hist(zp[, j], breaks = 30,
                     main = paste0("Z_prob column ", j),
                     xlab = "Estimated CDF",
                     col = "lightgrey", ...)
    }
  }
  
  invisible(x)
}

#' @title Update a mseldml fit
#'
#' @description Refits the model with one or more arguments replaced.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... named arguments to modify.
#' @param evaluate a logical value. If \code{TRUE} (the default) the
#' updated call is evaluated; if \code{FALSE} the call is returned
#' without evaluation.
#'
#' @return A new \code{"mseldml"} object, or a call when
#' \code{evaluate = FALSE}.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @export
update.mseldml <- function(object, ..., evaluate = TRUE)
{
  # Retrieve the matched call of the fitted model
  call <- object$call
  if (is.null(call))
  {
    stop("This mseldml object does not carry a call; refit with the ",
         "current version of mseldml().")
  }
  
  # Extract the replacement arguments from '...'
  extras <- match.call(expand.dots = FALSE)$...
  if (length(extras) > 0)
  {
    # Replace existing arguments in place
    existing <- !is.na(match(names(extras), names(call)))
    for (a in names(extras)[existing])
    {
      call[[a]] <- extras[[a]]
    }
    
    # Append new arguments to the call
    if (any(!existing))
    {
      call <- c(as.list(call), extras[!existing])
      call <- as.call(call)
    }
  }
  
  # Evaluate the updated call in the caller's environment
  if (evaluate)
  {
    eval(call, parent.frame())
  }
  else
  {
    call
  }
}

#' @title Predict from a mseldml object
#'
#' @description Not yet implemented. Out-of-sample prediction requires
#' storing the fitted learners for every fold, which is a substantially
#' different design from the current aggregation-based architecture.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param newdata a data frame or named list of new observations.
#' @param ... further arguments. Currently ignored.
#'
#' @return This function currently raises an error.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @export
predict.mseldml <- function(object, newdata = NULL, ...)
{
  stop("Out-of-sample prediction is not yet implemented. To obtain ",
       "potential outcomes on a new sample, refit the model on that ",
       "sample using mseldml(). A future release will support ",
       "out-of-sample prediction.")
}