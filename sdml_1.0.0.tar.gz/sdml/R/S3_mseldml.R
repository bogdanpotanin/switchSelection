# ---------------------------------------------------------
# S3 methods: coef, vcov, confint, tidy, glance
# ---------------------------------------------------------

#' @title Extract coefficients from a mseldml object
#'
#' @description Returns the named numeric vector of point estimates
#' stored in the fitted model.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param further arguments (currently ignored).
#'
#' @return A named numeric vector of point estimates.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{vcov.mseldml}},
#' \code{\link[sdml]{confint.mseldml}}
#'
#' @export
coef.mseldml <- function(object, ...)
{
  # Return the results
  return (object$estimates)
}

#' @title Extract the covariance matrix from a mseldml object
#'
#' @description Returns either the covariance matrix of the
#' derivative-corrected estimators or the covariance matrix of the
#' derivative-free estimators.
#'
#' @details
#' The fitted \code{\link[sdml]{mseldml}} object stores up to two
#' covariance matrices of size \eqn{4 \times 4}:
#' \itemize{
#' \item \code{cov}, the covariance matrix of the derivative-corrected
#'   estimators (suffix \code{_DML});
#' \item \code{cov_nograd}, the covariance matrix of the derivative-free
#'   estimators (suffix \code{_DML0}).
#' }
#' Both are in the canonical parameter order
#' \eqn{(\mathrm{ATES}, \mathrm{ATTS}, \mathrm{ATE}, \mathrm{ATT})}.
#' Which one is returned is controlled by the \code{nograd} argument.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param nograd a logical value selecting which covariance matrix to
#' return. If \code{TRUE}, returns \code{object$cov_nograd}, the
#' covariance matrix for the derivative-free estimators. If
#' \code{FALSE}, returns \code{object$cov}, the covariance matrix for
#' the derivative-corrected estimators. If \code{NULL} (the default),
#' the value stored in \code{object$nograd} is used, that is, the mode
#' that was requested when the model was fitted.
#' @param further arguments (currently ignored).
#'
#' @return A \eqn{4 \times 4} numeric covariance matrix with rows and
#' columns ordered \eqn{(\mathrm{ATES}, \mathrm{ATTS}, \mathrm{ATE},
#' \mathrm{ATT})}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{coef.mseldml}},
#' \code{\link[sdml]{confint.mseldml}}
#'
#' @export
vcov.mseldml <- function(object, nograd = NULL, ...)
{
  # Default to the mode that was used when the object was fitted
  if (is.null(nograd))
  {
    nograd <- isTRUE(object$nograd)
  }
  
  # Validate 'nograd'
  if (!is.logical(nograd) || (length(nograd) != 1L) || is.na(nograd))
  {
    stop("The argument 'nograd' must be TRUE, FALSE, or NULL.")
  }
  
  # Return the covariance matrix of the derivative-free estimators
  if (nograd)
  {
    if (is.null(object$cov_nograd))
    {
      stop("The derivative-free covariance matrix 'cov_nograd' is not ",
           "available in the object.")
    }
    return(object$cov_nograd)
  }
  
  # Return the covariance matrix of the derivative-corrected estimators
  if (is.null(object$cov))
  {
    stop("The derivative-corrected covariance matrix 'cov' is not ",
         "available in the object. Refit the model with ",
         "'nograd = FALSE'.")
  }
  
  # Return the results
  return (object$cov)
}

#' @title Confidence intervals for a mseldml object
#'
#' @description Confidence intervals for the point
#' estimates under the assumption that the estimator is asymptotically normal.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param parm an optional character vector of parameter names to
#' restrict the output to.
#' @param level a numeric value in range \eqn{(0, 1)} giving the confidence
#' level. Defaults to \code{0.95}.
#' @param further arguments (currently ignored).
#'
#' @return A numeric matrix with one row per parameter and two columns
#' giving the lower and upper bounds.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{coef.mseldml}}
#'
#' @export
confint.mseldml <- function(object, parm, level = 0.95, ...)
{
  # Extract the estimates and their standard errors
  est <- coef(object)
  se  <- object$se
  
  # Compute the normal quantile and the bounds
  z  <- stats::qnorm(1 - (1 - level) / 2)
  ci <- cbind(est - z * se, est + z * se)
  
  # Label the two columns with the tail probabilities
  alpha        <- (1 - level) / 2
  lo_pct       <- format(100 * alpha, trim = TRUE, scientific = FALSE)
  hi_pct       <- format(100 * (1 - alpha), trim = TRUE,
                         scientific = FALSE)
  colnames(ci) <- c(paste0(lo_pct, "%"), paste0(hi_pct, "%"))
  
  # Restrict to a subset of parameters when requested
  if (!missing(parm))
  {
    ci <- ci[parm, , drop = FALSE]
  }
  
  # Return the results
  return (ci)
}

#' @title Tidy a mseldml object
#'
#' @description Returns a broom-style data frame with one row per
#' estimate.
#'
#' @details
#' This is an S3 method for \code{generics::tidy}. To use it, ensure
#' the \pkg{generics} package is attached (or call
#' \code{generics::tidy(object)} directly).
#'
#' @param x an object of class \code{"mseldml"}.
#' @param conf.int a logical value. If \code{TRUE}, confidence bounds
#' are added.
#' @param conf.level the confidence level used when
#' \code{conf.int = TRUE}. Defaults to \code{0.95}.
#' @param further arguments (currently ignored).
#'
#' @return A data frame with columns \code{term}, \code{estimate},
#' \code{std.error}, \code{statistic}, \code{p.value}, and, when
#' \code{conf.int = TRUE}, \code{conf.low} and \code{conf.high}.
#'
#' @importFrom generics tidy
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{glance.mseldml}}
#'
#' @export
tidy.mseldml <- function(x, conf.int = FALSE, conf.level = 0.95, ...)
{
  # Extract the point estimates and standard errors
  est <- coef(x)
  se  <- x$se
  
  # Compute the z-statistics and two-sided p-values
  z <- est / se
  p <- 2 * stats::pnorm(-abs(z))
  
  # Assemble the base data frame
  out <- data.frame(term             = names(est),
                    estimate         = as.numeric(est),
                    std.error        = as.numeric(se),
                    statistic        = as.numeric(z),
                    p.value          = as.numeric(p),
                    stringsAsFactors = FALSE)
  
  # Add confidence bounds when requested
  if (conf.int)
  {
    ci            <- confint(x, level = conf.level)
    out$conf.low  <- ci[, 1]
    out$conf.high <- ci[, 2]
  }
  
  # Return the results
  return (out)
}

#' @title Glance at a mseldml object
#'
#' @description Returns a one-row summary of the model.
#'
#' @details
#' This is an S3 method for \code{generics::glance}.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param further arguments (currently ignored).
#'
#' @return A one-row data frame with columns \code{nobs},
#' \code{n_select}, \code{n_prob}, \code{cf_folds}, \code{is_nested},
#' \code{n_rep} and \code{nograd}.
#'
#' @importFrom generics glance
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{tidy.mseldml}}
#'
#' @export
glance.mseldml <- function(x, ...)
{
  # Assemble the one-row summary
  val <- data.frame(nobs      = x$dim$n,
                    n_select  = x$dim$n_Z,
                    n_prob    = x$dim$n_prob,
                    cf_folds  = length(x$ind_test),
                    is_nested = isTRUE(x$is_nested),
                    n_rep     = if (is.null(x$n_rep)) 1L else x$n_rep,
                    nograd    = isTRUE(x$nograd),
                    stringsAsFactors = FALSE)
  
  # Return the results
  return (val)
}

# ---------------------------------------------------------
# S3 methods: plot, update
# ---------------------------------------------------------

#' @title Plot a mseldml object
#'
#' @description Produces a forest plot of the ATES, ATTS, ATE, and ATT 
#' estimates with the confidence intervals, or a histogram of the estimated
#' control-function columns.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param type one of \code{"forest"} (default) or \code{"zprob"}.
#' @param conf.level the confidence level for the forest plot.
#' Defaults to \code{0.95}.
#' @param ... further arguments passed to \code{\link[graphics]{plot}}
#' (for \code{type = "forest"}) or \code{\link[graphics]{hist}} (for
#' \code{type = "zprob"}).
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @examples
#' \donttest{
#' # Fit a small model, then plot the four estimates
#' data <- data.frame(
#'   y = rnorm(200),
#'   x = rnorm(200),
#'   d = rbinom(200, size = 1, prob = 0.5)
#' )
#' model <- mseldml(data = data,
#'                  X = "x", W_Z = "x", D = "d", Y = "y",
#'                  Z = NULL)
#' plot(model, type = "forest")
#' }
#'
#' @export
plot.mseldml <- function(x, type = c("forest", "zprob"),
                         conf.level = 0.95, ...)
{
  # Match the requested plot type
  type <- match.arg(type)
  
  # Forest plot
  if (type == "forest")
  {
    # Select the family of estimates to display
    suffix    <- if (isTRUE(x$nograd)) "DML0" else "DML"
    par_order <- c("ATES", "ATTS", "ATE", "ATT")
    
    # Extract the estimates and standard errors
    est <- x$estimates[paste0(par_order, "_", suffix)]
    se  <- x$se       [paste0(par_order, "_", suffix)]
    
    # Compute the confidence bounds
    z     <- stats::qnorm(1 - (1 - conf.level) / 2)
    ci_lo <- est - z * se
    ci_hi <- est + z * se
    ylim  <- range(c(ci_lo, ci_hi, est))
    k     <- length(est)
    
    # Draw the point estimates
    graphics::plot(seq_len(k), est, xaxt = "n",
                   ylim = ylim, xlab = "",
                   ylab = "Estimate", pch = 19,
                   main = paste0("Estimates (", suffix, ")"),
                   ...)
    
    # Add the confidence intervals and the zero line
    graphics::segments(seq_len(k), ci_lo, seq_len(k), ci_hi)
    graphics::abline(h = 0, lty = 2, col = "grey50")
    
    # Label the horizontal axis with the parameter names
    graphics::axis(1, at = seq_len(k), labels = par_order)
  }
  else
  {
    # Fail early if there are no selection equations
    if (is.null(x$nuisances$Z_prob) || ncol(x$nuisances$Z_prob) == 0L)
    {
      stop("The model has no selection equations, so there is nothing to plot.")
    }
    
    # Extract the estimated probabilities and set the layout
    zp      <- x$nuisances$Z_prob
    n       <- ncol(zp)
    old_par <- graphics::par(no.readonly = TRUE)
    on.exit(graphics::par(old_par), add = TRUE)
    graphics::par(mfrow = c(1, n))
    
    # Draw one histogram per probability column
    for (j in seq_len(n))
    {
      graphics::hist(zp[, j], 
                     breaks = 30,
                     main   = paste0("Z_prob column ", j),
                     xlab   = "Estimated probabilities",
                     col    = "lightgrey", ...)
    }
  }
  
  invisible(x)
}

#' @title Update a mseldml fit
#'
#' @description Refits the model with one or more arguments replaced.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... named arguments to modify.
#' @param evaluate a logical value. If \code{TRUE} (the default) the
#' updated call is evaluated; if \code{FALSE} the call is returned
#' without evaluation.
#'
#' @return A new \code{"mseldml"} object, or a call when
#' \code{evaluate = FALSE}.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @export
update.mseldml <- function(object, ..., evaluate = TRUE)
{
  # Retrieve the matched call of the fitted model
  call <- object$call
  if (is.null(call))
  {
    stop("This mseldml object does not carry a call, so refit with the ",
         "current version of mseldml().")
  }
  
  # Extract the replacement arguments from '...'
  extras <- match.call(expand.dots = FALSE)$...
  if (length(extras) > 0)
  {
    # Replace existing arguments in place
    existing <- !is.na(match(names(extras), names(call)))
    for (a in names(extras)[existing])
    {
      call[[a]] <- extras[[a]]
    }
    
    # Append new arguments to the call
    if (any(!existing))
    {
      call <- c(as.list(call), extras[!existing])
      call <- as.call(call)
    }
  }
  
  # Evaluate the updated call in the caller's environment
  if (evaluate)
  {
    eval(call, parent.frame())
  }
  else
  {
    call
  }
}