# ---------------------------------------------------------
# Summary and print methods
# ---------------------------------------------------------

#' @title Summary for an Object of CLass mseldml
#'
#' @description Provides summary for an object of class 'mseldml'.
#'
#' @details
#' The returned object is dispatched to
#' \code{\link[sdml]{print.summary.mseldml}}, which in turn calls
#' \code{\link[sdml]{print.mseldml}}. No new information is computed.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... further arguments (currently ignored).
#'
#' @return The object, invisibly, with class
#' \code{"summary.mseldml"}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{print.mseldml}}
#'
#' @export
summary.mseldml <- function(object, ...)
{
  # Make a warning when unused arguments are passed
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through '...' are ignored.")
  }
  
  # Change the class
  class(object) <- "summary.mseldml"
  
  # Return the results
  return (object)
}

#' @title Build the table of estimates to print
#'
#' @description Assembles the four causal estimates of a given suffix
#' (either \code{"DML"} or \code{"DML0"}) into a matrix with the
#' columns required by \code{\link[stats]{printCoefmat}}.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param suffix a character string, either \code{"DML"} or
#' \code{"DML0"}.
#'
#' @return A \eqn{4 \times 4} numeric matrix with columns
#' \code{Estimate}, \code{Std_Error}, \code{z_value} and \code{p_value},
#' and rows ordered \code{ATES}, \code{ATTS}, \code{ATE}, \code{ATT}.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_build_table <- function(x, suffix)
{
  # Names of estimates
  tr_names  <- c("ATES", "ATTS", "ATE", "ATT")
  est_names <- paste0(tr_names, "_", suffix)
  
  # Extract estimates and standard errors
  est <- x$estimates[est_names]
  se  <- x$se[est_names]
  
  # Compute the z-statistics and two-sided p-values
  z <- est / se
  p <- 2 * pnorm(-abs(z))
  
  # Assemble and label the table
  tbl           <- cbind(est, se, z, p)
  colnames(tbl) <- c("Estimate", "Std_Error", "z_value", "p_value")
  rownames(tbl) <- tr_names
  return (tbl)
}

#' @title Print the header of a mseldml object
#'
#' @description Prints the header of the summary output: the model
#' type, the number of observations, the number of selection equations
#' and the cross-fitting configuration.
#'
#' @param x an object of class \code{"mseldml"}.
#'
#' @return The function returns \code{x}.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_print_header <- function(x)
{
  # Model type and separator
  cat(paste0("DML model with",
             ifelse(x$is_Z, " sample selection", ""),
             "\n"))
  cat("--- \n")
  
  # Information
  cat(paste0("Observations = ",        x$dim$n,      "\n"))
  cat(paste0("Selection equations = ", x$dim$n_Z,    "\n"))
  cat(paste0("Probabilities = ",       x$dim$n_prob, "\n"))
  
  # Cross-fitting configuration
  cat(paste0("Cross-fitting: ",
             ifelse(isTRUE(x$is_nested), "nested", "non-nested"),
             ", ", length(x$ind_test), " folds",
             "\n"))
  
  return (invisible(x))
}

#' @title Print the diagnostics block of a mseldml object
#'
#' @description Prints selection and treatment rates, ranges of the
#' estimated control functions, and trimming counts.
#'
#' @param x an object of class \code{"mseldml"}.
#'
#' @return The function returns \code{x}.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_print_diagnostics <- function(x)
{
  # Skip silently if diagnostics were not stored
  dg <- x$diagnostics
  if (is.null(dg))
  {
    return (invisible(x))
  }
  
  # Section header
  cat("--- \n")
  cat("Diagnostics\n")
  
  # Selection and treatment rates
  cat(sprintf("%-42s = %s\n", "Selection rate P(Z_tilde = 1)",
              formatC(dg$P_Z, digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d1)",
              formatC(dg$P_D1, digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d0 | Z_tilde = 1)",
              formatC(dg$P_D0Z / max(dg$P_Z, 1e-12),
                      digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d1 | Z_tilde = 1)",
              formatC(dg$P_D1Z / max(dg$P_Z, 1e-12),
                      digits = 3, format = "f")))
  
  # Ranges of the estimated control functions
  cat(sprintf("%-42s = [%s, %s]\n", "Range of P_i^(d)",
              formatC(dg$D1_range[1], digits = 3, format = "f"),
              formatC(dg$D1_range[2], digits = 3, format = "f")))
  cat(sprintf("%-42s = [%s, %s]\n", "Range of P_i^(d*)",
              formatC(dg$D0_range[1], digits = 3, format = "f"),
              formatC(dg$D0_range[2], digits = 3, format = "f")))
  cat(sprintf("%-42s = [%s, %s]\n", "Range of tilde_P_i",
              formatC(dg$Z_joint_prob_range[1], digits = 3, format = "f"),
              formatC(dg$Z_joint_prob_range[2], digits = 3, format = "f")))
  
  # Counts of low-propensity observations
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P_i^(d) < 0.05",
              dg$D1_below_05,
              100 * dg$D1_below_05 / x$dim$n))
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P_i^(d*) < 0.05",
              dg$D0_below_05,
              100 * dg$D0_below_05 / x$dim$n))
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with tilde_P_i < 0.05",
              dg$Z_joint_prob_below_05,
              100 * dg$Z_joint_prob_below_05 / x$dim$n))
  
  # Trimming count
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs trimmed",
              dg$n_trimmed,
              100 * dg$n_trimmed / x$dim$n))
  
  # Monotonicity repairs, printed only when non-zero
  if (!is.null(dg$n_projected) && dg$n_projected > 0)
  {
    cat(sprintf("%-42s = %d\n",
                "Monotonicity repairs applied",
                dg$n_projected))
  }
  
  return (invisible(x))
}

#' @title Print the overlap-quantile block
#'
#' @description Prints quantiles of the estimated control-function
#' probabilities and of the products that appear in the 
#' scores, computed on the retained observations.
#'
#' @param dg the diagnostics list stored in a \code{"mseldml"} object.
#' @param retained_n the number of retained observations.
#'
#' @return The function returns \code{NULL}, invisibly.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_print_quantiles <- function(dg, retained_n)
{
  # Skip silently when the quantile block was not stored
  if (is.null(dg$probs_lower) || is.null(dg$D1_quantiles_lower) ||
      is.null(retained_n)     || (length(retained_n) != 1L)     ||
      !is.finite(retained_n)  || (retained_n <= 0L))
  {
    return (invisible(NULL))
  }
  
  col_w   <- 8L
  label_w <- 26L
  
  # Helper: one quantile table with the given label and rows
  print_block <- function(title, probs, rows)
  {
    cat("--- \n")
    cat(title, "\n", sep = "")
    
    # Header row of quantile labels
    cat(sprintf("%-*s", label_w, ""))
    for (q in probs)
    {
      cat(sprintf("%*s", col_w,
                  paste0(format(100 * q, trim = TRUE), "%")))
    }
    cat("\n")
    
    # One line per probability set
    for (row in rows)
    {
      cat(sprintf("%-*s", label_w, row$label))
      for (v in row$values)
      {
        cat(sprintf("%*s", col_w,
                    formatC(v, digits = 3, format = "f")))
      }
      cat("\n")
    }
  }
  
  # Lower-tail block: quantiles and the counts of tiny products
  print_block(
    title = "Overlap diagnostics: lower tail (retained observations)",
    probs = dg$probs_lower,
    rows  = list(
      list(label  = "P(D = d1)",
           values = dg$D1_quantiles_lower),
      list(label  = "P(D = d0)",
           values = dg$D0_quantiles_lower),
      list(label  = "P(Z_tilde = 1)",
           values = dg$Z_joint_quantiles_lower),
      list(label  = "P(D=d1) * P(Z_tilde=1)",
           values = dg$D1Z_quantiles_lower),
      list(label  = "P(D=d0) * P(Z_tilde=1)",
           values = dg$D0Z_quantiles_lower)
    )
  )
  
  # Counts of tiny products that drive the ATE-family denominators
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P(D=d1) * P(Z_tilde=1) < 0.01",
              dg$D1Z_below_01,
              100 * dg$D1Z_below_01 / retained_n))
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P(D=d0) * P(Z_tilde=1) < 0.01",
              dg$D0Z_below_01,
              100 * dg$D0Z_below_01 / retained_n))
  
  # Upper-tail block
  print_block(
    title = "Overlap diagnostics: upper tail (retained observations)",
    probs = dg$probs_upper,
    rows  = list(
      list(label  = "P(D = d1)",
           values = dg$D1_quantiles_upper),
      list(label  = "P(D = d0)",
           values = dg$D0_quantiles_upper),
      list(label  = "P(Z_tilde = 1)",
           values = dg$Z_joint_quantiles_upper),
      list(label  = "P(D=d1) * P(Z_tilde=1)",
           values = dg$D1Z_quantiles_upper),
      list(label  = "P(D=d0) * P(Z_tilde=1)",
           values = dg$D0Z_quantiles_upper)
    )
  )
  
  return (invisible(NULL))
}

#' @title Print a mseldml object
#'
#' @description Prints summary for an object of class 'mseldml'.
#'
#' @details
#' 
#' If \code{nograd = FALSE}, then two tables are printed: the first with the
#' derivative-corrected estimates, the second with the derivative-free
#' ones. If \code{nograd = TRUE}, then only a single table is printed.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param diagnostics a logical value. If \code{TRUE} (the default), then a
#' diagnostic block is printed after the estimate tables.
#' @param ... further arguments. Currently ignored.
#'
#' @return The function returns \code{x}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{summary.mseldml}}
#'
#' @export
print.mseldml <- function(x, diagnostics = TRUE, ...)
{
  # Print the header
  .mseldml_print_header(x)
  
  # Check whether the gradient based estimator is used
  nograd <- isTRUE(x$nograd)
  
  if (!nograd)
  {
    # Build the two estimate tables
    tbl_DML  <- .mseldml_build_table(x, "DML")
    tbl_DML0 <- .mseldml_build_table(x, "DML0")
    
    # Print the derivative-corrected estimates
    cat("--- \n")
    cat("Estimates with derivative terms\n")
    printCoefmat(tbl_DML,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
    
    # Print the derivative-free estimates
    cat("--- \n")
    cat("Estimates without derivative terms\n")
    printCoefmat(tbl_DML0,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
  }
  else
  {
    # Build the single estimate table
    tbl_DML0 <- .mseldml_build_table(x, "DML0")
    
    # Print the estimates
    cat("--- \n")
    cat("Estimates\n")
    printCoefmat(tbl_DML0,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
  }
  
  # Print diagnostics unless disabled
  if (isTRUE(diagnostics))
  {
    .mseldml_print_diagnostics(x)
    .mseldml_print_quantiles(x$diagnostics, x$diagnostics$n_retained)
  }
  
  # Print the significance legend when the option is set
  if (getOption("show.signif.stars"))
  {
    cat("--- \n")
    cat("Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 \n")
  }
  
  # Return the results
  return (invisible(x))
}

#' @title Print a summary.mseldml object
#'
#' @description Delegates to \code{\link[sdml]{print.mseldml}}.
#'
#' @param x an object of class \code{"summary.mseldml"}.
#' @param ... further arguments passed to
#' \code{\link[sdml]{print.mseldml}}.
#'
#' @return The function returns \code{x}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{print.mseldml}}
#'
#' @export
print.summary.mseldml <- function(x, ...)
{
  print.mseldml(x, ...)
}