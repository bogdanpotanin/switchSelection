# ---------------------------------------------------------
# Summary and print methods
# ---------------------------------------------------------

#' @title Summarize a mseldml object
#'
#' @description Replaces the class of \code{object} with
#' \code{"summary.mseldml"} and returns it.
#'
#' @details
#' The returned object is dispatched to
#' \code{\link[sdml]{print.summary.mseldml}}, which in turn calls
#' \code{\link[sdml]{print.mseldml}}. No new information is computed.
#'
#' @param object an object of class \code{"mseldml"}.
#' @param ... further arguments. Currently ignored.
#'
#' @return The object, invisibly, with class
#' \code{"summary.mseldml"}.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{print.mseldml}}
#'
#' @export
summary.mseldml <- function(object, ...)
{
  # Warn when unused arguments are passed
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through '...' are ignored.")
  }
  
  # Reclass and return the object
  class(object) <- "summary.mseldml"
  return(object)
}

#' @title Build the estimate table for printing
#'
#' @description Assembles the four causal estimates of a given suffix
#' (either \code{"DML"} or \code{"DML0"}) into a matrix with the
#' columns required by \code{\link[stats]{printCoefmat}}.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param suffix a character string, either \code{"DML"} or
#' \code{"DML0"}.
#'
#' @return A \eqn{4 \times 4} numeric matrix with columns
#' \code{Estimate}, \code{Std_Error}, \code{z_value} and \code{p_value},
#' and rows ordered \code{ATES}, \code{ATTS}, \code{ATE}, \code{ATT}.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_build_table <- function(x, suffix)
{
  # Rows in the order produced by mseldml()
  tr_names  <- c("ATES", "ATTS", "ATE", "ATT")
  est_names <- paste0(tr_names, "_", suffix)
  
  # Extract estimates and standard errors
  est <- x$estimates[est_names]
  se  <- x$se[est_names]
  
  # Compute the z-statistics and two-sided p-values
  z <- est / se
  p <- 2 * stats::pnorm(-abs(z))
  
  # Assemble and label the table
  tbl           <- cbind(est, se, z, p)
  colnames(tbl) <- c("Estimate", "Std_Error", "z_value", "p_value")
  rownames(tbl) <- tr_names
  return(tbl)
}

#' @title Print the header of a mseldml object
#'
#' @description Prints the header of the summary output: the model
#' type, the number of observations, the number of selection equations
#' and the cross-fitting configuration.
#'
#' @param x an object of class \code{"mseldml"}.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_print_header <- function(x)
{
  # Model type and separator
  cat(paste0("DML model with",
             ifelse(x$is_Z, " sample selection", ""),
             "\n"))
  cat("--- \n")
  
  # Dimensions
  cat(paste0("Observations = ",        x$dim$n,      "\n"))
  cat(paste0("Selection equations = ", x$dim$n_Z,    "\n"))
  cat(paste0("Probabilities = ",       x$dim$n_prob, "\n"))
  
  # Cross-fitting configuration
  cat(paste0("Cross-fitting: ",
             ifelse(isTRUE(x$is_nested), "nested", "non-nested"),
             "\n"))
  
  # Number of repetitions when greater than one
  if (!is.null(x$n_rep) && x$n_rep > 1)
  {
    cat(paste0("Cross-fitting repetitions = ", x$n_rep,
               " (median method, Chernozhukov et al. 2018, Cor. 3.3)\n"))
  }
  
  return(invisible(x))
}

#' @title Print the diagnostics block of a mseldml object
#'
#' @description Prints selection and treatment rates, ranges of the
#' estimated control functions, and trimming counts.
#'
#' @param x an object of class \code{"mseldml"}.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{print.mseldml}}
#'
#' @keywords internal
.mseldml_print_diagnostics <- function(x)
{
  # Skip silently if diagnostics were not stored
  dg <- x$diagnostics
  if (is.null(dg))
  {
    return(invisible(x))
  }
  
  # Section header
  cat("--- \n")
  cat("Diagnostics\n")
  
  # Selection and treatment rates
  cat(sprintf("%-42s = %s\n", "Selection rate P(Z_tilde = 1)",
              formatC(dg$P_Z, digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d1)",
              formatC(dg$P_D1, digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d0 | Z_tilde = 1)",
              formatC(dg$P_D0Z / max(dg$P_Z, 1e-12),
                      digits = 3, format = "f")))
  cat(sprintf("%-42s = %s\n", "P(D = d1 | Z_tilde = 1)",
              formatC(dg$P_D1Z / max(dg$P_Z, 1e-12),
                      digits = 3, format = "f")))
  
  # Ranges of the estimated control functions
  cat(sprintf("%-42s = [%s, %s]\n", "Range of P_i^(d)",
              formatC(dg$D1_range[1], digits = 3, format = "f"),
              formatC(dg$D1_range[2], digits = 3, format = "f")))
  cat(sprintf("%-42s = [%s, %s]\n", "Range of P_i^(d*)",
              formatC(dg$D0_range[1], digits = 3, format = "f"),
              formatC(dg$D0_range[2], digits = 3, format = "f")))
  cat(sprintf("%-42s = [%s, %s]\n", "Range of tilde_P_i",
              formatC(dg$tildeP_range[1], digits = 3, format = "f"),
              formatC(dg$tildeP_range[2], digits = 3, format = "f")))
  
  # Counts of low-propensity observations
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P_i^(d) < 0.05",
              dg$D1_below_05,
              100 * dg$D1_below_05 / x$dim$n))
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with P_i^(d*) < 0.05",
              dg$D0_below_05,
              100 * dg$D0_below_05 / x$dim$n))
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs with tilde_P_i < 0.05",
              dg$tildeP_below_05,
              100 * dg$tildeP_below_05 / x$dim$n))
  
  # Trimming count
  cat(sprintf("%-42s = %d (%.1f%%)\n",
              "Obs trimmed",
              dg$n_trimmed,
              100 * dg$n_trimmed / x$dim$n))
  
  # Monotonicity repairs, printed only when non-zero
  if (!is.null(dg$n_projected) && dg$n_projected > 0)
  {
    cat(sprintf("%-42s = %d\n",
                "Monotonicity repairs applied",
                dg$n_projected))
  }
  
  return(invisible(x))
}

#' @title Print a mseldml object
#'
#' @description Displays the fitted estimates of the four causal
#' parameters together with their standard errors, z-statistics and
#' p-values, followed by a short diagnostic block.
#'
#' @details
#' If \code{nograd = FALSE}, two tables are printed: the first with the
#' derivative-corrected estimates, the second with the derivative-free
#' ones. If \code{nograd = TRUE}, only a single table is printed.
#'
#' @param x an object of class \code{"mseldml"}.
#' @param diagnostics a logical value. If \code{TRUE} (the default), a
#' diagnostic block is printed after the estimate tables.
#' @param ... further arguments. Currently ignored.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{summary.mseldml}}
#'
#' @export
print.mseldml <- function(x, diagnostics = TRUE, ...)
{
  # Print the header
  .mseldml_print_header(x)
  
  # Decide which tables to print
  nograd <- isTRUE(x$nograd)
  
  if (!nograd)
  {
    # Build the two estimate tables
    tbl_DML  <- .mseldml_build_table(x, "DML")
    tbl_DML0 <- .mseldml_build_table(x, "DML0")
    
    # Print the derivative-corrected estimates
    cat("--- \n")
    cat("Estimates with derivative terms\n")
    printCoefmat(tbl_DML,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
    
    # Print the derivative-free estimates
    cat("--- \n")
    cat("Estimates without derivative terms\n")
    printCoefmat(tbl_DML0,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
  }
  else
  {
    # Build the single estimate table
    tbl_DML0 <- .mseldml_build_table(x, "DML0")
    
    # Print the estimates
    cat("--- \n")
    cat("Estimates\n")
    printCoefmat(tbl_DML0,
                 has.Pvalue    = TRUE,
                 signif.legend = FALSE,
                 P.values      = TRUE)
  }
  
  # Print diagnostics unless disabled
  if (isTRUE(diagnostics))
  {
    .mseldml_print_diagnostics(x)
  }
  
  # Print the significance legend when the option is set
  if (getOption("show.signif.stars"))
  {
    cat("--- \n")
    cat("Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 \n")
  }
  
  return(invisible(x))
}

#' @title Print a summary.mseldml object
#'
#' @description Delegates to \code{\link[sdml]{print.mseldml}}.
#'
#' @param x an object of class \code{"summary.mseldml"}.
#' @param ... further arguments passed to
#' \code{\link[sdml]{print.mseldml}}.
#'
#' @return The object, invisibly.
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{print.mseldml}}
#'
#' @export
print.summary.mseldml <- function(x, ...)
{
  print.mseldml(x, ...)
}