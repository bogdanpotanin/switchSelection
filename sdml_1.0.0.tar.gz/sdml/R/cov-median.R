# ---------------------------------------------------------
# Matrix median (operator-norm) used by the repeated-split
# covariance aggregation
# ---------------------------------------------------------

#' @title Select the matrix with the median operator norm
#'
#' @description Implements the median matrix method of Chernozhukov et
#' al. (2018), Definition 3.3. Given a list of symmetric covariance
#' matrices, the function selects the matrix whose operator norm is
#' closest to the median rank of the operator norms and returns it
#' after symmetrisation.
#'
#' @details
#' Taking the median element by element across a list of positive
#' semidefinite matrices does not, in general, yield a positive
#' semidefinite matrix. The operator-norm median is guaranteed to be one
#' of the input matrices (up to symmetrisation) and therefore preserves
#' positive semidefiniteness. For a symmetric matrix, the operator norm
#' is the maximum of the absolute values of its eigenvalues.
#'
#' When the number of matrices is even, the two middle ranks are equally
#' legitimate medians. The function uses the lower of the two middle
#' ranks, which makes the selection invariant to the order of
#' \code{cov_list}. The naive rule based on the arithmetic median is
#' order-dependent whenever the two middle matrices are equidistant
#' from that median.
#'
#' @param cov_list a list of symmetric square numeric matrices.
#'
#' @return A symmetric square numeric matrix.
#'
#' @references
#' V. Chernozhukov, D. Chetverikov, M. Demirer, E. Duflo, C. Hansen,
#' W. Newey, J. Robins (2018). Double/debiased machine learning for
#' treatment and structural parameters. The Econometrics Journal,
#' vol. 21(1), pages C1-C68.
#'
#' @seealso \code{\link[sdml]{mseldml}}
#'
#' @examples
#' # Three symmetric covariance matrices with different operator norms
#' A <- matrix(c(1, 0.2, 0.2, 1), nrow = 2)
#' B <- matrix(c(2, 0.5, 0.5, 2), nrow = 2)
#' C <- matrix(c(3, 0.1, 0.1, 3), nrow = 2)
#'
#' # Select the matrix with the median operator norm
#' cov_median(list(A, B, C))
#'
#' # The selection is invariant to the order of the input
#' isTRUE(all.equal(cov_median(list(A, B, C)),
#'                  cov_median(list(C, A, B))))
#'
#' # A single matrix is returned after symmetrisation
#' cov_median(list(A))
#'
#' @export
cov_median <- function(cov_list)
{
  # Validate the length of 'cov_list'
  if (length(cov_list) == 0L)
  {
    stop("The argument 'cov_list' must contain at least one matrix.")
  }
  
  # Check for missing entries in 'cov_list'
  if (any(vapply(cov_list, is.null, logical(1L))))
  {
    stop("All split covariance matrices must be available.")
  }
  
  # Validate that all matrices are finite, square, symmetric, have the
  # same dimensions, and are positive semidefinite covariance matrices
  expected_dim <- NULL
  for (i in seq_along(cov_list))
  {
    S <- cov_list[[i]]
    
    if (!is.matrix(S)        || !is.numeric(S) || 
        (nrow(S) != ncol(S)) || any(!is.finite(S)))
    {
      stop("Each element of 'cov_list' must be a finite square numeric ",
           "matrix.")
    }
    
    if (is.null(expected_dim))
    {
      expected_dim <- dim(S)
    }
    else if (!identical(dim(S), expected_dim))
    {
      stop("All matrices in 'cov_list' must have identical dimensions.")
    }
    
    if (!isSymmetric(S, tol = 1e-8))
    {
      stop("Each element of 'cov_list' must be symmetric.")
    }
    
    S_sym   <- (S + t(S)) / 2
    ev      <- eigen(S_sym, symmetric = TRUE, only.values = TRUE)$values
    psd_tol <- 1e-10 * max(1, max(abs(ev)))
    if (min(ev) < -psd_tol)
    {
      stop("Each element of 'cov_list' must be positive semidefinite.")
    }
    
    cov_list[[i]] <- S_sym
  }
  
  # Compute the operator norm of each matrix
  op_norm <- vapply(cov_list, function(S)
                              {
                                S  <- (S + t(S)) / 2
                                ev <- eigen(S, symmetric = TRUE, 
                                            only.values = TRUE)$values
                                max(abs(ev))
                              }, 
                    numeric(1L))
  
  # Stable deterministic tie-break by the symmetrised matrix entries
  matrix_key <- vapply(cov_list, function(S)
  {
    S <- (S + t(S)) / 2
    paste(sprintf("%.17g", as.vector(S)), collapse = ",")
  }, character(1L))
  ord <- order(op_norm, matrix_key, method = "radix")
  idx <- ord[ceiling(length(ord) / 2L)]
  S   <- cov_list[[idx]]
  
  # Return the results
  return ((S + t(S)) / 2)
}