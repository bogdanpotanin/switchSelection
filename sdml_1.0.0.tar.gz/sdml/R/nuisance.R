# ---------------------------------------------------------
# Learning and predicting nuisance functions
# ---------------------------------------------------------

#' @title Fit and predict a nuisance function
#'
#' @description Fits a learner on a training sample and returns
#' predictions on a test sample. Optionally also returns numeric
#' derivatives of the prediction with respect to one or more regressor
#' columns.
#'
#' @details
#' This function is used internally by
#' \code{\link[sdml]{mseldml}} to fit each nuisance function
#' through a consistent two-stage interface.
#'
#' \strong{Workflow}
#'
#' \enumerate{
#' \item The learner is fitted on \code{x[ind_train, ]} after applying
#'   \code{data_transform}.
#' \item Predictions are produced on \code{x[ind_test, ]}. If
#'   \code{D_values} is supplied, predictions are repeated with the
#'   treatment column replaced by each value of \code{D_values} in turn,
#'   yielding a matrix with one column per treatment value.
#' \item If \code{ind_grad} is not \code{NULL}, numeric central
#'   differences of the prediction with respect to each listed column
#'   are computed.
#' }
#'
#' \strong{Numeric derivatives}
#'
#' When \code{ind_grad} is supplied, the derivative of the prediction
#' with respect to each listed column of \code{x} is approximated by a
#' central finite difference: the prediction is evaluated at
#' \eqn{p + \epsilon} and \eqn{p - \epsilon} for a small step
#' \eqn{\epsilon}, and the two values are differenced and divided by
#' the effective step. The result has the same shape as \code{pred}:
#' a matrix of \eqn{n_{\mathrm{test}} \times n_{\mathrm{grad}}} when
#' \code{D_values} is \code{NULL}, and a
#' \eqn{n_{\mathrm{test}} \times n_{\mathrm{grad}} \times n_{\mathrm{predict}}}
#' array otherwise.
#'
#' Because tree-based learners produce piecewise-constant predictions,
#' their numeric derivatives are zero almost everywhere. Smooth
#' learners (for example, lasso or linear regression) are required if
#' the derivative output is to be meaningful.
#'
#' @template template_x_ind_vars
#' @template template_y_d0_d1
#' @param learner a function that fits a model on a training sample.
#' May be set to any of the learners provided by the package, such as
#' \code{\link[sdml]{learner_glmnet}} (the default) or
#' \code{\link[sdml]{learner_ranger}}, or to a user-supplied function
#' with the same interface.
#' @param predictor a function that produces predictions from the
#' fitted model returned by \code{learner}. It must match the chosen
#' learner: \code{\link[sdml]{predictor_glmnet}} (the default) pairs
#' with \code{learner_glmnet}, and
#' \code{\link[sdml]{predictor_ranger}} pairs with
#' \code{learner_ranger}.
#' @param data_transform a function applied to \code{x} before fitting
#' and prediction. The default is
#' \code{\link[sdml]{data_transform_default}}, which appends polynomial
#' columns to selected blocks of \code{x}; a user-supplied function
#' with the same interface may be used instead.
#' @param control_learner a list of additional arguments passed to
#' \code{learner}.
#' @param control_predictor a list of additional arguments passed to
#' \code{predictor}.
#' @param control_transform a list of additional arguments passed to
#' \code{data_transform}.
#' @param ind_train an integer vector of training indices.
#' @param ind_test an integer vector of test indices.
#' @param ind_grad an integer vector of columns of \code{x} for which
#' numeric derivatives are required. If \code{NULL}, no derivatives are
#' computed.
#' @param D_values a numeric vector of treatment values at which to
#' predict. If \code{NULL}, only the observed treatment values are used.
#'
#' @return A list with slots:
#' \itemize{
#' \item \code{pred} --- predictions on the test sample (a vector when
#'   \code{D_values} is a single value or \code{NULL}, and a matrix
#'   otherwise);
#' \item \code{grad} --- an array of numeric derivatives (only if
#'   \code{ind_grad} is non-empty).
#' }
#'
#' @seealso \code{\link[sdml]{mseldml}},
#' \code{\link[sdml]{learner_glmnet}},
#' \code{\link[sdml]{predictor_glmnet}}
#'
#' @examples
#' # Simulate a small data set with covariates X, treatment D,
#' # and two probability columns P1 and P2
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n),
#'             D  = rbinom(n, size = 1, prob = 0.5),
#'             P1 = runif(n), P2 = runif(n))
#' y  <- 1 + 2 * x[, "D"] + x[, "X1"] - x[, "X2"] + rnorm(n)
#'
#' # Map block labels to the columns of 'x'
#' ind_vars <- list(X = c(1, 2), D = 3, P = c(4, 5))
#'
#' # Split into training and test subsets
#' ind_train <- 1:70
#' ind_test  <- 71:100
#'
#' # Basic prediction for the observed treatment values
#' fit <- nuisance(x = x, y = y, ind_vars = ind_vars,
#'                 ind_train = ind_train, ind_test = ind_test)
#' head(fit$pred)
#'
#' # Predictions for both treatment levels
#' fit_two <- nuisance(x = x, y = y, ind_vars = ind_vars,
#'                     ind_train = ind_train, ind_test = ind_test,
#'                     D_values = c(0, 1))
#' dim(fit_two$pred)
#' head(fit_two$pred)
#'
#' # Derivatives with respect to the probability columns P1 and P2
#' fit_grad <- nuisance(x = x, y = y, ind_vars = ind_vars,
#'                      ind_train = ind_train, ind_test = ind_test,
#'                      ind_grad = c(4, 5))
#' dim(fit_grad$grad)
#' head(fit_grad$grad)
#'
#' # Derivatives combined with two-value prediction:
#' # the gradient becomes a 3-dimensional array
#' fit_both <- nuisance(x = x, y = y, ind_vars = ind_vars,
#'                      ind_train = ind_train, ind_test = ind_test,
#'                      D_values = c(0, 1), ind_grad = c(4, 5))
#' dim(fit_both$grad)
#'
#' # Tree-based learners return zero derivatives because their
#' # predictions are piecewise constant; the call must still complete
#' fit_ranger <- nuisance(x = x, y = y, ind_vars = ind_vars,
#'                        ind_train = ind_train, ind_test = ind_test,
#'                        ind_grad = c(4, 5),
#'                        learner   = learner_ranger,
#'                        predictor = predictor_ranger)
#' dim(fit_ranger$grad)
#' max(abs(fit_ranger$grad))
#' 
#' @export
nuisance <- function(x, y,
                     learner           = learner_glmnet,
                     predictor         = predictor_glmnet,
                     data_transform    = data_transform_default,
                     control_learner   = list(),
                     control_predictor = list(),
                     control_transform = list(),
                     ind_train         = NULL,
                     ind_test          = NULL,
                     ind_vars          = NULL,
                     ind_grad          = NULL,
                     D_values          = NULL,
                     d0                = 0,
                     d1                = 1)
{
  # Initialize the output container
  out <- vector(mode = "list", length = 0)
  
  # Get the number of observations
  n <- length(y)
  
  # Default to the full sample when indices are not provided
  if (all(is.null(ind_train)))
  {
    ind_train <- 1:n
  }
  if (all(is.null(ind_test)))
  {
    ind_test <- ind_train
  }
  
  # Extract the training and test subsets
  n_test  <- length(ind_test)
  x_train <- x[ind_train, , drop = FALSE]
  y_train <- y[ind_train]
  x_test  <- x[ind_test, , drop = FALSE]
  
  # Drop training rows with missing values
  NA_train <- !complete.cases(x_train) | is.na(y_train)
  x_train  <- x_train[!NA_train, , drop = FALSE]
  y_train  <- y_train[!NA_train]
  if (length(y_train) == 0L)
  {
    stop("The training sample contains no complete observations after ",
         "removing rows with missing values.")
  }
  
  # Apply the transformation to the training sample
  x_train_transform <- x_train
  if (!is.null(data_transform))
  {
    args_transform    <- modifyList(control_transform,
                                    list(x        = x_train,
                                         ind_vars = ind_vars))
    args_transform    <- as.list(args_transform)
    x_train_transform <- do.call(what = data_transform, args = args_transform)
    if ((ncol(x_train_transform) < ncol(x_train)) ||
        !identical(colnames(x_train_transform)[seq_len(ncol(x_train))],
                   colnames(x_train)))
    {
      stop("The data transform must preserve the original columns of 'x' ",
           "at their original positions. New columns may be appended.")
    }
  }
  
  # Fit the learner on the transformed training sample
  args_learner <- modifyList(control_learner,
                             list(x        = x_train_transform,
                                  y        = y_train,
                                  ind_vars = ind_vars,
                                  d0       = d0,
                                  d1       = d1))
  args_learner <- as.list(args_learner)
  model        <- do.call(what = learner, args = args_learner)
  
  # Look up the treatment column if present in 'ind_vars'
  ind_D <- NULL
  if (!is.null(ind_vars) && hasName(x = ind_vars, name = "D"))
  {
    ind_D <- ind_vars[["D"]]
  }
  
  # Get the number of treatment values to predict for
  n_predict <- 1
  if (!is.null(D_values))
  {
    n_predict <- length(D_values)
  }
  
  # Allocate the matrix of predictions
  predict_matrix <- matrix(NA_real_, nrow = n_test, ncol = n_predict)
  
  # Produce one column of predictions per treatment value
  x_test_d <- x_test
  for (i in seq_len(n_predict))
  {
    # Substitute the treatment value into the test sample
    if (!is.null(D_values) && !is.null(ind_D))
    {
      x_test_d[, ind_D] <- D_values[i]
    }
    
    # Apply the transformation to the test sample
    x_test_d_transform <- x_test_d
    if (!is.null(data_transform))
    {
      args_transform     <- modifyList(control_transform,
                                       list(x        = x_test_d,
                                            ind_vars = ind_vars))
      args_transform     <- as.list(args_transform)
      x_test_d_transform <- do.call(what = data_transform, args = args_transform)
    }
    
    # Produce predictions with the fitted model
    args_predictor      <- modifyList(control_predictor,
                                      list(x        = x_test_d_transform,
                                           ind_vars = ind_vars,
                                           model    = model,
                                           d0       = d0,
                                           d1       = d1))
    args_predictor      <- as.list(args_predictor)
    pred_i              <- do.call(what = predictor, args = args_predictor)
    if (!is.numeric(pred_i) || !is.null(dim(pred_i)) ||
        length(pred_i) != n_test)
    {
      stop("The predictor must return a numeric vector of length ",
           n_test, " (the number of test observations).")
    }
    if (any(!is.finite(pred_i)))
    {
      stop("The predictor returned non-finite values.")
    }
    predict_matrix[, i] <- as.numeric(pred_i)
  }
  
  # Clear the temporary test matrix
  x_test_d <- NULL
  
  # Collect predictions into the output
  if (n_predict == 1)
  {
    out$pred <- predict_matrix[, 1]
  }
  else
  {
    out$pred <- predict_matrix
  }
  
  # Compute numeric derivatives if requested
  if (!is.null(ind_grad) & (length(ind_grad) > 0))
  {
    # Get the number of columns to differentiate
    n_grad <- length(ind_grad)
    
    # Allocate the gradient array
    grad <- array(NA_real_, dim = c(n_test, n_grad, n_predict))
    
    # Set the perturbation size per observation and per column
    eps <- 1e-5 * (abs(x_test[, ind_grad, drop = FALSE]) + 1)
    
    x_test_d <- x_test
    for (i in seq_len(n_predict))
    {
      # Substitute the treatment value into the test sample
      if (!is.null(D_values) & !is.null(ind_D))
      {
        x_test_d[, ind_D] <- D_values[i]
      }
      
      # Compute a central difference for each requested column
      for (j in seq_len(n_grad))
      {
        # Increment and decrement the column
        p       <- x_test[, ind_grad[j]]
        p_plus  <- p + eps[, j]
        p_minus <- p - eps[, j]
        denom   <- p_plus - p_minus
        
        # Predict at the upward perturbation
        x_test_d[, ind_grad[j]] <- p_plus
        x_test_d_transform <- x_test_d
        if (!is.null(data_transform))
        {
          args_transform     <- modifyList(control_transform,
                                           list(x        = x_test_d,
                                                ind_vars = ind_vars))
          args_transform     <- as.list(args_transform)
          x_test_d_transform <- do.call(what = data_transform,
                                        args = args_transform)
        }
        args_predictor <- modifyList(control_predictor,
                                     list(model    = model,
                                          x        = x_test_d_transform,
                                          ind_vars = ind_vars,
                                          d0       = d0,
                                          d1       = d1))
        args_predictor <- as.list(args_predictor)
        predict_plus   <- do.call(what = predictor, args = args_predictor)
        
        # Validate the inrcremented predictions
        if (!is.numeric(predict_plus) || !is.null(dim(predict_plus)) ||
            (length(predict_plus) != n_test))
        {
          stop("The predictor must return a numeric vector of length ", n_test,
               " (the number of test observations).")
        }
        if (any(!is.finite(predict_plus)))
        {
          stop("The predictor returned non-finite values.")
        }
        
        # Predict at the downward perturbation
        x_test_d[, ind_grad[j]] <- p_minus
        x_test_d_transform <- x_test_d
        if (!is.null(data_transform))
        {
          args_transform     <- modifyList(control_transform,
                                           list(x        = x_test_d,
                                                ind_vars = ind_vars))
          args_transform     <- as.list(args_transform)
          x_test_d_transform <- do.call(what = data_transform,
                                        args = args_transform)
        }
        args_predictor <- modifyList(control_predictor,
                                     list(model    = model,
                                          x        = x_test_d_transform,
                                          ind_vars = ind_vars,
                                          d0       = d0,
                                          d1       = d1))
        args_predictor <- as.list(args_predictor)
        predict_minus  <- do.call(what = predictor, args = args_predictor)
        
        # Validate the decremented predictions
        if (!is.numeric(predict_minus) || !is.null(dim(predict_minus)) ||
            (length(predict_minus) != n_test))
        {
          stop("The predictor must return a numeric vector of length ", n_test,
               " (the number of test observations).")
        }
        if (any(!is.finite(predict_minus)))
        {
          stop("The predictor returned non-finite values.")
        }
        
        # Central difference
        grad[, j, i] <- (predict_plus - predict_minus) / denom
        
        # Restore the unperturbed column
        x_test_d[, ind_grad[j]] <- p
      }
    }
    
    # Collect gradients into the output
    if (n_predict == 1)
    {
      out$grad <- matrix(grad[, , 1], nrow = n_test, ncol = n_grad)
    }
    else
    {
      out$grad <- grad
    }
  }
  
  return (out)
}