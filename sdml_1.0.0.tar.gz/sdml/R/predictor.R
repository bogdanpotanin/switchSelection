# ---------------------------------------------------------
# Implementations of the predictors
# ---------------------------------------------------------

#' @title Predictor based on glmnet
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_glmnet}} object.
#'
#' @details
#' The predictor mirrors the mode in which the learner was fitted and
#' routes each observation to the corresponding model. See the section
#' below for the two modes.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding treatment-group
#' model is empty are returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_glmnet}}
#'
#' @examples
#' set.seed(1)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_glmnet(model = fit_two, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' # Single-learner: fit and predict
#' fit_one <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' head(predictor_glmnet(model = fit_one, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' @export
predictor_glmnet <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.matrix(x)
    
    pred <- rep(NA_real_, nrow(x))
    if (!is.null(model$model1) && length(model$model1) > 0)
    {
      pred <- as.numeric(predict(model$model1, newx = x_all,
                                 type = "response"))
    }
    return(pred)
  }
  
  # Two-learner mode: split by treatment level
  D    <- x[, ind_vars[["D"]]]
  ind1 <- which(D == d1)
  ind0 <- which(D == d0)
  
  # Split the regressors into treated and control subsamples
  x1 <- as.matrix(x[ind1, , drop = FALSE])
  x0 <- as.matrix(x[ind0, , drop = FALSE])
  x1 <- x1[, -ind_vars[["D"]], drop = FALSE]
  x0 <- x0[, -ind_vars[["D"]], drop = FALSE]
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  if ((length(ind1) > 0) && !is.null(model$model1) &&
      length(model$model1) > 0)
  {
    pred[ind1] <- as.numeric(predict(model$model1, newx = x1,
                                     type = "response"))
  }
  if ((length(ind0) > 0) && !is.null(model$model0) &&
      length(model$model0) > 0)
  {
    pred[ind0] <- as.numeric(predict(model$model0, newx = x0,
                                     type = "response"))
  }
  
  # Return the results
  return(pred)
}

#' @title Predictor based on ranger
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_ranger}} object.
#'
#' @details
#' For classification tasks, the probability column corresponding to
#' the positive class is selected by name. The column must be named
#' \code{"1"}; a probability model trained on a fold without positive
#' examples does not produce a valid positive-class column and must be
#' handled by the caller. Clipping keeps predictions strictly inside
#' \eqn{(0, 1)} so that downstream safeguards never encounter exact
#' boundary values.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding treatment-group
#' model is empty are returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_ranger}}
#'
#' @examples
#' set.seed(1)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_ranger(model = fit_two, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' # Binary outcome: the predictor returns probabilities
#' yb  <- rbinom(n, size = 1, prob = plogis(x[, "X1"]))
#' fit_b <- learner_ranger(x = x, y = yb, ind_vars = list())
#' head(predictor_ranger(model = fit_b, x = x, ind_vars = list()))
#'
#' @export
predictor_ranger <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Helper: pick the positive-class probability from a ranger output
  pick_positive <- function(mat)
  {
    if (is.null(dim(mat)))
    {
      p <- as.numeric(mat)
    }
    else
    {
      cls <- colnames(mat)
      if (is.null(cls) || !("1" %in% cls))
      {
        stop("The ranger probability matrix does not contain a column ",
             "named '1'. Ensure the outcome is coded as 0/1 factors and ",
             "both classes are present in the training fold.")
      }
      p <- as.numeric(mat[, "1"])
    }
    eps <- 1e-6
    pmin(pmax(p, eps), 1 - eps)
  }
  
  # Helper: predict on a subsample with a ranger model
  predict_subset <- function(m, x_sub)
  {
    if (is.null(m) || length(m) == 0)
    {
      return(NULL)
    }
    p <- predict(m, data = x_sub)$predictions
    if (m$treetype == "Probability estimation")
    {
      p <- pick_positive(p)
    }
    as.numeric(p)
  }
  
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    pred  <- predict_subset(model$model1, x_all)
    if (is.null(pred))
    {
      return(rep(NA_real_, nrow(x)))
    }
    return(pred)
  }
  
  # Two-learner mode: split by treatment level
  D    <- x[, ind_vars[["D"]]]
  ind1 <- which(D == d1)
  ind0 <- which(D == d0)
  
  # Split the regressors into treated and control subsamples
  x1 <- as.data.frame(x[ind1, , drop = FALSE])
  x0 <- as.data.frame(x[ind0, , drop = FALSE])
  x1 <- x1[, -ind_vars[["D"]], drop = FALSE]
  x0 <- x0[, -ind_vars[["D"]], drop = FALSE]
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  if (length(ind1) > 0)
  {
    p1 <- predict_subset(model$model1, x1)
    if (!is.null(p1))
    {
      pred[ind1] <- p1
    }
  }
  if (length(ind0) > 0)
  {
    p0 <- predict_subset(model$model0, x0)
    if (!is.null(p0))
    {
      pred[ind0] <- p0
    }
  }
  
  # Return the results
  return(pred)
}

#' @title Predictor based on glm
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_glm}} object.
#'
#' @details
#' The predictor mirrors the mode in which the learner was fitted and
#' routes each observation to the corresponding model. See the section
#' below for the two modes.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding model is empty are
#' returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_glm}}
#'
#' @examples
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- rbinom(n, size = 1, prob = plogis(x[, "X1"]))
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_glm(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_glm(model = fit_two, x = xd,
#'                    ind_vars = list(D = 3)))
#'
#' # Single-learner: fit and predict
#' fit_one <- learner_glm(x = xd, y = y, ind_vars = list(D = 3),
#'                        two_learner = FALSE)
#' head(predictor_glm(model = fit_one, x = xd,
#'                    ind_vars = list(D = 3)))
#'
#' @export
predictor_glm <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Helper: predict on a subsample with a glm model
  predict_subset <- function(m, x_sub)
  {
    if (is.null(m) || length(m) == 0)
    {
      return(NULL)
    }
    as.numeric(stats::predict(m, newdata = x_sub, type = "response"))
  }
  
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    pred  <- predict_subset(model$model1, x_all)
    if (is.null(pred))
    {
      return(rep(NA_real_, nrow(x)))
    }
    return(pred)
  }
  
  # Two-learner mode: split by treatment level
  D    <- x[, ind_vars[["D"]]]
  ind1 <- which(D == d1)
  ind0 <- which(D == d0)
  
  # Split the regressors into treated and control subsamples
  x1 <- as.data.frame(x[ind1, , drop = FALSE])
  x0 <- as.data.frame(x[ind0, , drop = FALSE])
  x1 <- x1[, -ind_vars[["D"]], drop = FALSE]
  x0 <- x0[, -ind_vars[["D"]], drop = FALSE]
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  if (length(ind1) > 0)
  {
    p1 <- predict_subset(model$model1, x1)
    if (!is.null(p1))
    {
      pred[ind1] <- p1
    }
  }
  if (length(ind0) > 0)
  {
    p0 <- predict_subset(model$model0, x0)
    if (!is.null(p0))
    {
      pred[ind0] <- p0
    }
  }
  
  # Return the results
  return(pred)
}