# ---------------------------------------------------------
# Implementations of the predictors
# ---------------------------------------------------------

#' @title Predictor based on glmnet
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_glmnet}} object.
#'
#' @details
#' The predictor mirrors the mode in which the learner was fitted and
#' routes each observation to the corresponding model. See the section
#' below for the two modes.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding treatment-group
#' model is empty are returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_glmnet}}
#'
#' @examples
#' set.seed(1)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_glmnet(model = fit_two, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' # Single-learner: fit and predict
#' fit_one <- learner_glmnet(x = xd, y = y, ind_vars = list(D = 3),
#'                           two_learner = FALSE)
#' head(predictor_glmnet(model = fit_one, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' @export
predictor_glmnet <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Helper: predict on a subsample with a glmnet model
  predict_subset <- function(m, x_sub)
  {
    if (is.null(m) || length(m) == 0)
    {
      return (NULL)
    }
    as.numeric(predict(m, newx = x_sub, type = "response"))
  }
  
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  if (isTRUE(effective_two) && (is.null(ind_vars) || is.null(ind_vars[["D"]])))
  {
    stop("The fitted model uses two learners, but 'ind_vars$D' is missing ",
         "at prediction time. Supply the same 'ind_vars' used for fitting.")
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.matrix(x)
    
    if (is.null(model$model1) || length(model$model1) == 0)
    {
      stop("The single-learner model is empty, so the predictor cannot ",
           "produce predictions. Refit the learner with a non-empty ",
           "training sample.")
    }
    pred <- as.numeric(predict(model$model1, newx = x_all,
                               type = "response"))
    return (pred)
  }
  
  # Two-learner mode: split by treatment level
  D <- x[, ind_vars[["D"]]]
  
  # Models fitted for every treatment level; fall back on the legacy
  # model0 and model1 containers when the full list is not available
  if (!is.null(model$models))
  {
    models <- model$models
  }
  else
  {
    models        <- vector(mode = "list", length = 2L)
    names(models) <- as.character(c(d0, d1))
    models[[as.character(d0)]] <- model$model0
    models[[as.character(d1)]] <- model$model1
  }
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  for (lv_str in names(models))
  {
    # Observations with this treatment level
    ind_lv <- which(as.character(D) == lv_str)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.matrix(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    
    # Predict on this subsample
    p_lv <- predict_subset(models[[lv_str]], x_lv)
    if (!is.null(p_lv))
    {
      pred[ind_lv] <- p_lv
    }
  }
  
  # Return the results
  return (pred)
}

#' @title Predictor based on ranger
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_ranger}} object.
#'
#' @details
#' For classification tasks, the probability column corresponding to
#' the positive class is selected by name. The column must be named
#' \code{"1"}; a probability model trained on a fold without positive
#' examples does not produce a valid positive-class column and must be
#' handled by the caller. Clipping keeps predictions strictly inside
#' \eqn{(0, 1)} so that downstream safeguards never encounter exact
#' boundary values.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding treatment-group
#' model is empty are returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_ranger}}
#'
#' @examples
#' set.seed(1)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- 1 + 2 * D + x[, "X1"] - x[, "X2"] + rnorm(n)
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_ranger(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_ranger(model = fit_two, x = xd,
#'                       ind_vars = list(D = 3)))
#'
#' # Binary outcome: the predictor returns probabilities
#' yb  <- rbinom(n, size = 1, prob = plogis(x[, "X1"]))
#' fit_b <- learner_ranger(x = x, y = yb, ind_vars = list())
#' head(predictor_ranger(model = fit_b, x = x, ind_vars = list()))
#'
#' @export
predictor_ranger <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Helper: pick the positive-class probability from a ranger output
  pick_positive <- function(mat)
  {
    if (is.null(dim(mat)))
    {
      p <- as.numeric(mat)
    }
    else
    {
      cls <- colnames(mat)
      if (is.null(cls) || !("1" %in% cls))
      {
        stop("The ranger probability matrix does not contain a column ",
             "named '1'. Ensure the outcome is coded as 0/1 factors and ",
             "both classes are present in the training fold.")
      }
      p <- as.numeric(mat[, "1"])
    }
    eps <- 1e-6
    pmin(pmax(p, eps), 1 - eps)
  }
  
  # Helper: predict on a subsample with a ranger model
  predict_subset <- function(m, x_sub)
  {
    if (is.null(m) || length(m) == 0)
    {
      return (NULL)
    }
    p <- predict(m, data = x_sub)$predictions
    if (m$treetype == "Probability estimation")
    {
      p <- pick_positive(p)
    }
    as.numeric(p)
  }
  
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  if (isTRUE(effective_two) && (is.null(ind_vars) || is.null(ind_vars[["D"]])))
  {
    stop("The fitted model uses two learners, but 'ind_vars$D' is missing ",
         "at prediction time. Supply the same 'ind_vars' used for fitting.")
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    pred  <- predict_subset(model$model1, x_all)
    if (is.null(pred))
    {
      stop("The single-learner model is empty, so the predictor cannot produce ",
           "predictions. Refit the learner with a non-empty training sample.")
    }
    return (pred)
  }
  
  # Two-learner mode: split by treatment level
  D <- x[, ind_vars[["D"]]]
  
  # Models fitted for every treatment level; fall back on the legacy
  # model0 and model1 containers when the full list is not available
  if (!is.null(model$models))
  {
    models <- model$models
  }
  else
  {
    models        <- vector(mode = "list", length = 2L)
    names(models) <- as.character(c(d0, d1))
    models[[as.character(d0)]] <- model$model0
    models[[as.character(d1)]] <- model$model1
  }
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  for (lv_str in names(models))
  {
    # Observations with this treatment level
    ind_lv <- which(as.character(D) == lv_str)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.data.frame(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    
    # Predict on this subsample
    p_lv <- predict_subset(models[[lv_str]], x_lv)
    if (!is.null(p_lv))
    {
      pred[ind_lv] <- p_lv
    }
  }
  
  # Return the results
  return (pred)
}

#' @title Predictor based on glm
#'
#' @description Generates predictions from a fitted
#' \code{\link[sdml]{learner_glm}} object.
#'
#' @details
#' The predictor mirrors the mode in which the learner was fitted and
#' routes each observation to the corresponding model. See the section
#' below for the two modes.
#' @template template_two_learner_predictor
#'
#' @template template_predictor_args
#' @template template_x_ind_vars
#'
#' @return A numeric vector of length \code{nrow(x)}. Positions that
#' could not be predicted because the corresponding model is empty are
#' returned as \code{NA}.
#'
#' @seealso \code{\link[sdml]{learner_glm}}
#'
#' @examples
#' set.seed(123)
#' n  <- 100
#' x  <- cbind(X1 = rnorm(n), X2 = rnorm(n))
#' D  <- rbinom(n, size = 1, prob = 0.5)
#' y  <- rbinom(n, size = 1, prob = plogis(x[, "X1"]))
#' xd <- cbind(x, D = D)
#'
#' # Two-learner: fit and predict
#' fit_two <- learner_glm(x = xd, y = y, ind_vars = list(D = 3))
#' head(predictor_glm(model = fit_two, x = xd,
#'                    ind_vars = list(D = 3)))
#'
#' # Single-learner: fit and predict
#' fit_one <- learner_glm(x = xd, y = y, ind_vars = list(D = 3),
#'                        two_learner = FALSE)
#' head(predictor_glm(model = fit_one, x = xd,
#'                    ind_vars = list(D = 3)))
#'
#' @export
predictor_glm <- function(model, x, d0 = 0, d1 = 1, ind_vars = NULL)
{
  # Helper: predict on a subsample with a glm model
  predict_subset <- function(m, x_sub)
  {
    if (is.null(m) || length(m) == 0)
    {
      return (NULL)
    }
    as.numeric(predict(m, newdata = x_sub, type = "response"))
  }
  
  # Determine the effective mode: trust 'model$two_learner' if present
  effective_two <- if (!is.null(model$two_learner))
  {
    model$two_learner
  }
  else
  {
    "D" %in% names(ind_vars)
  }
  if (isTRUE(effective_two) && (is.null(ind_vars) || is.null(ind_vars[["D"]])))
  {
    stop("The fitted model uses two learners, but 'ind_vars$D' is missing ",
         "at prediction time. Supply the same 'ind_vars' used for fitting.")
  }
  
  # Single-learner mode: predict on the whole sample
  if (!effective_two)
  {
    x_all <- as.data.frame(x)
    pred  <- predict_subset(model$model1, x_all)
    if (is.null(pred))
    {
      stop("The single-learner model is empty, so the predictor cannot produce ",
           "predictions. Refit the learner with a non-empty training sample.")
    }
    return (pred)
  }
  
  # Two-learner mode: split by treatment level
  D <- x[, ind_vars[["D"]]]
  
  # Models fitted for every treatment level; fall back on the legacy
  # model0 and model1 containers when the full list is not available
  if (!is.null(model$models))
  {
    models <- model$models
  }
  else
  {
    models        <- vector(mode = "list", length = 2L)
    names(models) <- as.character(c(d0, d1))
    models[[as.character(d0)]] <- model$model0
    models[[as.character(d1)]] <- model$model1
  }
  
  # Predict on each subsample with the corresponding model
  pred <- rep(NA_real_, nrow(x))
  for (lv_str in names(models))
  {
    # Observations with this treatment level
    ind_lv <- which(as.character(D) == lv_str)
    
    # Skip empty levels
    if (length(ind_lv) == 0L)
    {
      next
    }
    
    # Split the regressors for this treatment level
    x_lv <- as.data.frame(x[ind_lv, , drop = FALSE])
    x_lv <- x_lv[, -ind_vars[["D"]], drop = FALSE]
    
    # Predict on this subsample
    p_lv <- predict_subset(models[[lv_str]], x_lv)
    if (!is.null(p_lv))
    {
      pred[ind_lv] <- p_lv
    }
  }
  
  # Return the results
  return (pred)
}