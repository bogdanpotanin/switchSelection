# Differentiate function respect to the parameters
# estimated via mvoprobit function
deriv_mvoprobit <- function(object, fn, 
                            fn_args = list(), 
                            eps     = max(1e-4, sqrt(.Machine$double.eps) * 10),
                            type    = "default")
{
  # Get some variables
  n_par <- object$other$n_par
  n_eq  <- object$other$n_eq
  n_eq2 <- object$other$n_eq2
  n_eq3 <- object$other$n_eq3
  is1   <- object$other$is1
  is2   <- object$other$is2
  is3   <- object$other$is3
  
  # Deal with eps
  if (length(eps) == 1)
  {
    eps <- rep(eps, n_par)
  }
  
  # Estimate value of the function at initial point
  fn_args$object <- object
  fn_val         <- do.call(what = fn, args = fn_args)
  if (is.matrix(fn_val))
  {
    if (ncol(fn_val) > 1)
    {
      stop ("Function 'fn' should return a vector or a single column matrix.")
    }
  }
  n_val <- length(fn_val)
  
  # Prepare output matrix
  out           <- matrix(0, nrow = n_val, ncol = n_par)
  colnames(out) <- 1:ncol(out)
  
  # Differentiate respect to coefficients
  coef_ind <- object$ind$coef
  if (is1)
  {
    for (i in 1:n_eq)
    {
      for (j in 1:length(object$coef[[i]]))
      {
        if (eps[coef_ind[[i]][j]] != 0)
        {
          # save initial value
          par_old_tmp                     <- object$coef[[i]][j] 
          # prepare increment
          eps_tmp                         <- eps[coef_ind[[i]][j]] * 
                                             abs(par_old_tmp)
          # plus
          fn_args$object$coef[[i]][j]     <- par_old_tmp + eps_tmp
          fn_plus                         <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$coef[[i]][j]     <- par_old_tmp - eps_tmp
          fn_minus                        <- do.call(what = fn, args = fn_args)
          # derivative
          out[, coef_ind[[i]][j]]         <- (fn_plus - fn_minus) / 
                                             (2 * eps_tmp)
          # names
          colnames(out)[coef_ind[[i]][j]] <- paste0("coef",  j, " of ",
                                                    object$other$z_names[i])
          # set initial value
          fn_args$object$coef[[i]][j]     <- par_old_tmp
        }
      }
    }
  }
  
  # Differentiate respect to cuts
  cuts_ind <- object$ind$cuts
  if (is1)
  {
    for (i in 1:n_eq)
    {
      for (j in 1:length(object$cuts[[i]]))
      {
        if (eps[cuts_ind[[i]][j]] != 0)
        {
          # save initial value
          par_old_tmp <- object$cuts[[i]][j]
          # prepare increment
          eps_tmp <- eps[cuts_ind[[i]][j]] * abs(par_old_tmp)
          # plus
          fn_args$object$cuts[[i]][j] <- par_old_tmp + eps_tmp
          fn_plus <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$cuts[[i]][j] <- par_old_tmp - eps_tmp
          fn_minus <- do.call(what = fn, args = fn_args)
          # derivative
          out[, cuts_ind[[i]][j]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
          # names
          colnames(out)[cuts_ind[[i]][j]] <- paste0("cut",  j, " of ",
                                                    object$other$z_names[i])
          # set initial value
          fn_args$object$cuts[[i]][j] <- par_old_tmp
        }
      }
    }
  }
  
  # Differentiate respect to coefficients of variance equation
  coef_var_ind <- object$ind$coef_var
  if (is1)
  {
    for (i in 1:n_eq)
    {
      if (object$other$is_het[i])
      {
        for (j in 1:length(coef_var_ind[[i]]))
        {
          if (eps[coef_var_ind[[i]][j]] != 0)
          {
            # save initial value
            par_old_tmp <- object$coef_var[[i]][j]
            # prepare increment
            eps_tmp <- eps[coef_var_ind[[i]][j]] * abs(par_old_tmp)
            # plus
            fn_args$object$coef_var[[i]][j] <- par_old_tmp + eps_tmp
            fn_plus <- do.call(what = fn, args = fn_args)
            # minus
            fn_args$object$coef_var[[i]][j] <- par_old_tmp - eps_tmp
            fn_minus <- do.call(what = fn, args = fn_args)
            # derivative
            out[, coef_var_ind[[i]][j]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
            # names
            colnames(out)[coef_var_ind[[i]][j]] <- paste0("coef_var", j, " of ",
                                                          object$other$z_names[i])
            # set initial value
            fn_args$object$coef_var[[i]][j] <- par_old_tmp
          }
        }
      }
    }
  }
  
  # Differentiate respect to the elements of the covariance matrix
  # of the ordered equations
  if (n_eq > 1)
  {
    sigma_ind_mat <- object$ind$sigma_mat
    for (i in 1:(n_eq - 1))
    {
      for (j in (i + 1):n_eq)
      {
        if (eps[sigma_ind_mat[i, j]] != 0)
        {
          # save initial value
          par_old_tmp <- object$sigma[i, j]
          # prepare increment
          eps_tmp <- eps[sigma_ind_mat[i, j]] * abs(par_old_tmp)
          # plus
          fn_args$object$sigma[i, j] <- par_old_tmp + eps_tmp
          fn_args$object$sigma[j, i] <- fn_args$object$sigma[i, j]
          fn_plus <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$sigma[i, j] <- par_old_tmp - eps_tmp
          fn_args$object$sigma[j, i] <- fn_args$object$sigma[i, j]
          fn_minus <- do.call(what = fn, args = fn_args)
          # derivative
          out[, sigma_ind_mat[i, j]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
          # names
          colnames(out)[sigma_ind_mat[i, j]] <- paste0("cov(",
                                                        object$other$z_names[i],
                                                        ",",
                                                        object$other$z_names[j],
                                                        ")")
          # set initial value
          fn_args$object$sigma[i, j] <- par_old_tmp
          fn_args$object$sigma[j, i] <- par_old_tmp
        }
      }
    }
  }
  
  # Differentiate respect to the parameters of the marginal distribution
  if (object$other$is_marginal)
  {
    marginal_par_n   <- object$other$marginal_par_n
    marginal_par_ind <- object$ind$marginal_par
    for (i in 1:n_eq)
    {
      if (marginal_par_n[i] > 0)
      {
        for (j in 1:marginal_par_n[i])
        {
          if (eps[marginal_par_ind[[i]][j]] != 0)
          {
            # save initial value
            par_old_tmp <- object$marginal_par[[i]][j]
            # prepare increment
            eps_tmp <- eps[marginal_par_ind[[i]][j]] * abs(par_old_tmp)
            # plus
            fn_args$object$marginal_par[[i]][j] <- par_old_tmp + eps_tmp
            fn_plus <- do.call(what = fn, args = fn_args)
            # minus
            fn_args$object$marginal_par[[i]][j] <- par_old_tmp - eps_tmp
            fn_minus <- do.call(what = fn, args = fn_args)
            # derivative
            out[, marginal_par_ind[[i]][j]] <- (fn_plus - fn_minus) / 
                                               (2 * eps_tmp)
            # set initial value
            fn_args$object$marginal_par[[i]][j] <- par_old_tmp
          }
        }
      }
    }
  }
  
  # Derivatives respect to parameters of the continuous equations
  if (is2)
  {
    n_eq2     <- object$other$n_eq2 
    n_regimes <- object$other$n_regimes
    
    # Differentiate respect to the coefficients of the continuous equations
    coef2_ind <- object$ind$coef2
    for (i in 1:n_eq2)
    {
      for (j in 1:n_regimes[i])
      {
        for (t in 1:length(object$coef2[[i]][j, ]))
        {
          if (eps[coef2_ind[[i]][j, t]] != 0)
          {
            # save initial value
            par_old_tmp <- object$coef2[[i]][j, t] 
            # prepare increment
            eps_tmp <- eps[coef2_ind[[i]][j, t]] * abs(par_old_tmp)
            # plus
            fn_args$object$coef2[[i]][j, t] <- par_old_tmp + eps_tmp
            fn_plus <- do.call(what = fn, args = fn_args)
            # minus
            fn_args$object$coef2[[i]][j, t] <- par_old_tmp - eps_tmp
            fn_minus <- do.call(what = fn, args = fn_args)
            # derivative
            out[, coef2_ind[[i]][j, t]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
            # names
            colnames(out)[coef2_ind[[i]][j, t]] <- paste0("coef2(", 
                                                          j - 1, ",", 
                                                          t, ")", " of ",
                                                          object$other$y_names[i])
            # set initial value
            fn_args$object$coef2[[i]][j, t] <- par_old_tmp
          }
        }
      }
    }
    
    # Differentiate respect to variances of the continuous equations
    if (object$estimator == "ml")
    {
      var2_ind <- object$ind$var2
      for (i in 1:n_eq2)
      {
        for (j in 1:n_regimes[i])
        {
          if (eps[var2_ind[[i]][j]] != 0)
          {
            # save initial value
            par_old_tmp <- object$var2[[i]][j] 
            # prepare increment
            eps_tmp <- eps[var2_ind[[i]][j]] * abs(par_old_tmp)
            # plus
            fn_args$object$var2[[i]][j] <- par_old_tmp + eps_tmp
            fn_plus <- do.call(what = fn, args = fn_args)
            # plus
            fn_args$object$var2[[i]][j] <- par_old_tmp - eps_tmp
            fn_minus <- do.call(what = fn, args = fn_args)
            # derivative
            out[, var2_ind[[i]][j]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
            # names
            colnames(out)[var2_ind[[i]][j]] <- paste0("var(", 
                                                       object$other$y_names[i],
                                                       ")", j - 1)
            # set initial value
            fn_args$object$var2[[i]][j] <- par_old_tmp
          }
        }
      }
    }
    
    # Differentiate respect to the covariances between the continuous 
    # and ordered equations
    if ((object$estimator == "ml") & is1)
    {
      cov2_ind <- object$ind$cov2
      for (i in 1:n_eq2)
      {
        for (j in 1:n_regimes[i])
        {
          for (t in 1:n_eq)
          {
            if (eps[cov2_ind[[i]][j, t]] != 0)
            {
              # save initial value
              par_old_tmp <- object$cov2[[i]][j, t] 
              # prepare increment
              eps_tmp <- eps[cov2_ind[[i]][j, t]] * abs(par_old_tmp)
              # plus
              fn_args$object$cov2[[i]][j, t] <- par_old_tmp + eps_tmp
              fn_plus <- do.call(what = fn, args = fn_args)
              # minus
              fn_args$object$cov2[[i]][j, t] <- par_old_tmp - eps_tmp
              fn_minus <- do.call(what = fn, args = fn_args)
              # derivative
              out[, cov2_ind[[i]][j, t]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
              # names
              colnames(out)[cov2_ind[[i]][j, t]] <- paste0("cov(", 
                                                            object$other$y_names[i],
                                                            "(", j, ")", ",", 
                                                            object$other$z_names[t],
                                                            ")")
              # set initial value
              fn_args$object$cov2[[i]][j, t] <- par_old_tmp
            }
          }
        }
      }
    }
    
    # Differentiate respect to covariances
    # between regimes of the continuous equations
    if (n_eq2 > 1 & (object$estimator == "ml"))
    {
      sigma2_ind <- lapply(object$control_lnL$sigma2_ind, function(x){x + 1})
      counter <- 1
      regimes_pair <- object$other$regimes_pair
      for (i in 2:n_eq2)
      {
        for (j in 1:(i - 1))
        {
          for (t in 1:nrow(regimes_pair[[counter]]))
          {
            if (eps[sigma2_ind[[counter]][t]] != 0)
            {
              # save initial value
              par_old_tmp <- object$sigma2[[counter]][t]
              # prepare increment
              eps_tmp <- eps[sigma2_ind[[counter]][t]] * abs(par_old_tmp)
              # plus
              fn_args$object$sigma2[[counter]][t] <- par_old_tmp + eps_tmp
              fn_plus <- do.call(what = fn, args = fn_args)
              # minus
              fn_args$object$sigma2[[counter]][t] <- par_old_tmp - eps_tmp
              fn_minus <- do.call(what = fn, args = fn_args)
              # derivative
              out[, sigma2_ind[[counter]][t]] <- (fn_plus - fn_minus) / 
                                                 (2 * eps_tmp)
              # names
              colnames(out)[sigma2_ind[[counter]]] <- paste0(
                  "cov(",
                   object$other$y_names[i],
                   "(",
                   regimes_pair[[counter]][t, 1],
                   ")", ",",
                   "(",
                   regimes_pair[[counter]][t, 2],
                   ")",
                   object$other$y_names[j],
                   ")")
              # set initial value
              fn_args$object$sigma2[[counter]][t] <- par_old_tmp
            }
            counter <- counter + 1
          }
        }
      }
    }
  }
  
  # Differentiate respect to the coefficients of
  # the multinomial equations
  if (is3)
  {
    coef3_ind <- object$ind$coef3
    for (i in 1:(n_eq3 - 1))
    {
      for (j in 1:length(object$coef3[i, ]))
      {
        if (eps[coef3_ind[i, j]] != 0)
        {
          # save initial value
          par_old_tmp                     <- object$coef3[i, j]
          # prepare increment
          eps_tmp                         <- eps[coef3_ind[i, j]] * 
                                             abs(par_old_tmp)
          # plus
          fn_args$object$coef3[i, j]      <- par_old_tmp + eps_tmp
          fn_plus                         <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$coef3[i, j]      <- par_old_tmp - eps_tmp
          fn_minus                        <- do.call(what = fn, args = fn_args)
          # derivative
          out[, coef3_ind[i, j]]          <- (fn_plus - fn_minus) / 
                                             (2 * eps_tmp)
          # names
          colnames(out)[coef3_ind[i, j]] <- paste0("coef",  j, 
                                                   " of the Alternative ", i)
          # set initial value
          fn_args$object$coef3[i, j]     <- par_old_tmp
        }
      }
    }
  }
  
  # Short version of the output
  if (type %in% c("grad", "derivative", "jac", "gradient", "jacobian"))
  {
    return(out)
  }

  out <- list(grad = out, val = fn_val)

  return(out)
}

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

# Differentiate function respect to parameters
# estimated via mnprobit function
deriv_mnprobit <- function(object, fn, fn_args = list(), 
                           eps = max(1e-4, sqrt(.Machine$double.eps) * 10),
                           type = "default")
{
  # Get some variables
  n_par <- object$control_lnL$n_par
  n_alt <- object$control_lnL$n_alt
  n_coef <- object$control_lnL$n_coef
  
  # Deal with eps
  if (length(eps) == 1)
  {
    eps <- rep(eps, n_par)
  }
  
  # Estimate value of the function at initial point
  fn_args$object <- object
  fn_val <- do.call(what = fn, args = fn_args)
  if (is.matrix(fn_val))
  {
    if (ncol(fn_val) > 1)
    {
      stop ("Function 'fn' should return a vector or a single column matrix.")
    }
  }
  n_val <- length(fn_val)
  
  # Prepare output matrix
  out <- matrix(NA, nrow = n_val, ncol = n_par)
  colnames(out) <- 1:ncol(out)
  
  # Differentiate respect to coefficients
  coef_ind_alt <- object$control_lnL$coef_ind_alt + 1
  for (i in 1:(n_alt - 1))
  {
    for (j in 1:n_coef)
    {
      if (eps[coef_ind_alt[j, i]] != 0)
      {
        # save initial value
        par_old_tmp <- object$coef[j, i] 
        # prepare increment
        eps_tmp <- eps[coef_ind_alt[j, i]] * abs(par_old_tmp)
        # plus
        fn_args$object$coef[j, i] <- par_old_tmp + eps_tmp
        fn_plus <- do.call(what = fn, args = fn_args)
        # plus
        fn_args$object$coef[j, i] <- par_old_tmp - eps_tmp
        fn_minus <- do.call(what = fn, args = fn_args)
        # derivative
        out[, coef_ind_alt[j, i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
        # names
        colnames(out)[coef_ind_alt[j, i]] <- paste0("coef(", i, ",", j, ")")
        # set initial value
        fn_args$object$coef[j, i] <- par_old_tmp
      }
    }
  }
  
  # Differentiate respect to covariances between the
  # alternatives of the multinomial equations
  if (n_alt > 2)
  {
    sigma_ind <- object$control_lnL$sigma_ind + 1
    counter <- 1
    for (i in 1:(n_alt - 1))
    {
      for (j in 1:i)
      {
        if (!((i == 1) & (j == 1)))
        {
          if (eps[sigma_ind[counter]] != 0)
          {
            # save initial value
            par_old_tmp <- object$sigma[i, j]
            # prepare increment
            eps_tmp <- eps[sigma_ind[counter]] * abs(par_old_tmp)
            # plus
            fn_args$object$sigma[i, j] <- par_old_tmp + eps_tmp
            fn_args$object$sigma[j, i] <- fn_args$object$sigma[j, i]
            fn_plus <- do.call(what = fn, args = fn_args)
            # minus
            fn_args$object$sigma[i, j] <- par_old_tmp - eps_tmp
            fn_args$object$sigma[j, i] <- fn_args$object$sigma[j, i]
            fn_minus <- do.call(what = fn, args = fn_args)
            # derivative
            out[, sigma_ind[counter]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
            # names
            colnames(out)[sigma_ind[counter]] <- paste0("cov(", i, ",", j, ")")
            # set initial value
            fn_args$object$sigma[i, j] <- par_old_tmp
            fn_args$object$sigma[j, i] <- par_old_tmp
            # counter
          }
          counter <- counter + 1
        }
      }
    }
  }
  
  # Stuff for continuous equations
  is2 <- object$other$is2
  if (is2)
  {
    # Get some variables
    n_regimes <- object$n_regimes
      
    # Differentiate respect to coefficients
    coef2_ind_regimes <- object$control_lnL$coef2_ind_regime + 1
    for (i in 1:n_regimes)
    {
      for (j in 1:n_coef)
      {
        if (eps[coef2_ind_regimes[j, i]] != 0)
        {
          # save initial value
          par_old_tmp <- object$coef2[j, i] 
          # prepare increment
          eps_tmp <- eps[coef2_ind_regimes[j, i]] * abs(par_old_tmp)
          # plus
          fn_args$object$coef2[j, i] <- par_old_tmp + eps_tmp
          fn_plus <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$coef2[j, i] <- par_old_tmp - eps_tmp
          fn_minus <- do.call(what = fn, args = fn_args)
          # derivative
          out[, coef2_ind_regimes[j, i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
          # names
          colnames(out)[coef2_ind_regimes[j, i]] <- paste0("coef2(", i, 
                                                           ",", j, ")")
          # set initial value
          fn_args$object$coef2[j, i] <- par_old_tmp
        }
      }
    }
    # Differentiate respect to variances
    var2_ind_regime <- object$control_lnL$var2_ind_regime + 1
    for (i in 1:n_regimes)
    {
      if (eps[var2_ind_regime[i]] != 0)
      {
        # save initial value
        par_old_tmp <- object$var2[i] 
        # prepare increment
        eps_tmp <- eps[var2_ind_regime[i]] * abs(par_old_tmp)
        # plus
        fn_args$object$var2[i] <- par_old_tmp + eps_tmp
        fn_plus <- do.call(what = fn, args = fn_args)
        # minus
        fn_args$object$var2[i] <- par_old_tmp - eps_tmp
        fn_minus <- do.call(what = fn, args = fn_args)
        # derivative
        out[, var2_ind_regime[i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
        # names
        colnames(out)[var2_ind_regime[i]] <- paste0("var(", i - 1, ")")
        # set initial value
        fn_args$object$var2[i] <- par_old_tmp
      }
    }

    # Differentiate respect to covariances between
    # multinomial and continuous equations
    cov2_ind_regime <- object$control_lnL$cov2_ind_regime + 1
    for (i in 1:n_regimes)
    {
      for (j in 1:(n_alt - 1))
      {
        if (eps[cov2_ind_regime[j, i]] != 0)
        {
          # save initial value
          par_old_tmp <- object$cov2[j, i] 
          # prepare increment
          eps_tmp <- eps[cov2_ind_regime[j, i]] * abs(par_old_tmp)
          # plus
          fn_args$object$cov2[j, i] <- par_old_tmp + eps_tmp
          fn_args$object$coef_lambda[[i]][[j]] <- fn_args$object$cov2[j, i]
          fn_plus <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$cov2[j, i] <- par_old_tmp - eps_tmp
          fn_args$object$coef_lambda[[i]][[j]] <- fn_args$object$cov2[j, i]
          fn_minus <- do.call(what = fn, args = fn_args)
          # derivative
          out[, cov2_ind_regime[j, i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
          # names
          colnames(out)[cov2_ind_regime[j, i]] <- paste0("cov2(", i - 1, 
                                                          ",", j, ")")
          # set initial value
          fn_args$object$cov2[j, i] <- par_old_tmp
          fn_args$object$coef_lambda[[i]][[j]] <- par_old_tmp
        }
      }
    }
  }
  
  # Short version of the output
  if (type %in% c("grad", "derivative", "jac", "gradient", "jacobian"))
  {
    return(out)
  }

  out <- list(grad = out, val = fn_val)
  
  return(out)
}

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

# Differentiate function respect to parameters
# estimated via mnlogit function
deriv_mnlogit <- function(object, fn, fn_args = list(), 
                          eps = max(1e-4, sqrt(.Machine$double.eps) * 10),
                          type = "default")
{
  # Get some variables
  n_par <- object$control_lnL$n_par
  n_alt <- object$control_lnL$n_alt
  n_coef <- object$control_lnL$n_coef
  
  # Deal with eps
  if (length(eps) == 1)
  {
    eps <- rep(eps, n_par)
  }
  
  # Estimate value of the function at initial point
  fn_args$object <- object
  fn_val <- do.call(what = fn, args = fn_args)
  if (is.matrix(fn_val))
  {
    if (ncol(fn_val) > 1)
    {
      stop ("Function 'fn' should return a vector or a single column matrix.")
    }
  }
  n_val <- length(fn_val)
  
  # Prepare output matrix
  out <- matrix(NA, nrow = n_val, ncol = n_par)
  colnames(out) <- 1:ncol(out)
  
  # Differentiate respect to coefficients
  coef_ind_alt <- object$control_lnL$coef_ind_alt + 1
  for (i in 1:(n_alt - 1))
  {
    for (j in 1:n_coef)
    {
      if (eps[coef_ind_alt[j, i]] != 0)
      {
        # save initial value
        par_old_tmp <- object$coef[j, i] 
        # prepare increment
        eps_tmp <- eps[coef_ind_alt[j, i]] * abs(par_old_tmp)
        # plus
        fn_args$object$coef[j, i] <- par_old_tmp + eps_tmp
        fn_plus <- do.call(what = fn, args = fn_args)
        # plus
        fn_args$object$coef[j, i] <- par_old_tmp - eps_tmp
        fn_minus <- do.call(what = fn, args = fn_args)
        # derivative
        out[, coef_ind_alt[j, i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
        # names
        colnames(out)[coef_ind_alt[j, i]] <- paste0("coef(", i, ",", j, ")")
        # set initial value
        fn_args$object$coef[j, i] <- par_old_tmp
      }
    }
  }
  
  # Stuff for continuous equations
  is2 <- object$other$is2
  if (is2)
  {
    # Get some variables
    n_regimes <- object$n_regimes
    
    # Differentiate respect to coefficients
    coef2_ind_regimes <- object$control_lnL$coef2_ind_regime + 1
    for (i in 1:n_regimes)
    {
      for (j in 1:n_coef)
      {
        if (eps[coef2_ind_regimes[j, i]] != 0)
        {
          # save initial value
          par_old_tmp <- object$coef2[j, i] 
          # prepare increment
          eps_tmp <- eps[coef2_ind_regimes[j, i]] * abs(par_old_tmp)
          # plus
          fn_args$object$coef2[j, i] <- par_old_tmp + eps_tmp
          fn_plus <- do.call(what = fn, args = fn_args)
          # minus
          fn_args$object$coef2[j, i] <- par_old_tmp - eps_tmp
          fn_minus <- do.call(what = fn, args = fn_args)
          # derivative
          out[, coef2_ind_regimes[j, i]] <- (fn_plus - fn_minus) / (2 * eps_tmp)
          # names
          colnames(out)[coef2_ind_regimes[j, i]] <- paste0("coef2(", i, 
                                                           ",", j, ")")
          # set initial value
          fn_args$object$coef2[j, i] <- par_old_tmp
        }
      }
    }
  }
  
  # Short version of the output
  if (type %in% c("grad", "derivative", "jac", "gradient", "jacobian"))
  {
    return(out)
  }
  
  out <- list(grad = out, val = fn_val)
  
  return(out)
}

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

#' Delta method and Wald test for mvoprobit, mnprobit and mnlogit functions
#' @description This function uses delta method to estimate standard errors
#' of functions of the estimator of the parameters of 
#' \code{\link[switchSelection]{mvoprobit}}, 
#' \code{\link[switchSelection]{mnprobit}} and 
#' \code{\link[switchSelection]{mnlogit}} 
#' functions.
#' @param object an object of class 'mvoprobit', 'mnprobit' or 'mnlogit'.
#' @param fn function which returns a numeric vector and should depend on the 
#' elements of \code{object}. These elements should be accessed via 
#' \code{\link[switchSelection]{coef.mvoprobit}},
#' \code{\link[switchSelection]{coef.mnprobit}} and
#' \code{\link[switchSelection]{coef.mnlogit}} functions. 
#' Also it is possible to use \code{\link[switchSelection]{predict.mvoprobit}}, 
#' \code{\link[switchSelection]{predict.mnprobit}} and
#' \code{\link[switchSelection]{predict.mnlogit}} functions.
#' The first argument of \code{fn} should be \code{object}.
#' Therefore \code{coef} and \code{predict} functions in \code{fn} should also
#' depend on \code{object}.
#' @param fn_args list of additional arguments of \code{fn}.
#' @param eps positive numeric value representing the increment used for
#' numeric differentiation of \code{fn}. It may also be a numeric vector
#' such that \code{eps[i]} is increment used to differentiate 
#' \code{fn} respect to the \code{par_ind[i]}-th parameter of the model.
#' Set \code{ind = TRUE} in \code{summary}, to see the indexes of 
#' model parameters. If \code{eps[i] = 0} then derivative of \code{fn} respect
#' to \code{par_ind[i]}-th parameter is assumed to be zero.
#' @param cl numeric value between \code{0} and \code{1} representing
#' a confidence level of the confidence interval.
#' @param par_ind vector of indexes of the model (estimated) parameters used in 
#' calculation of \code{fn}. If only necessarily indexes are included then
#' in some cases estimation time may greatly decrease. Set \code{ind = TRUE}
#' in \code{summary} to see the indexes of the model parameters. If \code{eps} 
#' is a vector then \code{eps[i]} determines the increment used to differentiate
#' \code{fn} respect to  parameter with \code{par_ind[i]}-th index.
#' @param type character representing the type of the test to
#' be used. If \code{type = "dm"} then delta method is used to test the 
#' hypotheses that each value (separately) of \code{fn} given true parameters 
#' is zero. If \code{type = "wald"} then Wald test is used to test the 
#' hypothesis that given true parameters all values of \code{fn} are 
#' simultaneously equal zero. If \code{type = "score"} then score bootstrap
#' Wald test is used which has been proposed by P. Kline and A. Santos (2012).
#' @param vcov estimate of the asymptotic covariance matrix of the parameters
#' of the model.
#' @param iter the number of iterations used by the score bootstrap Wald test.
#' @param generator function which is used by the score bootstrap to generate
#' random weights. It should have an argument \code{n} representing the
#' number of random weights to generate. Other arguments are ignored.
#' @details Numeric differentiation is used to estimate derivatives of
#' \code{fn} respect to various parameters of 
#' \code{\link[switchSelection]{mvoprobit}}, 
#' \code{\link[switchSelection]{mnprobit}} and
#' \code{\link[switchSelection]{mnlogit}} functions.
#' 
#' This function may be used only if \code{object$estimator = "ml"}.
#' 
#' Alternatively apply \code{\link[switchSelection]{bootstrap_test}} function
#' for the analysis of confidence intervals and hypothesis testing
#' based on bootstrap.
#' @return This function returns an object of class \code{delta_method}. If
#' \code{type = "dm"} then it is a matrix which columns are as follows:
#' \itemize{
#' \item \code{val} - output of the \code{fn} function.
#' \item \code{se} - numeric vector such that \code{se[i]} represents standard
#' error associated with \code{val[i]}.
#' \item \code{p_value} - numeric vector such that \code{p_value[i]} represents
#' p-value of the two-sided significance test associated with \code{val[i]}.
#' Null hypothesis is that \code{fn} equals zero.
#' \item \code{lwr} - realization of the lower (left) bound of the 
#' confidence interval.
#' \item \code{upr} - realization of the upper (right) bound of the 
#' confidence interval.
#' }
#' 
#' If \code{type = "wald"} or \code{type = "score"} then output is a matrix 
#' which columns are as follows:
#' \itemize{
#' \item \code{stat} - the value of the test statistic.
#' \item \code{p_value} - p-value of the Wald test which
#' null hypothesis is that all values of \code{fn} equal zero.
#' }
#' 
#' An object of class \code{delta_method} has implementation of 
#' \code{summary} method 
#' \code{\link[switchSelection]{summary.delta_method}}.
#' @references P. Kline, A. Santos (2012). 
#' A Score Based Approach to Wild Bootstrap Inference.
#' Journal of Econometric Methods, vol. 67, no. 1, pages 23-41.
#' @template delta_method_examples_Template
delta_method <- function(object, fn, 
                         fn_args   = list(), 
                         eps       = max(1e-4, sqrt(.Machine$double.eps) * 10), 
                         cl        = 0.95,
                         par_ind   = 1:object$control_lnL$n_par,
                         type      = "dm",
                         vcov      = object$cov,
                         iter      = 100,
                         generator = rnorm)
{
  # Validate confidence level
  if ((cl <= 0) | (cl >= 1))
  {
    stop("Invalid 'cl' value. It should be between 0 and 1.")
  }
  
  # Validate the type
  type <- tolower(type)
  type_vec <- c("type", "wald")
  if (type %in% c("waldtest", "wald test", "aggregate"))
  {
    type <- "wald"
    warning("It is assumed that 'type' is 'vald'.")
  }
  if (type %in% c("delta method", "deltamethod", "individual", "ind"))
  {
    type <- "dm"
    warning("It is assumed that 'type' is 'dm'.")
  }
  
  # Get the number of parameters of the model
  n_par <- object$control_lnL$n_par
  
  # Validate par_ind argument
  par_ind_unique <- unique(par_ind)
  if (length(par_ind) != length(par_ind_unique))
  {
    warning("Duplicates of some indexes have been removed from 'par_ind'.")
    par_ind <- par_ind_unique
  }
  out_of_range <- (par_ind < 1) | (par_ind > n_par)
  if (any(out_of_range))
  {
    warning(paste0("Indexes ", paste(par_ind[out_of_range], collapse = ", "), 
                   " are out of range so they have been removed",
                   " from 'par_ind'."))
    par_ind <- par_ind[!out_of_range]
  }
  if (length(par_ind) == 0)
  {
    stop("Input argument 'par_ind' should not be empty.")
  }
  
  # Deal with eps argument
  if (length(eps) == 1)
  {
    eps <- rep(eps, length(par_ind))
  }
  if (length(eps) != length(par_ind))
  {
    stop(paste0("If 'eps' has more than 1 element then ",
                "length of 'eps' and 'par_ind' should be the same. "))
  }
  eps_tmp <- rep(0, n_par)
  eps_tmp[par_ind] <- eps
  eps <- eps_tmp
  eps[is.na(eps)] <- 0
  
  # Get values of derivatives
  d_list <- NULL
  if (is(object = object, class2 = "mvoprobit"))
  {
    d_list <- deriv_mvoprobit(object = object, fn = fn, 
                              fn_args = fn_args, eps = eps)
  }
  if (is(object = object, class2 = "mnprobit"))
  {
    d_list <- deriv_mnprobit(object = object, fn = fn, 
                             fn_args = fn_args, eps = eps)
  }
  if (is(object = object, class2 = "mnlogit"))
  {
    d_list <- deriv_mnlogit(object = object, fn = fn, 
                            fn_args = fn_args, eps = eps)
  }
  d   <- d_list$grad
  val <- d_list$val
  n   <- nrow(d)
  if (is.null(names(val)))
  {
    names(val) <- 1:n
  }
  
  # Use delta method
  if (type == "dm")
  {
    se <- vector(mode = "numeric", length = n)
    for (i in 1:n)
    {
      se[i] <- sqrt(d[i, , drop = FALSE] %*% vcov %*% t(d[i, , drop = FALSE]))
    }
    
    # Get p-values
    z_value <- val / se
    p_value <- rep(NA, n)
    for (i in 1:n)
    {
      p_value[i] <- 2 * min(pnorm(z_value[i]), 1 - pnorm(z_value[i]))
    }
    
    # Get bounds of the confidence interval
    b   <- qnorm(cl + (1 - cl) / 2) * se
    lwr <- val - b
    upr <- val + b
    
    # Aggregate the output
    names(se)              <- names(val)
    names(p_value)         <- names(val)
    out                    <- cbind(val, se, lwr, upr, p_value)
    colnames(out)          <- c("val", "se", "lwr", "upr", "p_value")
    attr(out, 'test_type') <- type
  }
  
  # Use Wald test
  if (type == "wald")
  {
    val           <- matrix(val, ncol = 1)
    Chi2          <- as.numeric(t(val) %*% qr.solve(d %*% vcov %*% t(d), 
                                                    tol = 1e-16) %*% val)
    p_value                <- 1 - pchisq(Chi2, df = n)
    out                    <- cbind(Chi2, p_value)
    colnames(out)          <- c("stat", "p_value")
    rownames(out)          <- "Wald test"
    attr(out, 'test_type') <- type
  }
  
  # Use score bootstrap with Wald statistic
  if (type == "score")
  {
    # calculate Jacobian and Hessian if need
    if (!hasName(object, name = "J") | !hasName(object, name = "H"))
    {
      vcov_ml_list  <- vcov_ml(object, type = "sandwich", 
                               n_cores = 1, n_sim = 1000)
      object$J      <- vcov_ml_list$J
      object$H      <- vcov_ml_list$H
    }
    # initial statistic
    scores <- object$J
    H      <- object$H
    n_obs  <- nrow(scores)
    val    <- matrix(val, ncol = 1) / sqrt(n_obs)
    H_inv  <- qr.solve(H, tol = 1e-16)
    A      <- d %*% H_inv
    T_0    <- t(val) %*% 
              qr.solve(A %*% cov(scores) %*% t(A), tol = 1e-16) %*% 
              val
    T_0    <- as.numeric(T_0)
    # bootstrapped statistics 
    T_boot <- rep(NA, iter)
    for (i in 1:iter)
    {
      weights       <- generator(n = nrow(scores))
      scores_adj    <- weights * scores
      S             <- A %*% colSums(scores_adj) / sqrt(n_obs)
      T_boot[i]     <- t(S) %*% 
                       qr.solve(A %*% cov(scores_adj) %*% t(A), tol = 1e-16) %*% 
                       S
    }
    p_value                <- mean(T_boot >= T_0)
    out                    <- cbind(T_0, p_value)
    colnames(out)          <- c("stat", "p_value")
    rownames(out)          <- "Wald test"
    attr(out, 'test_type') <- type
    attr(out, 'test_iter') <- iter
  }
  
  # Return the results
  class(out)  <- "delta_method"
  
  return(out)
}

#' Summary for an Object of Class delta_method
#' @description Provides summary for an object of class 'delta_method'.
#' @param object object of class 'delta_method'
#' @param ... further arguments (currently ignored)
#' @return Returns an object of class 'summary.delta_method'.
summary.delta_method <- function(object, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  class(object) <- "summary.delta_method"
  
  return(object)
}

#' Print summary for an Object of Class delta_method
#' @description Prints summary for an object of class 'delta_method'.
#' @param x object of class 'delta_method'
#' @param ... further arguments (currently ignored)
#' @return The function returns input argument \code{x}.
print.summary.delta_method <- function(x, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")   
  }
  
  class(x) <- "delta_method"
  
  printCoefmat(x, signif.legend = TRUE, has.Pvalue = TRUE)
  
  if (attributes(x)$test_type == "score")
  {
    cat(paste0(attributes(x)$test_iter, 
               " iterations of score bootstrap have been used to ",
               "calculate p-value.\n"))
  }
  
  return(x)
}